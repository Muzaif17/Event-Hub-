# 🎓 MHSSCE EventHub

**Events & Activities Portal — M.H. Saboo Siddik College of Engineering, Mumbai**

> One platform to **discover, register, manage and archive** every college event —
> hackathons, fests, competitions, workshops, seminars, sports and club activities.

![Status](https://img.shields.io/badge/status-Phase%201%20%26%202%20complete-12b76a)
![Built for](https://img.shields.io/badge/built%20for-MHSSCE%20CSE%20project-1d5bd8)

---

## ✨ What it does

| Role | What they can do |
|---|---|
| 👨‍🎓 **Student** | Browse live/upcoming/past events · filter by category · register (individual or team, with demo payment) · get confirmation with Registration ID · track everything on a personal dashboard · download participation/winner **certificates** · climb the **college leaderboard** |
| 🎤 **Organizer** | Create & publish events · manage registrations (paid/attended, CSV export) · **publish results** (auto-issues certificates + leaderboard points) · manage gallery |
| 🛠️ **Admin** | Everything an organizer can do, plus: manage **users & roles**, revoke certificates, full dashboard analytics |

### Highlights
- 🔴 **Live event status engine** — statuses (`Upcoming → Reg. Open → Reg. Closed → 🔴 Live → Completed → Results Published`) are **computed automatically from dates**, never set by hand
- ⏱ **Real-time countdowns** on live & upcoming events
- 🏆 **Results + winner profiles** with medals, prizes and projects
- 🎖 **Digital certificates** rendered on `<canvas>` — downloadable PNG with unique ID + barcode, and a **public verification page** (`CERT-2026-10231` is a working demo ID)
- 🏅 **Leaderboard points engine** — Winner +100 · Runner-up +70 · Third +50 · Finalist +40 · Participation +10
- 📕 **Event archive** — a permanent digital history of college events, year by year
- 📸 **Gallery with lightbox**, club pages, animated stat counters, toasts, page transitions
- 📱 Fully responsive — works on phones, tablets and projectors

---

## 🚀 How to run

**Option A — dev server (recommended)**
```bash
cd mhssce-eventhub
python3 server.py
# open http://localhost:8000
```

**Option B — single-file build** (works offline, perfect for presentation day)
```bash
python3 build_standalone.py   # generates MHSSCE-EventHub.html at repo root
```
One self-contained HTML file — all CSS, JS and images embedded. Open it anywhere, even from a USB stick.

**Demo accounts** (also shown on the login page)

| Role | Email | Password |
|---|---|---|
| Student | `student@mhssce.ac.in` | `student123` |
| Organizer | `organizer@mhssce.ac.in` | `org123` |
| Admin | `admin@mhssce.ac.in` | `admin123` |

> Data persists in your browser's `localStorage`. Reset anytime from
> **Admin Panel → Shortcuts → Reset demo data**.

---

## 🧱 Technology

- **HTML5 + CSS3 + Vanilla JavaScript** — no frameworks, no build step, no CDN (works fully offline)
- Single-page app with a **hash router** (`#/events`, `#/results`, `#/admin/…`)
- **Canvas API** for certificates, confirmations (with generated barcode) and dashboard charts
- **`localStorage` mock-DB** that mirrors the designed MongoDB collections — swappable with a real backend without touching the UI
- Python `http.server` dev server + standalone builder

### Planned production stack (Phase 3)
`React.js + Tailwind` · `Node.js + Express` · `MongoDB Atlas` · `JWT auth` · `Cloudinary` · `Razorpay` · deploy on Vercel/Render

---

## 📂 Project structure

```text
mhssce-eventhub/
├── index.html               # app shell (navbar / footer / router root)
├── css/
│   └── styles.css           # full design system
├── js/
│   ├── data.js              # seed DB — users, events, clubs, results, certificates, gallery
│   ├── helpers.js           # storage, dates, status engine, canvas certs, charts, CSV
│   ├── components.js        # event cards, winner cards, club cards, navbar session
│   ├── pages.js             # public pages + registration flow + login + dashboard
│   ├── admin.js             # admin/organizer panel (events, regs, users, results, certs, gallery)
│   └── app.js               # state, session, hash router, boot
├── assets/img/              # college logo (favicon, badge, transparent) + event banners
├── server.py                # dev server (SPA fallback)
├── build_standalone.py      # single-file offline build
└── README.md
```

---

## 🗄️ Data model (mirrors the MongoDB design)

```text
USERS          → id, name, email, phone, PRN, branch, year, role, pass
EVENTS         → id, title, tagline, description, category, club, venue,
                 dates/times, regDeadline, entryFee, maxParticipants, teamSize,
                 eligibility, banner, prizes[], rules[], schedule[], organizers[],
                 published, resultsPublished
REGISTRATIONS  → id (EV2026-xxxx), eventId, userId, participant snapshot,
                 type (individual/team), teamName, members[], paid, attended
RESULTS        → id, eventId, position, title, members[], prize, project
CLUBS          → id, name, emoji, tagline, about, faculty & student coordinators, members
CERTIFICATES   → id (CERT-2026-xxxxx), eventId, userId, name, achievement, date
GALLERY        → id, eventId, image, caption
```

## 🔢 Status engine

```text
UPCOMING ──▶ REGISTRATION OPEN ──▶ REGISTRATION CLOSED ──▶ 🔴 HAPPENING NOW
       ──▶ COMPLETED ──▶ RESULT PUBLISHED
```
Computed in `getStatus(event)` from start/end times, registration deadline and the
`resultsPublished` flag — labels can never go stale.

---

## 🗺️ Roadmap

- [x] **Phase 1 (MVP)** — home, events, details, registration, results, winners, participants, admin event creation
- [x] **Phase 2 (Advanced)** — clubs, gallery, search/filter, countdowns, certificates + verification, leaderboard, user dashboard, archive
- [ ] **Phase 3 (Real platform)** — college SSO, QR attendance, payment gateway, e-mail notifications, event approval workflow, analytics, organizer dashboards per club

---

## 👥 Team EventHub

Built by students of MHSSCE as a classroom project — designed to grow into a real
college-wide platform. All events, people and results in the demo are sample data.

*Crafted with 💙 by Team EventHub · 2026*
