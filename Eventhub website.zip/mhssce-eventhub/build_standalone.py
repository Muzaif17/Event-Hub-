#!/usr/bin/env python3
"""
MHSSCE EventHub — standalone builder

Produces ONE self-contained HTML file (MHSSCE-EventHub.html at the repo root):
  • inlines the stylesheet and all scripts
  • embeds every image exactly once in a global window.__ASSET_MAP
  • small static images (navbar/footer logo, favicon) are inlined directly

The output works offline — double-click it anywhere, no server needed.
Perfect for classroom presentations.

Run:  python3 build_standalone.py
"""
import base64
import os
import re

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(ROOT), "MHSSCE-EventHub.html")
MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".webp": "image/webp", ".svg": "image/svg+xml", ".ico": "image/x-icon"}


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def data_uri(rel):
    path = os.path.join(ROOT, rel.replace("/", os.sep))
    ext = os.path.splitext(path)[1].lower()
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return "data:%s;base64,%s" % (MIME.get(ext, "application/octet-stream"), b64)


def main():
    html = read(os.path.join(ROOT, "index.html"))

    # 1. inline stylesheets
    html = re.sub(
        r'<link rel="stylesheet" href="([^"]+)">',
        lambda m: "<style>\n" + read(os.path.join(ROOT, m.group(1))) + "\n</style>",
        html,
    )

    # 2. inline scripts
    html = re.sub(
        r'<script src="([^"]+)"></script>',
        lambda m: "<script>\n" + read(os.path.join(ROOT, m.group(1))) + "\n</script>",
        html,
    )

    # 3. static images referenced directly in the HTML → inline as data URIs
    static_imgs = sorted(set(re.findall(r'(?<=src=")assets/img/[\w.\-]+(?=")', html)
                             + re.findall(r'(?<=href=")assets/img/[\w.\-]+(?=")', html)))
    for rel in static_imgs:
        html = html.replace('"%s"' % rel, '"%s"' % data_uri(rel)) \
                   .replace("'%s'" % rel, "'%s'" % data_uri(rel))

    # 4. every image the JS/CSS references at runtime → one global ASSET map
    runtime_refs = sorted(set(re.findall(r"assets/img/[\w.\-]*[\w\-]", html)) - set(static_imgs))
    if runtime_refs:
        entries = ", ".join('"%s":"%s"' % (rel, data_uri(rel)) for rel in runtime_refs)
        map_script = "<script>window.__ASSET_MAP = {%s};</script>" % entries
        html = html.replace("</head>", map_script + "\n</head>", 1)

    with open(OUT, "w", encoding="utf-8") as f:
        f.write(html)

    print("Built %s  (%.2f MB)" % (OUT, os.path.getsize(OUT) / 1e6))
    print("Static inline:", len(static_imgs), "| Runtime map:", len(runtime_refs))


if __name__ == "__main__":
    main()
