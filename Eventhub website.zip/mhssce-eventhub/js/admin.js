/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — Admin / Organizer panel
   ═══════════════════════════════════════════════════════════════ */

var ADMIN_SECTIONS = [
  ["/admin", "📊", "Dashboard"],
  ["/admin/events", "🎪", "Events"],
  ["/admin/registrations", "📝", "Registrations"],
  ["/admin/users", "👥", "Users"],
  ["/admin/results", "🏆", "Results & Winners"],
  ["/admin/certificates", "🎖", "Certificates"],
  ["/admin/gallery", "📸", "Gallery"]
];

function adminShell(active, contentHTML) {
  var u = currentUser();
  return '<div class="container"><div class="admin-layout">' +
    '<aside class="admin-side">' +
    '<div class="as-title">' + (u && u.role === "admin" ? "Admin" : "Organizer") + ' Panel</div>' +
    ADMIN_SECTIONS.map(function (s) {
      return '<a href="#' + s[0] + '" class="' + (active === s[0] ? "active" : "") + '">' + s[1] + " " + s[2] + "</a>";
    }).join("") +
    '<div class="as-title">Shortcuts</div>' +
    '<a href="#/events">🌐 View public site</a>' +
    '<a href="javascript:resetDemoData()" style="color:#b45309">♻️ Reset demo data</a>' +
    "</aside>" +
    '<section id="adminContent">' + contentHTML + "</section>" +
    "</div></div>";
}

/* ═══════════════ ADMIN ROUTER ═══════════════ */
function pageAdmin(section, params) {
  if (section === "events" && params && (params.new || params.edit)) {
    DB.__editingId = params.edit || null;
    return adminEventForm(params);
  }
  if (section === "dashboard") return adminDashboard();
  if (section === "events") return adminEvents();
  if (section === "registrations") return adminRegistrations(params);
  if (section === "users") return adminUsers();
  if (section === "results") return adminResults();
  if (section === "certificates") return adminCertificates();
  if (section === "gallery") return adminGallery();
  return adminDashboard();
}

/* ═══════════════ DASHBOARD ═══════════════ */
function adminDashboard() {
  var totalRegs = DB.registrations.length;
  var fees = DB.registrations.reduce(function (s, r) { return s + (r.paid ? r.fee || 0 : 0); }, 0);
  var liveCount = DB.events.filter(function (e) { return e.published !== false && getStatus(e).key === "live"; }).length;
  var upcomingCount = DB.events.filter(function (e) { var k = getStatus(e).key; return e.published !== false && (k === "open" || k === "closed"); }).length;
  var recent = DB.registrations.slice(-7).reverse();
  var catTotals = {};
  DB.registrations.forEach(function (r) {
    var e = eventById(r.eventId);
    if (e) catTotals[e.cat] = (catTotals[e.cat] || 0) + 1;
  });
  var donutItems = Object.keys(catTotals).map(function (k) { return { label: k, value: catTotals[k] }; });
  var topEvents = DB.events.map(function (e) { return { e: e, n: joinedCount(e) }; })
    .sort(function (a, b) { return b.n - a.n; }).slice(0, 6);

  var content =
    '<h1 class="page-title">Dashboard</h1><p class="page-sub">EventHub at a glance — ' + new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) + "</p>" +
    '<div class="stat-cards mt-3">' +
    '<div class="stat-card"><span class="sc-icon">🎪</span><small>Total events</small><b>' + DB.events.length + "</b>" +
    '<div class="trend up">▲ ' + liveCount + " live · " + upcomingCount + " upcoming</div></div>" +
    '<div class="stat-card"><span class="sc-icon">👥</span><small>Registrations</small><b>' + totalRegs + "</b>" +
    '<div class="trend up">▲ this semester</div></div>' +
    '<div class="stat-card"><span class="sc-icon">🤝</span><small>Clubs</small><b>' + DB.clubs.length + "</b>" +
    '<div class="trend up">All active</div></div>' +
    '<div class="stat-card"><span class="sc-icon">💰</span><small>Fees collected</small><b>₹' + fees.toLocaleString("en-IN") + "</b>" +
    '<div class="trend up">▲ demo gateway</div></div>' +
    "</div>" +
    '<div class="chart-row mt-3">' +
    '<div class="chart-box"><h4>📈 Top events by registrations</h4><canvas id="chartBar"></canvas></div>' +
    '<div class="chart-box"><h4>🍩 Registrations by category</h4><canvas id="chartDonut"></canvas></div>' +
    "</div>" +
    '<div class="panel mt-3"><div class="flex-between"><h3 style="margin:0">🧾 Recent registrations</h3>' +
    '<a class="btn btn-ghost btn-sm" href="#/admin/registrations">View all →</a></div>' +
    '<div class="table-wrap mt-2" style="box-shadow:none"><table class="data"><thead><tr><th>Reg. ID</th><th>Participant</th><th>Event</th><th>Type</th><th>Status</th></tr></thead><tbody>' +
    recent.map(function (r) {
      var e = eventById(r.eventId);
      return "<tr><td class='mono'>" + r.id + "</td><td class='t-main'>" + esc(r.name) + "</td><td>" + esc(e ? e.title : "—") + "</td>" +
        "<td>" + (r.type === "team" ? "👥 " + esc(r.teamName) : "👤") + "</td><td>" + (r.paid ? '<span class="badge badge-green">Paid</span>' : '<span class="badge badge-closed">Unpaid</span>') + "</td></tr>";
    }).join("") +
    "</tbody></table></div></div>" +
    '<div class="panel mt-3"><h3>⚡ Quick actions</h3><div class="chip-row">' +
    '<a class="chip" href="#/admin/events?new=1">➕ Create event</a>' +
    '<a class="chip" href="#/admin/results">🏆 Publish results</a>' +
    '<a class="chip" href="#/admin/certificates">🎖 Issue certificate</a>' +
    '<a class="chip" href="#/admin/registrations">📝 Registrations & CSV</a>' +
    "</div></div>";

  window.__afterRender = function () {
    var cb = qs("#chartBar"), cd = qs("#chartDonut");
    if (cb) drawBarChart(cb, topEvents.map(function (x) { return x.e.title; }), topEvents.map(function (x) { return x.n; }));
    if (cd) drawDonut(cd, donutItems.length ? donutItems : [{ label: "No data", value: 1 }]);
  };
  return adminShell("/admin", content);
}

/* ═══════════════ MANAGE EVENTS ═══════════════ */
function adminEvents() {
  var list = DB.events.slice().sort(function (a, b) { return evStart(b) - evStart(a); });
  var content =
    '<div class="admin-toolbar"><div><h1 class="page-title">Events</h1><p class="page-sub">' + list.length + " events · statuses are computed automatically from dates</p></div>" +
    '<a class="btn btn-primary" href="#/admin/events?new=1">➕ Create Event</a></div>' +
    '<div class="table-wrap"><table class="data"><thead><tr>' +
    "<th>Event</th><th>Date</th><th>Category / Club</th><th>Status</th><th>Regs</th><th>Published</th><th>Actions</th></tr></thead><tbody>" +
    list.map(function (e) {
      return "<tr><td><div class='t-main'>" + esc(e.title) + "</div><div class='t-sub'>" + e.id + " · " + esc(e.venue.split(",")[0]) + "</div></td>" +
        "<td>" + fmtDateRange(e) + "</td>" +
        "<td><span class='badge badge-blue'>" + esc(e.cat) + "</span><div class='t-sub mt-1'>" + esc(clubName(e.clubId)) + "</div></td>" +
        "<td>" + badgeHTML(e) + "</td>" +
        "<td><b>" + joinedCount(e) + "</b></td>" +
        "<td><label class='switch'><input type='checkbox' " + (e.published !== false ? "checked" : "") + " onchange='togglePublish(\"" + e.id + "\",this.checked)'><i></i></label></td>" +
        "<td><div class='flex' style='gap:6px'>" +
        '<button class="icon-btn" title="Edit" onclick="location.hash=\'#/admin/events?edit=' + e.id + '\'">✏️</button>' +
        '<button class="icon-btn" title="Results" onclick="location.hash=\'#/admin/results\'">🏆</button>' +
        '<button class="icon-btn del" title="Delete" onclick="deleteEvent(\'' + e.id + '\')">🗑</button>' +
        "</div></td></tr>";
    }).join("") + "</tbody></table></div>";
  return adminShell("/admin/events", content);
}
function togglePublish(id, val) {
  var e = eventById(id);
  if (e) { e.published = val; saveDB(); toast(e.title + (val ? " published ✓" : " unpublished (draft)"), "ok"); route(); }
}
function deleteEvent(id) {
  var e = eventById(id);
  openModal(modalHead("Delete event?", esc(e.title)) +
    '<div class="modal-body"><p class="muted">This removes the event and its registrations/results from the demo database. This cannot be undone.</p></div>' +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-danger" onclick="confirmDeleteEvent(\'' + id + '\')">Delete permanently</button></div>', 480);
}
function confirmDeleteEvent(id) {
  DB.events = DB.events.filter(function (e) { return e.id !== id; });
  DB.registrations = DB.registrations.filter(function (r) { return r.eventId !== id; });
  DB.results = DB.results.filter(function (r) { return r.eventId !== id; });
  DB.gallery = DB.gallery.filter(function (g) { return g.eventId !== id; });
  DB.certificates = DB.certificates.filter(function (c) { return c.eventId !== id; });
  saveDB(); closeModal(); route();
  toast("Event deleted", "info");
}

/* ═══════════════ CREATE / EDIT EVENT ═══════════════ */
function adminEventForm(params) {
  var isNew = !!params.new;
  var e = isNew ? null : eventById(params.edit);
  if (!isNew && !e) return adminEvents();
  var clubOpts = DB.clubs.map(function (c) { return "<option value='" + c.id + "' " + (e && e.clubId === c.id ? "selected" : "") + ">" + c.emoji + " " + esc(c.name) + "</option>"; }).join("");
  var bannerPicks = IMG_LIBRARY.map(function (im) {
    return "<img src='" + A(im.src) + "' title='" + esc(im.label) + "' onclick='pickBanner(this)' data-src='" + im.src + "' class='" + ((e && e.banner === im.src) || (!e && im.src === "assets/img/hackathon.jpg") ? "sel" : "") + "'>";
  }).join("");
  var prizeRow = function (pos, label) {
    var p = e && e.prizes ? (e.prizes.find(function (x) { return x.pos === pos; }) || {}) : {};
    return '<div class="field"><label>' + label + '</label><div class="flex"><input id="ef_prize' + pos + '" type="number" min="0" placeholder="₹ amount" value="' + (p.amt || "") + '" style="flex:1"><input id="ef_plabel' + pos + '" placeholder="Label (optional)" value="' + esc(p.label || "") + '"></div></div>';
  };
  var content =
    '<a class="back-link" href="#/admin/events">← Back to events</a>' +
    "<h1 class='page-title'>" + (isNew ? "Create Event" : "Edit Event") + "</h1>" +
    "<p class='page-sub'>Status (Upcoming → Live → Completed → Results) is computed automatically from the dates you set.</p>" +
    '<div class="panel mt-3"><h3>🎪 Event details</h3><div class="form-grid">' +
    '<div class="field full"><label>Event Name <span class="req">*</span></label><input id="ef_title" value="' + esc(e ? e.title : "") + '" placeholder="e.g. Hackathon 2027"><div class="err">Event name is required</div></div>' +
    '<div class="field full"><label>Tagline</label><input id="ef_tagline" value="' + esc(e ? e.tagline : "") + '" placeholder="e.g. Build • Innovate • Solve"></div>' +
    '<div class="field full"><label>Description <span class="req">*</span></label><textarea id="ef_desc" rows="4" placeholder="What is this event about?">' + esc(e ? e.desc : "") + "</textarea></div>" +
    '<div class="field"><label>Category <span class="req">*</span></label><select id="ef_cat">' + CATEGORIES.map(function (c) { return "<option " + (e && e.cat === c ? "selected" : "") + ">" + c + "</option>"; }).join("") + "</select></div>" +
    '<div class="field"><label>Organizing Club <span class="req">*</span></label><select id="ef_club">' + clubOpts + "</select></div>" +
    '<div class="field full"><label>Venue <span class="req">*</span></label><input id="ef_venue" value="' + esc(e ? e.venue : "") + '" placeholder="e.g. Seminar Hall, MHSSCE Campus"></div>' +
    '<div class="field"><label>Start Date <span class="req">*</span></label><input id="ef_dstart" type="date" value="' + (e && e.dateStart ? e.dateStart : "") + '"></div>' +
    '<div class="field"><label>End Date (optional)</label><input id="ef_dend" type="date" value="' + (e && e.dateEnd ? e.dateEnd : "") + '"></div>' +
    '<div class="field"><label>Start Time</label><input id="ef_tstart" type="time" value="' + (e ? e.timeStart : "09:00") + '"></div>' +
    '<div class="field"><label>End Time</label><input id="ef_tend" type="time" value="' + (e ? e.timeEnd : "17:00") + '"></div>' +
    '<div class="field"><label>Registration Deadline</label><input id="ef_regd" type="date" value="' + (e && e.regDeadline ? e.regDeadline : "") + '"></div>' +
    '<div class="field"><label>Entry Fee (₹, 0 = free)</label><input id="ef_fee" type="number" min="0" value="' + (e ? e.fee : 0) + '"></div>' +
    '<div class="field"><label>Max Participants</label><input id="ef_max" type="number" min="1" value="' + (e ? e.maxPart : 100) + '"></div>' +
    '<div class="field"><label>Eligibility</label><input id="ef_elig" value="' + esc(e ? e.eligibility : "Open to all MHSSCE students") + '"></div>' +
    '<div class="field"><label>Team — min size</label><input id="ef_tmin" type="number" min="1" value="' + (e ? e.teamMin : 1) + '"></div>' +
    '<div class="field"><label>Team — max size</label><input id="ef_tmax" type="number" min="1" value="' + (e ? e.teamMax : 4) + '"></div>' +
    "</div></div>" +
    '<div class="panel"><h3>🖼️ Event banner</h3><div class="banner-pick">' + bannerPicks + "</div>" +
    '<p class="hint mt-1">In production, banners upload to Cloudinary. The demo ships with a bundled library.</p></div>' +
    '<div class="panel"><h3>🏆 Prizes</h3><div class="form-grid">' + prizeRow(1, "🥇 1st Prize") + prizeRow(2, "🥈 2nd Prize") + prizeRow(3, "🥉 3rd Prize") + "</div></div>" +
    '<div class="panel"><h3>📋 Rules <span class="muted small">(one per line)</span></h3><textarea id="ef_rules" rows="4" class="w100" style="padding:10px;border:1.5px solid var(--line);border-radius:11px">' + esc(e ? (e.rules || []).join("\n") : "") + '</textarea></div>' +
    '<div class="panel"><h3>📅 Schedule <span class="muted small">(one per line: time | activity)</span></h3><textarea id="ef_sched" rows="4" class="w100" style="padding:10px;border:1.5px solid var(--line);border-radius:11px" placeholder="09:00 AM | Registration&#10;10:00 AM | Opening ceremony">' + esc(e ? (e.schedule || []).map(function (s) { return s.time + " | " + s.label; }).join("\n") : "") + '</textarea></div>' +
    '<div class="panel"><h3>👥 Organizers <span class="muted small">(one per line: name | role)</span></h3><textarea id="ef_orgs" rows="3" class="w100" style="padding:10px;border:1.5px solid var(--line);border-radius:11px" placeholder="Prof. J. R. Kazi | Faculty Coordinator&#10;Sana Qureshi | Student Coordinator">' + esc(e ? (e.organizers || []).map(function (o) { return o.name + " | " + o.role; }).join("\n") : "") + '</textarea></div>' +
    '<div class="flex mt-3" style="justify-content:flex-end">' +
    (isNew ? '<button class="btn btn-ghost" onclick="saveEvent(true, false)">💾 Save Draft</button><button class="btn btn-primary" onclick="saveEvent(true, true)">🚀 Publish Event</button>' :
      '<button class="btn btn-ghost" onclick="saveEvent(false, ' + (e.published !== false ? "true" : "false") + ', ' + (e.published !== false ? "true" : "false") + ')">💾 Save changes</button>') +
    "</div>";
  return adminShell("/admin/events", content);
}
function pickBanner(img) {
  qsa(".banner-pick img").forEach(function (i) { i.classList.remove("sel"); });
  img.classList.add("sel");
}
function parseLines(val, map) {
  return val.split("\n").map(function (l) { return l.trim(); }).filter(Boolean).map(map).filter(Boolean);
}
function saveEvent(isNew, publish) {
  var title = qs("#ef_title").value.trim();
  var desc = qs("#ef_desc").value.trim();
  var venue = qs("#ef_venue").value.trim();
  var dstart = qs("#ef_dstart").value;
  if (!title || !desc || !venue || !dstart) {
    ["#ef_title", "#ef_desc", "#ef_venue", "#ef_dstart"].forEach(function (id) {
      var el = qs(id);
      el.closest(".field").classList.toggle("invalid", !el.value.trim());
    });
    return toast("Please fill all required fields", "err");
  }
  var banner = qs(".banner-pick img.sel");
  var selBanner = banner ? banner.getAttribute("data-src") : "assets/img/hero.jpg";
  var prizes = [1, 2, 3].map(function (pos) {
    var amt = parseInt(qs("#ef_prize" + pos).value, 10) || 0;
    var label = qs("#ef_plabel" + pos).value.trim();
    if (amt > 0 || label) return { pos: pos, amt: amt, label: label || undefined };
    return null;
  }).filter(Boolean);
  var ev = {
    id: isNew ? uid("e") : eventById(DB.__editingId).id,
    title: title, tagline: qs("#ef_tagline").value.trim(), desc: desc,
    cat: qs("#ef_cat").value, clubId: qs("#ef_club").value, venue: venue,
    dateStart: dstart, dateEnd: qs("#ef_dend").value || undefined,
    timeStart: qs("#ef_tstart").value || "09:00", timeEnd: qs("#ef_tend").value || "17:00",
    regDeadline: qs("#ef_regd").value || dstart,
    fee: parseInt(qs("#ef_fee").value, 10) || 0,
    maxPart: parseInt(qs("#ef_max").value, 10) || 100,
    teamMin: parseInt(qs("#ef_tmin").value, 10) || 1,
    teamMax: parseInt(qs("#ef_tmax").value, 10) || 4,
    eligibility: qs("#ef_elig").value.trim(),
    banner: selBanner, prizes: prizes,
    rules: qs("#ef_rules").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean),
    schedule: parseLines(qs("#ef_sched").value, function (l) {
      var parts = l.split("|");
      return parts.length >= 2 ? { time: parts[0].trim(), label: parts[1].trim() } : { time: "TBA", label: parts[0].trim() };
    }),
    organizers: parseLines(qs("#ef_orgs").value, function (l) {
      var parts = l.split("|");
      return { name: (parts[0] || "").trim() || "Coordinator", role: (parts[1] || "").trim() || "Organizer" };
    }),
    published: publish, resultsPublished: false, baseRegs: isNew ? 0 : (eventById(DB.__editingId).baseRegs || 0)
  };
  if (isNew) DB.events.push(ev);
  else {
    var idx = DB.events.findIndex(function (x) { return x.id === DB.__editingId; });
    DB.events[idx] = ev;
  }
  saveDB();
  toast(isNew ? (publish ? "Event published 🚀" : "Draft saved 💾") : "Event updated ✓", "ok");
  location.hash = "#/admin/events";
}

/* ═══════════════ REGISTRATIONS MANAGER ═══════════════ */
var ARF = { event: "All" };
function adminRegistrations(params) {
  if (params && params.event) ARF.event = params.event;
  var evOpts = '<option>All</option>' + DB.events.map(function (e) { return "<option value='" + e.id + "' " + (ARF.event === e.id ? "selected" : "") + ">" + esc(e.title) + "</option>"; }).join("");
  var content =
    '<h1 class="page-title">Registrations</h1><p class="page-sub">Track, mark attendance and export participant data.</p>' +
    '<div class="admin-toolbar mt-2">' +
    '<select style="padding:10px 14px;border-radius:11px;border:1px solid var(--line);font-weight:600;min-width:260px" onchange="ARF.event=this.value;route(\'#/admin/registrations\')">' + evOpts + "</select>" +
    '<div class="flex"><button class="btn btn-ghost btn-sm" onclick="exportRegsCSV()">⬇ Export CSV</button>' +
    '<span class="badge badge-blue" id="regCount"></span></div></div>' +
    '<div id="regsTableWrap"></div>';
  setTimeout(renderRegsTable, 0);
  return adminShell("/admin/registrations", content);
}
function currentRegs() {
  return DB.registrations.filter(function (r) {
    if (ARF.event !== "All" && r.eventId !== ARF.event) return false;
    return true;
  });
}
function renderRegsTable() {
  var wrap = qs("#regsTableWrap");
  if (!wrap) return;
  var regs = currentRegs().slice().reverse();
  var countEl = qs("#regCount");
  if (countEl) countEl.textContent = regs.length + " registrations";
  wrap.innerHTML = regs.length ?
    '<div class="table-wrap"><table class="data"><thead><tr><th>Reg. ID</th><th>Participant</th><th>PRN / Branch / Year</th><th>Event</th><th>Type</th><th>Paid</th><th>Attended</th><th></th></tr></thead><tbody>' +
    regs.map(function (r) {
      var e = eventById(r.eventId);
      return "<tr><td class='mono'>" + r.id + "</td><td><div class='t-main'>" + esc(r.name) + "</div><div class='t-sub'>" + esc(r.email) + "</div></td>" +
        "<td>" + esc(r.prn) + "<div class='t-sub'>" + esc(r.branch) + " · " + esc(r.year) + "</div></td>" +
        "<td>" + esc(e ? e.title : "—") + "</td>" +
        "<td>" + (r.type === "team" ? "👥 " + esc(r.teamName) + (r.members.length ? "<div class='t-sub'>+" + r.members.length + " member(s)</div>" : "") : "👤") + "</td>" +
        "<td><label class='switch'><input type='checkbox' " + (r.paid ? "checked" : "") + " onchange='toggleReg(\"" + r.id + "\",\"paid\",this.checked)'><i></i></label></td>" +
        "<td><label class='switch'><input type='checkbox' " + (r.attended ? "checked" : "") + " onchange='toggleReg(\"" + r.id + "\",\"attended\",this.checked)'><i></i></label></td>" +
        "<td><button class='icon-btn del' onclick='deleteReg(\"" + r.id + "\")'>🗑</button></td></tr>";
    }).join("") + "</tbody></table></div>"
    : emptyState("📝", "No registrations", "They will appear as students register.");
}
function toggleReg(id, field, val) {
  var r = DB.registrations.find(function (x) { return x.id === id; });
  if (r) { r[field] = val; saveDB(); toast(r.name + " — " + field + " updated", "ok"); }
}
function deleteReg(id) {
  DB.registrations = DB.registrations.filter(function (r) { return r.id !== id; });
  saveDB(); renderRegsTable(); toast("Registration removed", "info");
}
function exportRegsCSV() {
  var regs = currentRegs();
  if (!regs.length) return toast("Nothing to export", "err");
  var rows = [["Reg ID", "Event", "Name", "Email", "Phone", "PRN", "Branch", "Year", "Type", "Team", "Members", "Fee", "Paid", "Attended", "Date"]];
  regs.forEach(function (r) {
    var e = eventById(r.eventId);
    rows.push([r.id, e ? e.title : "", r.name, r.email, r.phone, r.prn, r.branch, r.year, r.type, r.teamName, (r.members || []).join("; "), r.fee, r.paid ? "Yes" : "No", r.attended ? "Yes" : "No", r.date]);
  });
  downloadCSV("mhssce-eventhub-registrations.csv", rows);
}

/* ═══════════════ USERS MANAGER ═══════════════ */
var UF = "";
function adminUsers() {
  var u = currentUser();
  var content =
    '<h1 class="page-title">Users</h1><p class="page-sub">' + DB.users.length + " registered accounts — students, organizers and admins.</p>" +
    '<div class="admin-toolbar mt-2"><div class="search-box" style="flex:1;position:relative"><input placeholder="Search name / email / PRN…" style="width:100%;padding:10px 14px;border-radius:11px;border:1px solid var(--line)" oninput="UF=this.value;renderUsersTable()"></div>' +
    '<span class="badge badge-blue">' + DB.users.filter(function (x) { return x.role === "student"; }).length + ' students</span></div>' +
    '<div id="usersWrap"></div>' +
    '<div class="note-box mt-3"><span>🔐</span><span>Roles: <b>Student</b> — browse & register · <b>Organizer</b> — manage events & results · <b>Admin</b> — full control. Staff accounts are pre-provisioned by the college.</span></div>';
  setTimeout(renderUsersTable, 0);
  return adminShell("/admin/users", content);
}
function renderUsersTable() {
  var wrap = qs("#usersWrap");
  if (!wrap) return;
  var me = currentUser();
  var list = DB.users.filter(function (x) {
    if (!UF) return true;
    var q = UF.toLowerCase();
    return (x.name + x.email + x.prn + x.branch).toLowerCase().indexOf(q) >= 0;
  });
  wrap.innerHTML = '<div class="table-wrap"><table class="data"><thead><tr><th>User</th><th>PRN / Branch / Year</th><th>Role</th><th>Registrations</th><th></th></tr></thead><tbody>' +
    list.map(function (x) {
      var regs = DB.registrations.filter(function (r) { return r.userId === x.id; }).length;
      return "<tr><td><div class='flex'><span class='avatar' style='width:34px;height:34px;font-size:12px'>" + initials(x.name) + "</span><div><div class='t-main'>" + esc(x.name) + "</div><div class='t-sub'>" + esc(x.email) + "</div></div></div></td>" +
        "<td>" + esc(x.prn || "—") + "<div class='t-sub'>" + esc(x.branch || "—") + " · " + esc(x.year || "—") + "</div></td>" +
        "<td><select style='padding:7px 10px;border-radius:9px;border:1px solid var(--line);font-weight:600' onchange='changeRole(\"" + x.id + "\",this.value)' " + (x.id === me.id ? "disabled" : "") + ">" +
        ["student", "organizer", "admin"].map(function (r) { return "<option value='" + r + "' " + (x.role === r ? "selected" : "") + ">" + r + "</option>"; }).join("") + "</select></td>" +
        "<td>" + regs + "</td>" +
        "<td>" + (x.id !== me.id ? "<button class='icon-btn del' onclick='deleteUser(\"" + x.id + "\")'>🗑</button>" : "<span class='badge badge-blue'>You</span>") + "</td></tr>";
    }).join("") + "</tbody></table></div>";
}
function changeRole(id, role) {
  var u = userById(id);
  if (!u) return;
  u.role = role;
  saveDB();
  toast(u.name + " is now " + role, "ok");
}
function deleteUser(id) {
  var u = userById(id);
  openModal(modalHead("Delete user?", esc(u.name)) +
    '<div class="modal-body"><p class="muted">The account and its registrations will be removed.</p></div>' +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-danger" onclick="confirmDeleteUser(\'' + id + '\')">Delete</button></div>', 440);
}
function confirmDeleteUser(id) {
  DB.users = DB.users.filter(function (x) { return x.id !== id; });
  DB.registrations = DB.registrations.filter(function (r) { return r.userId !== id; });
  saveDB(); closeModal(); renderUsersTable();
  toast("User deleted", "info");
}

/* ═══════════════ RESULTS MANAGER ═══════════════ */
function adminResults() {
  var completed = DB.events.filter(function (e) {
    var k = getStatus(e).key;
    return e.published !== false && (k === "done" || k === "results" || k === "live");
  }).sort(function (a, b) { return evStart(b) - evStart(a); });
  var pending = completed.filter(function (e) { return !e.resultsPublished; });
  var published = completed.filter(function (e) { return e.resultsPublished; });
  var content =
    '<h1 class="page-title">Results & Winners</h1>' +
    '<p class="page-sub">Publishing results automatically awards leaderboard points and generates certificates for winners.</p>' +
    '<div class="panel mt-3"><h3>⏳ Awaiting results (' + pending.length + ')</h3>' +
    (pending.length ? pending.map(function (e) {
      return '<div class="flex-between" style="padding:11px 0;border-bottom:1px dashed var(--line)">' +
        '<div><b>' + esc(e.title) + "</b><div class='t-sub'>" + fmtDateRange(e) + " · " + joinedCount(e) + " registered</div></div>" +
        '<button class="btn btn-primary btn-sm" onclick="openResultsForm(\'' + e.id + '\')">Enter results →</button></div>';
    }).join("") : '<p class="muted">Nothing pending — every completed event has results. 🎉</p>') + "</div>" +
    '<div class="panel"><h3>✅ Published results (' + published.length + ')</h3>' +
    (published.length ? published.map(function (e) {
      var w = DB.results.find(function (r) { return r.eventId === e.id && r.pos === 1; });
      return '<div class="flex-between" style="padding:11px 0;border-bottom:1px dashed var(--line)">' +
        '<div><b>' + esc(e.title) + "</b><div class='t-sub'>🥇 " + (w ? esc(w.title) : "—") + "</div></div>" +
        '<div class="flex"><button class="btn btn-ghost btn-sm" onclick="openResultsForm(\'' + e.id + '\')">✏️ Edit</button>' +
        '<button class="btn btn-ghost btn-sm" onclick="unpublishResults(\'' + e.id + '\')">Unpublish</button></div></div>';
    }).join("") : '<p class="muted">No published results yet.</p>') + "</div>";
  return adminShell("/admin/results", content);
}
function openResultsForm(eventId) {
  var e = eventById(eventId);
  var existing = DB.results.filter(function (r) { return r.eventId === eventId && r.pos > 0; });
  var row = function (pos) {
    var r = existing.find(function (x) { return x.pos === pos; }) || {};
    return '<div class="field full"><label>' + (POS_MEDAL[pos] || "") + " " + POS_LABEL[pos] + '</label>' +
      '<div class="form-grid">' +
      '<input id="res_title' + pos + '" placeholder="Team / participant name" value="' + esc(r.title || "") + '">' +
      '<input id="res_members' + pos + '" placeholder="Members (comma separated)" value="' + esc((r.members || []).join(", ")) + '">' +
      '<input id="res_prize' + pos + '" type="number" placeholder="Prize ₹" value="' + (r.prize || "") + '">' +
      '<input id="res_project' + pos + '" placeholder="Project / note" value="' + esc(r.project || "") + '">' +
      "</div></div>";
  };
  openModal(
    modalHead("🏆 Results — " + esc(e.title), "Positions 1–3 get certificates + leaderboard points (100/70/50 per member).") +
    '<div class="modal-body"><div class="form-grid">' + row(1) + row(2) + row(3) +
    '<div class="field full"><label>🏅 Finalists / special mentions (optional — name + note)</label>' +
    '<div class="form-grid">' +
    '<input id="res_title0" placeholder="e.g. All finalists" value="' + esc((existing.find(function (x) { return x.pos === 0; }) || {}).title || "") + '">' +
    '<input id="res_project0" placeholder="Note" value="' + esc((existing.find(function (x) { return x.pos === 0; }) || {}).project || "") + '">' +
    "</div></div></div>" +
    '<div class="note-box mt-2"><span>⚡</span><span>Publishing replaces existing entries for this event and issues certificates automatically (Winner / Runner-up / Third Place).</span></div>' +
    "</div>" +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="publishResults(\'' + eventId + '\')">🚀 Publish results</button></div>', 760);
}
function publishResults(eventId) {
  var e = eventById(eventId);
  var newVal = [];
  [1, 2, 3, 0].forEach(function (pos) {
    var title = qs("#res_title" + pos).value.trim();
    if (!title) return;
    var members = pos > 0 ? qs("#res_members" + pos).value.split(",").map(function (s) { return s.trim(); }).filter(Boolean) : [];
    var prize = parseInt(qs("#res_prize" + pos).value, 10) || 0;
    var project = qs("#res_project" + pos).value.trim();
    newVal.push({ id: uid("r"), eventId: eventId, pos: pos, title: title, type: members.length > 1 ? "team" : "individual", members: members, prize: prize, project: project });
  });
  if (!newVal.some(function (r) { return r.pos === 1; })) return toast("The Winner (1st place) entry is required", "err");
  DB.results = DB.results.filter(function (r) { return r.eventId !== eventId; }).concat(newVal);
  e.resultsPublished = true;
  // auto certificates for top 3
  var today = new Date().toISOString().slice(0, 10);
  newVal.forEach(function (r) {
    if (r.pos === 0 || !r.members.length) return;
    r.members.forEach(function (m) {
      var u = DB.users.find(function (x) { return x.name.toLowerCase() === m.toLowerCase() && x.role === "student"; });
      DB.certificates.push({
        id: "CERT-2026-" + (DB.meta.certSeq++),
        eventId: eventId, userId: u ? u.id : null, name: m,
        achievement: POS_LABEL[r.pos], date: today
      });
    });
  });
  saveDB(); closeModal(); route();
  toast("Results published — certificates generated 🏆", "ok");
}
function unpublishResults(eventId) {
  var e = eventById(eventId);
  e.resultsPublished = false;
  saveDB(); route();
  toast("Results unpublished for " + e.title, "info");
}

/* ═══════════════ CERTIFICATES MANAGER ═══════════════ */
function adminCertificates() {
  var content =
    '<div class="admin-toolbar"><div><h1 class="page-title">Certificates</h1><p class="page-sub">' + DB.certificates.length + " certificates issued · all publicly verifiable</p></div>" +
    '<button class="btn btn-primary" onclick="openIssueCert()">➕ Issue certificate</button></div>' +
    '<div class="table-wrap"><table class="data"><thead><tr><th>Certificate ID</th><th>Name</th><th>Event</th><th>Achievement</th><th>Issued</th><th></th></tr></thead><tbody>' +
    DB.certificates.slice().reverse().map(function (c) {
      var e = eventById(c.eventId);
      return "<tr><td class='mono t-main'>" + c.id + "</td><td>" + esc(c.name) + "</td><td>" + esc(e ? e.title : "—") + "</td>" +
        "<td><span class='badge badge-gold'>" + esc(c.achievement) + "</span></td><td>" + fmtDate(c.date) + "</td>" +
        "<td><div class='flex' style='gap:6px'><button class='icon-btn' title='View' onclick='openCertificate(\"" + c.id + "\")'>👁</button>" +
        "<button class='icon-btn del' title='Revoke' onclick='revokeCert(\"" + c.id + "\")'>🗑</button></div></td></tr>";
    }).join("") + "</tbody></table></div>";
  return adminShell("/admin/certificates", content);
}
function openIssueCert() {
  var evOpts = DB.events.map(function (e) { return "<option value='" + e.id + "'>" + esc(e.title) + "</option>"; }).join("");
  openModal(
    modalHead("🎖 Issue a certificate", "The recipient can verify it publicly via its ID.") +
    '<div class="modal-body"><div class="form-grid">' +
    '<div class="field full"><label>Event <span class="req">*</span></label><select id="ic_event">' + evOpts + "</select></div>" +
    '<div class="field full"><label>Recipient name <span class="req">*</span></label><input id="ic_name" list="userNames" placeholder="Student name"><datalist id="userNames">' +
    DB.users.map(function (u) { return "<option value='" + esc(u.name) + "'>"; }).join("") + "</datalist></div>" +
    '<div class="field"><label>Achievement</label><select id="ic_ach">' + ["Winner", "Runner-up", "Third Place", "Finalist", "Participant"].map(function (a) { return "<option>" + a + "</option>"; }).join("") + "</select></div>" +
    '<div class="field"><label>Issue date</label><input id="ic_date" type="date" value="' + new Date().toISOString().slice(0, 10) + '"></div>' +
    "</div></div>" +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="issueCert()">Issue →</button></div>', 560);
}
function issueCert() {
  var name = qs("#ic_name").value.trim();
  if (name.length < 3) return toast("Recipient name is required", "err");
  var u = DB.users.find(function (x) { return x.name.toLowerCase() === name.toLowerCase(); });
  var cert = {
    id: "CERT-2026-" + (DB.meta.certSeq++),
    eventId: qs("#ic_event").value,
    userId: u ? u.id : null,
    name: name,
    achievement: qs("#ic_ach").value,
    date: qs("#ic_date").value || new Date().toISOString().slice(0, 10)
  };
  DB.certificates.push(cert);
  saveDB(); closeModal(); route();
  toast("Certificate issued — " + cert.id, "ok");
}
function revokeCert(id) {
  DB.certificates = DB.certificates.filter(function (c) { return c.id !== id; });
  saveDB(); route(); toast("Certificate revoked", "info");
}

/* ═══════════════ GALLERY MANAGER ═══════════════ */
function adminGallery() {
  var evOpts = '<option value="">— General / no event —</option>' + DB.events.map(function (e) { return "<option value='" + e.id + "'>" + esc(e.title) + "</option>"; }).join("");
  var content =
    '<h1 class="page-title">Gallery</h1><p class="page-sub">' + DB.gallery.length + ' photos live on the public gallery.</p>' +
    '<div class="panel mt-3"><h3>➕ Add photo</h3><div class="form-grid">' +
    '<div class="field full"><label>Image</label><div class="banner-pick">' +
    IMG_LIBRARY.map(function (im, i) {
      return "<img src='" + A(im.src) + "' data-src='" + im.src + "' title='" + esc(im.label) + "' onclick='pickGImg(this)' class='" + (i === 0 ? "sel" : "") + "'>";
    }).join("") + "</div></div>" +
    '<div class="field"><label>Event</label><select id="ga_event">' + evOpts + "</select></div>" +
    '<div class="field"><label>Caption</label><input id="ga_cap" placeholder="e.g. Final round moments"></div>' +
    "</div><button class='btn btn-primary mt-2' onclick='addGalleryItem()'>Add to gallery →</button></div>" +
    '<div class="mt-3 gallery-grid">' +
    DB.gallery.map(function (g) {
      var e = eventById(g.eventId);
      return '<div style="position:relative" class="g-item"><img src="' + A(g.img) + '"><div class="g-cap" style="opacity:1;position:static;background:none;color:#94a3b8;padding:8px 2px;font-size:11.5px">' + esc(g.caption) + (e ? " · " + esc(e.title) : "") + '</div>' +
        '<button class="btn btn-danger btn-xs" style="position:absolute;top:8px;right:8px" onclick="delGalleryItem(\'' + g.id + '\')">🗑</button></div>';
    }).join("") + "</div>";
  return adminShell("/admin/gallery", content);
}
function pickGImg(img) {
  qsa(".banner-pick img").forEach(function (i) { i.classList.remove("sel"); });
  img.classList.add("sel");
}
function addGalleryItem() {
  var img = qs(".banner-pick img.sel");
  var cap = qs("#ga_cap").value.trim() || "Event moment";
  DB.gallery.push({ id: uid("g"), eventId: qs("#ga_event").value || null, img: img ? img.getAttribute("data-src") : "assets/img/hero.jpg", caption: cap });
  saveDB(); route();
  toast("Photo added to gallery 📸", "ok");
}
function delGalleryItem(id) {
  DB.gallery = DB.gallery.filter(function (g) { return g.id !== id; });
  saveDB(); route(); toast("Photo removed", "info");
}

/* ═══════════════ reset demo data ═══════════════ */
function resetDemoData() {
  openModal(modalHead("Reset demo data?", "Everything (registrations, new users, published results) goes back to the original seed.") +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-danger" onclick="confirmReset()">Reset everything</button></div>', 460);
}
function confirmReset() {
  store.remove("eh_db_v3");
  store.remove("eh_session");
  location.hash = "#/";
  setTimeout(function () { location.reload(); }, 150);
}
