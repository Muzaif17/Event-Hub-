/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — App core: state, session, router, boot
   ═══════════════════════════════════════════════════════════════ */

const DB_KEY = "eh_db_v3";
const SESSION_KEY = "eh_session";
let DB = null;

function loadDB() {
  try {
    var raw = store.get(DB_KEY);
    if (raw) {
      var parsed = JSON.parse(raw);
      if (parsed && parsed.version === 3) { DB = parsed; return; }
    }
  } catch (e) { /* fall through to seed */ }
  DB = seedDB();
  saveDB();
}
function saveDB() {
  try { store.set(DB_KEY, JSON.stringify(DB)); } catch (e) { /* quota */ }
}

/* ---------- session ---------- */
function currentUser() {
  var id = store.get(SESSION_KEY);
  if (!id) return null;
  return DB.users.find(function (u) { return u.id === id; }) || null;
}
function setSession(userId) {
  store.set(SESSION_KEY, userId);
  renderNavSession();
}
function logout() {
  store.remove(SESSION_KEY);
  renderNavSession();
  toast("Logged out — see you at the next event! 👋", "info");
  location.hash = "#/";
  route();
}

/* ---------- router ---------- */
var ROUTES = [
  [/^\/?$/, function () { return pageHome(); }],
  [/^\/events$/, function (q) { return pageEvents(q); }],
  [/^\/event\/([\w-]+)$/, function (q, m) { return pageEventDetail(m[1]); }],
  [/^\/results$/, function (q) { return pageResults(q); }],
  [/^\/participants\/([\w-]+)$/, function (q, m) { return pageParticipants(m[1]); }],
  [/^\/archive$/, function () { return pageArchive(); }],
  [/^\/gallery$/, function (q) { return pageGallery(q); }],
  [/^\/leaderboard$/, function () { return pageLeaderboard(); }],
  [/^\/clubs$/, function () { return pageClubs(); }],
  [/^\/club\/([\w-]+)$/, function (q, m) { return pageClubDetail(m[1]); }],
  [/^\/verify$/, function (q) { return pageVerify(q); }],
  [/^\/about$/, function () { return pageAbout(); }],
  [/^\/login$/, function (q) { return pageLogin(q); }],
  [/^\/dashboard$/, function (q) { return pageDashboard(q); }],
  [/^\/admin$/, function () { return pageAdmin("dashboard"); }],
  [/^\/admin\/([\w-]+)$/, function (q, m) { return pageAdmin(m[1], q); }]
];

function parseHash() {
  var h = location.hash.replace(/^#/, "") || "/";
  var qIdx = h.indexOf("?");
  var path = qIdx >= 0 ? h.slice(0, qIdx) : h;
  var query = {};
  if (qIdx >= 0) {
    h.slice(qIdx + 1).split("&").forEach(function (kv) {
      if (!kv) return;
      var p = kv.split("=");
      query[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || "");
    });
  }
  return { path: path, query: query };
}

function route() {
  var parts = parseHash();
  var path = parts.path, query = parts.query;
  var app = qs("#app");

  /* guards */
  if (path.indexOf("/admin") === 0) {
    var u = currentUser();
    if (!u || (u.role !== "admin" && u.role !== "organizer")) {
      toast(u ? "You need an organizer/admin account to open the panel" : "Please login with an organizer or admin account", "err");
      PENDING_REG = null;
      location.hash = "#/login";
      return;
    }
  }
  if (path === "/dashboard" && !currentUser()) {
    toast("Login to view your dashboard", "info");
    location.hash = "#/login";
    return;
  }

  var html = null;
  for (var i = 0; i < ROUTES.length; i++) {
    var m = path.match(ROUTES[i][0]);
    if (m) { html = ROUTES[i][1](query, m); break; }
  }
  if (html == null) html = page404();

  app.innerHTML = '<div class="page">' + html + "</div>";

  /* nav active state */
  qsa("#navLinks > a").forEach(function (a) {
    var p = a.getAttribute("data-nav");
    a.classList.toggle("active", p === "/" ? path === "/" : path.indexOf(p) === 0);
  });

  /* post-render hooks */
  if (window.__afterRender) { var fn = window.__afterRender; window.__afterRender = null; try { fn(); } catch (e) { console.error(e); } }
  initReveal();
  animateCounters();
  renderCountdowns();
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  qs("#navMobile").classList.remove("open");
}

/* ---------- navbar behaviour ---------- */
function initNavbar() {
  var burger = qs("#navBurger");
  var mobile = qs("#navMobile");
  var links = [
    ["#/", "🏠 Home"], ["#/events", "🎪 Events"], ["#/results", "🏆 Results"], ["#/clubs", "🤝 Clubs"],
    ["#/archive", "📕 Archive"], ["#/gallery", "📸 Gallery"], ["#/leaderboard", "🏅 Leaderboard"],
    ["#/verify", "🛡️ Verify Certificate"], ["#/about", "ℹ️ About"]
  ];
  mobile.innerHTML = links.map(function (l) { return '<a href="' + l[0] + '">' + l[1] + "</a>"; }).join("");
  burger.addEventListener("click", function () { mobile.classList.toggle("open"); });
  mobile.addEventListener("click", function (ev) { if (ev.target.tagName === "A") mobile.classList.remove("open"); });
}

/* ---------- boot ---------- */
function boot() {
  loadDB();
  /* anchor the always-live demo event to "now" on each fresh session */
  var live = DB.events.find(function (e) { return e.liveDemo; });
  if (live && (Date.now() > live.endMs || Date.now() < live.startMs - 6 * 3600e3)) {
    live.startMs = Date.now() - 45 * 60e3;
    live.endMs = Date.now() + 135 * 60e3;
    live.regCloseMs = Date.now() - 60 * 60e3;
    saveDB();
  }
  initNavbar();
  renderNavSession();
  window.addEventListener("hashchange", route);
  route();
  setInterval(renderCountdowns, 1000);
}
document.addEventListener("DOMContentLoaded", boot);
