/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — Shared components
   ═══════════════════════════════════════════════════════════════ */

function clubOf(id) { return DB.clubs.find(function (c) { return c.id === id; }); }
function clubName(id) { var c = clubOf(id); return c ? c.name : "—"; }
function eventById(id) { return DB.events.find(function (e) { return e.id === id; }); }
function userById(id) { return DB.users.find(function (u) { return u.id === id; }); }

/* ---------- section header ---------- */
function sectionHead(kicker, title, sub, link) {
  return '<div class="section-head reveal"><div><span class="kicker">' + kicker + '</span><h2>' + title + "</h2>" + (sub ? "<p>" + sub + "</p>" : "") + '</div>' + (link || "") + "</div>";
}

/* ---------- empty state ---------- */
function emptyState(icon, title, sub, action) {
  return '<div class="empty"><div class="e-ico">' + icon + "</div><b>" + title + "</b><span class='muted'>" + sub + "</span>" + (action ? '<div class="mt-2">' + action + "</div>" : "") + "</div>";
}

/* ---------- event card ---------- */
function eventCard(e) {
  var club = clubOf(e.clubId);
  var st = getStatus(e);
  var joined = joinedCount(e);
  var pct = e.maxPart ? Math.min(100, Math.round(joined / e.maxPart * 100)) : 0;
  var cta;
  if (st.key === "live") cta = '<a class="btn btn-danger btn-sm" href="#/event/' + e.id + '">🔴 View Live</a>';
  else if (st.key === "results") cta = '<a class="btn btn-ghost btn-sm" href="#/results">🏆 Results</a>';
  else if (st.key === "done") cta = '<a class="btn btn-ghost btn-sm" href="#/participants/' + e.id + '">Participants</a>';
  else if (st.key === "closed") cta = '<a class="btn btn-ghost btn-sm" href="#/event/' + e.id + '">View Details</a>';
  else cta = '<button class="btn btn-primary btn-sm" onclick="startRegistration(\'' + e.id + '\')">Register →</button>';

  var dateLine = st.key === "live"
    ? "🔴 Live now"
    : (st.key === "done" || st.key === "results") ? "🏁 " + fmtDate(e.dateStart || e.startMs) : "📅 " + fmtDateRange(e);

  return (
    '<article class="event-card reveal">' +
    '<div class="ec-banner"><img src="' + A(e.banner) + '" alt="' + esc(e.title) + '" loading="lazy">' +
    '<div class="ec-top">' + badgeHTML(e) +
    '<span class="badge badge-blue">' + esc(e.cat) + "</span></div></div>" +
    '<div class="ec-body">' +
    '<span class="ec-cat">' + (club ? club.emoji + " " + esc(club.name) : "") + "</span>" +
    '<h3 class="ec-title"><a href="#/event/' + e.id + '">' + esc(e.title) + "</a></h3>" +
    '<div class="ec-date-row"><span>' + dateLine + "</span><span>📍 " + esc(e.venue.split(",")[0]) + "</span></div>" +
    '<div class="ec-bar" title="' + pct + '% full"><i style="width:' + pct + '%"></i></div>' +
    '<div class="ec-foot"><span class="ec-fee ' + (!e.fee ? "free" : "") + '">' + fmtMoney(e.fee) + (e.fee ? (e.teamMin > 1 ? ' <small class="muted">/team</small>' : "") : "") +
    '</span><span class="ec-joined">👥 ' + joined + " joined</span>" + cta + "</div>" +
    "</div></article>"
  );
}

/* ---------- winner / result cards ---------- */
function winnerCard(res, ev) {
  var medal = POS_MEDAL[res.pos] || "🏅";
  var label = POS_LABEL[res.pos] || "Finalist";
  var placeCls = res.pos === 1 ? "p1" : res.pos === 2 ? "p2" : res.pos === 3 ? "p3" : "";
  return (
    '<div class="winner-card reveal ' + placeCls + '">' +
    '<div class="wc-head"><small>' + esc(label) + " · " + fmtDate(ev.dateStart || ev.startMs) + "</small><h3>" + esc(ev.title) + "</h3></div>" +
    '<div class="wc-body">' +
    '<div class="wc-place"><span class="medal ' + (res.pos <= 3 ? "m" + res.pos : "") + '">' + medal + "</span><span>" + esc(res.title) + "</span></div>" +
    (res.members && res.members.length ? '<div class="wc-members"><b>Members:</b> ' + res.members.map(esc).join(" · ") + "</div>" : "") +
    (res.project ? '<div class="wc-members"><b>Project:</b> ' + esc(res.project) + "</div>" : "") +
    '<div class="wc-prize"><span>Prize</span><b>' + (res.prize > 0 ? "₹" + res.prize.toLocaleString("en-IN") : "Glory 🏆") + "</b></div>" +
    '<div class="mt-2 flex-between"><a class="btn btn-ghost btn-sm" href="#/participants/' + ev.id + '">👥 Participants</a>' +
    '<button class="btn btn-ghost btn-sm" onclick="shareEvent(\'' + ev.id + '\')">🔗 Share</button></div>' +
    "</div></div>"
  );
}

/* ---------- club card ---------- */
function clubCard(c) {
  var evCount = DB.events.filter(function (e) { return e.clubId === c.id && e.published !== false; }).length;
  return (
    '<article class="club-card reveal">' +
    '<div class="club-logo">' + c.emoji + "</div>" +
    "<h3>" + esc(c.name) + "</h3>" +
    "<p>" + esc(c.tagline) + "</p>" +
    '<div class="club-stats"><div><b>' + evCount + '</b>Events</div><div><b>' + c.members + "</b>Members</div></div>" +
    '<div class="mt-2"><a class="btn btn-ghost btn-sm btn-block" href="#/club/' + c.id + '">View Club →</a></div>' +
    "</article>"
  );
}

/* ---------- participants of an event (with result lookup) ---------- */
function participantsOf(evId) {
  return DB.registrations.filter(function (r) { return r.eventId === evId; });
}
function resultLabelForName(evId, name) {
  var res = DB.results.filter(function (r) { return r.eventId === evId && r.pos > 0; });
  for (var i = 0; i < res.length; i++) {
    var list = res[i].members || [];
    for (var j = 0; j < list.length; j++) {
      if (list[j].toLowerCase() === String(name).toLowerCase()) {
        return (POS_MEDAL[res[i].pos] || "") + " " + (POS_LABEL[res[i].pos] || "Finalist");
      }
    }
  }
  return "Participant";
}
function participantsTable(ev) {
  var regs = participantsOf(ev.id);
  return (
    '<div class="table-wrap"><table class="data"><thead><tr>' +
    "<th>#</th><th>Participant</th><th>Branch</th><th>Year</th><th>Result</th></tr></thead><tbody>" +
    regs.map(function (r, i) {
      return "<tr><td class='muted'>" + (i + 1) + "</td>" +
        "<td class='t-main'>" + esc(r.name) + (r.teamName ? "<div class='t-sub'>Team: " + esc(r.teamName) + "</div>" : "") + "</td>" +
        "<td>" + esc(r.branch) + "</td><td>" + esc(r.year) + "</td>" +
        "<td>" + (ev.resultsPublished ? esc(resultLabelForName(ev.id, r.name)) : "<span class='muted'>—</span>") + "</td></tr>";
    }).join("") +
    "</tbody></table></div>"
  );
}

/* ---------- share ---------- */
function shareEvent(id) {
  var url = location.origin + location.pathname + "#/event/" + id;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(function () { toast("Event link copied to clipboard", "ok"); })
      .catch(function () { toast(url, "info"); });
  } else toast(url, "info");
}

/* ---------- lightbox ---------- */
let LB_ITEMS = [], LB_IDX = 0;
function openLightbox(items, idx) {
  LB_ITEMS = items; LB_IDX = idx;
  renderLightbox();
}
function renderLightbox() {
  var it = LB_ITEMS[LB_IDX];
  if (!it) return closeLightbox();
  var root = qs("#modalRoot");
  root.innerHTML =
    '<div class="lightbox" onclick="if(event.target===this)closeLightbox()">' +
    '<button class="lb-close" onclick="closeLightbox()">✕</button>' +
    '<button class="lb-nav lb-prev" onclick="lbStep(-1)">←</button>' +
    '<img src="' + A(it.img) + '" alt=""><div class="lb-cap">📸 ' + esc(it.caption || "") + " — " + (LB_IDX + 1) + "/" + LB_ITEMS.length + "</div>" +
    '<button class="lb-nav lb-next" onclick="lbStep(1)">→</button></div>';
  document.body.style.overflow = "hidden";
}
function lbStep(d) { LB_IDX = (LB_IDX + d + LB_ITEMS.length) % LB_ITEMS.length; renderLightbox(); }
function closeLightbox() {
  var lb = qs(".lightbox");
  if (lb) { lb.remove(); if (!qs(".modal-overlay")) document.body.style.overflow = ""; }
}

/* ---------- navbar session area ---------- */
function renderNavSession() {
  var box = qs("#navRight");
  var u = currentUser();
  if (!u) {
    box.innerHTML = '<a class="btn btn-ghost btn-sm" href="#/verify">🛡️ Verify</a><a class="btn btn-dark btn-sm" href="#/login">Login / Sign up</a>';
  } else {
    var staff = u.role === "admin" || u.role === "organizer";
    box.innerHTML =
      '<div class="user-chip" id="userChip">' +
      '<span class="avatar">' + initials(u.name) + "</span>" +
      "<span><b>" + esc(u.name.split(" ")[0]) + "</b><small>" + esc(u.role) + "</small></span></div>";
    var menu = document.createElement("div");
    menu.className = "user-menu";
    menu.id = "userMenu";
    menu.style.display = "none";
    menu.innerHTML =
      '<a href="#/dashboard">📊 My Dashboard</a>' +
      '<a href="#/dashboard?tab=certs">🏆 My Certificates</a>' +
      (staff ? '<hr><a href="#/admin">🛠️ ' + (u.role === "admin" ? "Admin" : "Organizer") + " Panel</a>" : "") +
      "<hr><button class='danger' onclick=\"logout()\">↩ Logout</button>";
    qs("#userChip").after(menu);
    qs("#userChip").addEventListener("click", function (ev) {
      ev.stopPropagation();
      var m = qs("#userMenu");
      m.style.display = m.style.display === "none" ? "block" : "none";
    });
    document.addEventListener("click", function (ev) {
      var m = qs("#userMenu");
      if (!m) return;
      var chip = qs("#userChip");
      if (m.style.display === "block" && chip && !chip.contains(ev.target) && !m.contains(ev.target)) m.style.display = "none";
    });
  }
}
