/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — Seed Database (demo data)
   Mirrors the backend MongoDB collections described in the spec:
   USERS, EVENTS, REGISTRATIONS, RESULTS, CLUBS, GALLERY, CERTIFICATES
   ═══════════════════════════════════════════════════════════════ */

const BRANCHES = [
  "Computer Engineering", "Information Technology", "AI & Data Science",
  "Mechanical Engineering", "Civil Engineering", "Electrical Engineering", "Electronics & Telecom"
];
const YEARS = ["FE", "SE", "TE", "BE"];
const YEAR_FULL = { FE: "First Year", SE: "Second Year", TE: "Third Year", BE: "Final Year" };
const CATEGORIES = ["Technical", "Hackathon", "Workshop", "Seminar", "Cultural", "Sports"];
const POINTS = { 1: 100, 2: 70, 3: 50, finalist: 40, participation: 10 };
const POS_MEDAL = { 1: "🥇", 2: "🥈", 3: "🥉" };
const POS_LABEL = { 1: "Winner", 2: "Runner-up", 3: "Third Place", 0: "Finalist" };

function seedDB() {
  const now = Date.now();
  const H = 3600e3, D = 86400e3;
  const iso = (y, m, d) => y + "-" + String(m).padStart(2, "0") + "-" + String(d).padStart(2, "0");

  const clubs = [
    { id: "c1", emoji: "💻", name: "Coding Club", tagline: "Code. Compete. Conquer.", about: "The Coding Club is the beating heart of the technical community at MHSSCE. We run hackathons, weekly programming contests, open-source sprints and peer-learning bootcamps for students of every branch and every skill level.", faculty: "Prof. J. R. Kazi", studentCoord: "Sana Qureshi", events: 18, members: 310, color: "#1d5bd8" },
    { id: "c2", emoji: "🤖", name: "Robotics Club", tagline: "Machines with a mission.", about: "From line-follower bots to 15kg combat robots, the Robotics Club designs, builds and battles. We host Robo War, drone workshops and represent MHSSCE at national techfests.", faculty: "Prof. S. Z. Ansari", studentCoord: "Rehan Patel", events: 12, members: 240, color: "#e5484d" },
    { id: "c3", emoji: "🎭", name: "Cultural Committee", tagline: "Where talent meets the stage.", about: "The Cultural Committee brings music, dance, drama and art to campus. Aawaaz, our annual cultural night, is the most loved event of the college calendar.", faculty: "Prof. N. B. Sayyed", studentCoord: "Fatima Ansari", events: 20, members: 480, color: "#7048e8" },
    { id: "c4", emoji: "🏆", name: "Sports Committee", tagline: "Play hard, play fair.", about: "Khel Mahotsav, inter-college cricket, football, chess and carrom — the Sports Committee keeps the campus energy high all year round.", faculty: "Prof. P. V. Deshmukh", studentCoord: "Aditya Deshmukh", events: 15, members: 390, color: "#12b76a" },
    { id: "c5", emoji: "💼", name: "E-Cell MHSSCE", tagline: "Dream. Pitch. Launch.", about: "The Entrepreneurship Cell nurtures startup ambitions through ideathons, pitch days, founder talks and incubation support.", faculty: "Prof. R. M. Shaikh", studentCoord: "Yash Kulkarni", events: 8, members: 150, color: "#f59e0b" },
    { id: "c6", emoji: "🧠", name: "AI & Innovation Forum", tagline: "Building the future, today.", about: "A student forum for AI, data science and emerging tech — research talks, paper reading groups, AI seminars and innovation challenges.", faculty: "Dr. A. R. Merchant", studentCoord: "Zoya Khan", events: 9, members: 180, color: "#0ea5e9" }
  ];

  const events = [
    /* ── 🔴 LIVE NOW (demo — anchored to current time so it is always live) ── */
    {
      id: "e-live", title: "CodeStorm 2026", tagline: "3-hour live programming battle", cat: "Technical", clubId: "c1",
      venue: "Computer Lab 3, MHSSCE Campus", fee: 0, maxPart: 120, teamMin: 1, teamMax: 2,
      eligibility: "Open to all MHSSCE students", banner: "assets/img/hackathon.jpg", published: true, resultsPublished: false,
      liveDemo: true, startMs: now - 45 * 60e3, endMs: now + 135 * 60e3, regCloseMs: now - 60 * 60e3,
      baseRegs: 86,
      desc: "CodeStorm is a fast-paced, adrenaline-filled programming competition happening right now in Computer Lab 3. Teams of two race through algorithmic puzzles, debugging duels and a surprise lightning round. Live leaderboard, live commentary, and glory for the top three teams.",
      prizes: [{ pos: 1, amt: 5000 }, { pos: 2, amt: 2500 }, { pos: 3, amt: 1000 }],
      rules: ["Teams of maximum 2 members.", "Any language is allowed; judges' decision is final.", "No internet access during the contest rounds.", "Plagiarism leads to instant disqualification."],
      schedule: [{ time: "11:15 AM", label: "Reporting & on-spot registration" }, { time: "11:45 AM", label: "Round 1 — Algorithm Sprint" }, { time: "12:45 PM", label: "Round 2 — Debugging Duel" }, { time: "01:30 PM", label: "Lightning Round" }, { time: "02:15 PM", label: "Results & prizes" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }, { name: "Sana Qureshi", role: "Student Coordinator" }, { name: "Aarav Sharma", role: "Contest Admin" }]
    },

    /* ── 🟢 UPCOMING ── */
    {
      id: "e1", title: "Hackathon 2026", tagline: "Build • Innovate • Solve", cat: "Hackathon", clubId: "c1",
      venue: "Seminar Hall & Computer Labs, MHSSCE Campus", dateStart: iso(2026, 9, 20), dateEnd: iso(2026, 9, 21),
      timeStart: "09:00", timeEnd: "18:00", regDeadline: iso(2026, 9, 18),
      fee: 100, maxPart: 150, teamMin: 2, teamMax: 4, eligibility: "Students of all branches & years",
      banner: "assets/img/hackathon.jpg", published: true, resultsPublished: false, baseRegs: 125,
      desc: "The flagship 2-day hackathon of MHSSCE. Teams of 2–4 students pick a real-world problem statement and build a working prototype in 24 hours — web, mobile, AI, IoT, hardware, anything goes. Mentors from industry and faculty stay with you through the night. Great food, great wifi, greater prizes.",
      prizes: [{ pos: 1, amt: 10000 }, { pos: 2, amt: 5000 }, { pos: 3, amt: 2500 }],
      rules: ["Team size: 2–4 members from any branch or year.", "Open to all MHSSCE students; inter-college teams not allowed.", "Prototype must be built on-site during the event.", "Use of open-source libraries and public APIs is allowed.", "Judging criteria: innovation (30%), technical depth (30%), UI/UX (20%), impact (20%).", "Teams must submit their project before the evaluation round."],
      schedule: [{ time: "09:00 AM", label: "Registration & kit distribution" }, { time: "10:00 AM", label: "Opening ceremony & problem statement reveal" }, { time: "10:30 AM", label: "Hacking begins" }, { time: "01:00 PM", label: "Mentor round 1 & lunch" }, { time: "05:00 PM", label: "Progress checkpoint" }, { time: "09:00 AM (Day 2)", label: "Final code freeze" }, { time: "10:30 AM", label: "Project evaluation" }, { time: "04:00 PM", label: "Jury deliberation" }, { time: "05:30 PM", label: "Results & prize distribution" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }, { name: "Sana Qureshi", role: "Student Coordinator" }, { name: "Rehan Patel", role: "Technical Lead" }]
    },
    {
      id: "e2", title: "Tech Quiz — Battle of Brains", tagline: "How fast can you think?", cat: "Technical", clubId: "c1",
      venue: "Main Auditorium, MHSSCE", dateStart: iso(2026, 9, 24), timeStart: "10:00", timeEnd: "13:00", regDeadline: iso(2026, 9, 23),
      fee: 0, maxPart: 100, teamMin: 2, teamMax: 2, eligibility: "Open to all departments",
      banner: "assets/img/quiz.jpg", published: true, resultsPublished: false, baseRegs: 67,
      desc: "The classic MHSSCE tech quiz returns! Rounds on programming, networking, new tech, history of computing and a rapid-fire buzzer finale. Audience prizes too — bring your friends.",
      prizes: [{ pos: 1, amt: 3000 }, { pos: 2, amt: 1500 }, { pos: 3, amt: 750 }],
      rules: ["Teams of exactly 2.", "6 rounds; lowest scoring teams eliminated after round 3.", "Star-marked questions carry double points.", "Quizmaster's decision is final."],
      schedule: [{ time: "10:00 AM", label: "Reporting" }, { time: "10:30 AM", label: "Preliminary written round" }, { time: "11:15 AM", label: "Semi-final on stage" }, { time: "12:15 PM", label: "Grand finale & rapid fire" }, { time: "01:00 PM", label: "Prize distribution" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }, { name: "Zoya Khan", role: "Quizmaster" }]
    },
    {
      id: "e3", title: "Robo War 3.0", tagline: "Let the machines fight", cat: "Technical", clubId: "c2",
      venue: "Open Air Arena, MHSSCE Ground", dateStart: iso(2026, 9, 28), timeStart: "11:00", timeEnd: "17:00", regDeadline: iso(2026, 9, 26),
      fee: 150, maxPart: 60, teamMin: 2, teamMax: 5, eligibility: "Robot specs as per rulebook (max 15 kg)",
      banner: "assets/img/robowar.jpg", published: true, resultsPublished: false, baseRegs: 48,
      desc: "MHSSCE's most adrenaline-packed event returns for its third season. Combat robots up to 15 kg clash inside a shatter-proof arena in single-elimination bouts. Safety inspection is mandatory before every fight.",
      prizes: [{ pos: 1, amt: 8000 }, { pos: 2, amt: 4000 }, { pos: 3, amt: 2000 }],
      rules: ["Max robot weight: 15 kg including onboard battery.", "No fire, liquids, EMPs or entanglement weapons.", "Match duration: 3 minutes; knockout or judges' decision.", "Team size 2–5; safety gear compulsory during handling."],
      schedule: [{ time: "11:00 AM", label: "Reporting & safety inspection" }, { time: "11:45 AM", label: "Opening bouts" }, { time: "02:00 PM", label: "Quarter finals" }, { time: "03:30 PM", label: "Semi finals" }, { time: "04:30 PM", label: "GRAND FINALE" }, { time: "05:15 PM", label: "Prize distribution" }],
      organizers: [{ name: "Prof. S. Z. Ansari", role: "Faculty Coordinator" }, { name: "Rehan Patel", role: "Student Coordinator" }]
    },
    {
      id: "e4", title: "Hands-on Drone Workshop", tagline: "Build & fly your own quadcopter", cat: "Workshop", clubId: "c2",
      venue: "Mechanical Workshop, MHSSCE", dateStart: iso(2026, 9, 15), timeStart: "10:00", timeEnd: "16:00", regDeadline: iso(2026, 9, 14),
      fee: 200, maxPart: 50, teamMin: 1, teamMax: 3, eligibility: "SE/TE/BE students; kit included in fee",
      banner: "assets/img/workshop.jpg", published: true, resultsPublished: false, baseRegs: 40,
      desc: "A full-day practical workshop: assemble a quadcopter from a kit, learn flight principles, calibrate the flight controller and fly it in the supervised arena. Take-home kit for every team. Certificates for all participants. Limited seats — registration closes soon!",
      prizes: [{ pos: 1, amt: 0, label: "Best Flyer award" }],
      rules: ["Fee includes a shared take-home kit per team.", "Participants must bring their own laptops.", "Flying outside the netted arena is prohibited.", "E-certificates for all attendees."],
      schedule: [{ time: "10:00 AM", label: "Intro to multirotor dynamics" }, { time: "11:30 AM", label: "Kit assembly session" }, { time: "01:00 PM", label: "Lunch break" }, { time: "02:00 PM", label: "Flight controller calibration" }, { time: "03:00 PM", label: "Supervised flying arena" }, { time: "04:00 PM", label: "Feedback & certificates" }],
      organizers: [{ name: "Prof. S. Z. Ansari", role: "Faculty Coordinator" }, { name: "Aditya Deshmukh", role: "Student Coordinator" }]
    },
    {
      id: "e5", title: "AI & The Future of Computing", tagline: "A seminar by industry experts", cat: "Seminar", clubId: "c6",
      venue: "Convention Centre, MHSSCE", dateStart: iso(2026, 9, 18), timeStart: "14:00", timeEnd: "17:00", regDeadline: iso(2026, 9, 17),
      fee: 0, maxPart: 150, teamMin: 1, teamMax: 1, eligibility: "Open to all students & faculty",
      banner: "assets/img/seminar.jpg", published: true, resultsPublished: false, baseRegs: 90,
      desc: "Industry speakers from leading product companies discuss where AI is taking computing — from on-device models to agentic systems — followed by a Q&A and networking tea. Free entry; e-certificates for attendees.",
      prizes: [],
      rules: ["Free entry with prior registration.", "Carry your college ID card.", "Q&A via the moderator only.", "Attendance certificate on exit scan."],
      schedule: [{ time: "02:00 PM", label: "Welcome & keynote" }, { time: "02:45 PM", label: "Talk 1 — On-device AI" }, { time: "03:30 PM", label: "Talk 2 — Agents in production" }, { time: "04:15 PM", label: "Panel + Q&A" }, { time: "04:45 PM", label: "Networking tea" }],
      organizers: [{ name: "Dr. A. R. Merchant", role: "Faculty Coordinator" }, { name: "Zoya Khan", role: "Student Coordinator" }]
    },
    {
      id: "e6", title: "Aawaaz — Cultural Night 2026", tagline: "The stage is yours", cat: "Cultural", clubId: "c3",
      venue: "Main Auditorium & Lawn, MHSSCE", dateStart: iso(2026, 10, 3), timeStart: "17:00", timeEnd: "22:00", regDeadline: iso(2026, 10, 1),
      fee: 50, maxPart: 300, teamMin: 1, teamMax: 15, eligibility: "Open to all; performances subject to audition",
      banner: "assets/img/cultural.jpg", published: true, resultsPublished: false, baseRegs: 210,
      desc: "The most awaited evening of the year — music, dance, drama, stand-up and the grand fashion parade. Competitions across 6 categories plus the headline band performance. Dinner included.",
      prizes: [{ pos: 1, amt: 5000, label: "Best Performance" }, { pos: 2, amt: 3000, label: "Second Best" }, { pos: 3, amt: 1500, label: "Third Best" }],
      rules: ["Performances 3–6 minutes; audition required for solo acts.", "No offensive content; committee approval mandatory.", "Props must be approved 48h in advance.", "Entry fee includes dinner coupon."],
      schedule: [{ time: "05:00 PM", label: "Doors open" }, { time: "05:30 PM", label: "Group dance competition" }, { time: "06:45 PM", label: "Singing & band performances" }, { time: "08:00 PM", label: "Dinner break" }, { time: "08:45 PM", label: "Drama & stand-up" }, { time: "09:45 PM", label: "Fashion parade & results" }],
      organizers: [{ name: "Prof. N. B. Sayyed", role: "Faculty Coordinator" }, { name: "Fatima Ansari", role: "Student Coordinator" }]
    },
    {
      id: "e7", title: "Khel Mahotsav — Sports Fest", tagline: "Three days. One champion college.", cat: "Sports", clubId: "c4",
      venue: "MHSSCE Ground & Sports Complex", dateStart: iso(2026, 10, 10), dateEnd: iso(2026, 10, 12),
      timeStart: "08:00", timeEnd: "18:00", regDeadline: iso(2026, 10, 8),
      fee: 100, maxPart: 400, teamMin: 1, teamMax: 16, eligibility: "All branches; class-wise teams",
      banner: "assets/img/sports.jpg", published: true, resultsPublished: false, baseRegs: 160,
      desc: "The annual three-day sports festival — cricket, football, volleyball, basketball, chess, carrom and athletics. Class-wise teams battle for the overall Championship Trophy.",
      prizes: [{ pos: 1, amt: 7000, label: "Championship Trophy" }, { pos: 2, amt: 4000 }, { pos: 3, amt: 2000 }],
      rules: ["One student may represent only one class team.", "College ID mandatory at every fixture.", "Cricket & football: 8-a-side format.", "Referee's decision is final."],
      schedule: [{ time: "08:00 AM (Day 1)", label: "Opening ceremony & march past" }, { time: "09:00 AM", label: "League fixtures begin" }, { time: "09:00 AM (Day 2)", label: "Semi-finals all sports" }, { time: "03:00 PM (Day 3)", label: "Cricket & football finals" }, { time: "05:30 PM", label: "Prize distribution & closing" }],
      organizers: [{ name: "Prof. P. V. Deshmukh", role: "Faculty Coordinator" }, { name: "Aditya Deshmukh", role: "Sports Secretary" }]
    },
    {
      id: "e8", title: "Startup Pitch Day", tagline: "90 seconds to impress the jury", cat: "Seminar", clubId: "c5",
      venue: "Incubation Centre, MHSSCE", dateStart: iso(2026, 10, 18), timeStart: "11:00", timeEnd: "15:00", regDeadline: iso(2026, 10, 16),
      fee: 50, maxPart: 60, teamMin: 1, teamMax: 4, eligibility: "Ideas at any stage; all branches welcome",
      banner: "assets/img/seminar.jpg", published: true, resultsPublished: false, baseRegs: 35,
      desc: "Pitch your startup idea to a jury of founders and investors. Top 3 teams get fast-track entry into the E-Cell incubation program and seed support from the college.",
      prizes: [{ pos: 1, amt: 6000, label: "+ Incubation fast-track" }, { pos: 2, amt: 3000 }, { pos: 3, amt: 1500 }],
      rules: ["Pitch duration: 90 seconds + 3 minutes Q&A.", "Deck limit: 10 slides.", "Individual and team entries allowed (max 4).", "Jury decision is final."],
      schedule: [{ time: "11:00 AM", label: "Reporting & deck submission" }, { time: "11:30 AM", label: "Pitches begin" }, { time: "01:30 PM", label: "Lunch + investor networking" }, { time: "02:15 PM", label: "Finalists re-pitch" }, { time: "02:45 PM", label: "Results" }],
      organizers: [{ name: "Prof. R. M. Shaikh", role: "Faculty Coordinator" }, { name: "Yash Kulkarni", role: "Student Coordinator" }]
    },

    /* ── ⚫ COMPLETED (results published) ── */
    {
      id: "e10", title: "Web Blitz 2.0", tagline: "Front-end speed building contest", cat: "Technical", clubId: "c1",
      venue: "Computer Lab 1 & 2", dateStart: iso(2026, 8, 30), timeStart: "10:00", timeEnd: "14:00", regDeadline: iso(2026, 8, 29),
      fee: 0, maxPart: 80, teamMin: 1, teamMax: 2, eligibility: "Open to all",
      banner: "assets/img/hackathon.jpg", published: true, resultsPublished: true, baseRegs: 54,
      desc: "A 3-hour front-end sprint: clone a given design pixel-perfect as fast as you can. Judged on accuracy, responsiveness and code quality.",
      prizes: [{ pos: 1, amt: 4000 }, { pos: 2, amt: 2000 }, { pos: 3, amt: 1000 }],
      rules: ["HTML/CSS/JS only; no frameworks.", "Time bonus for early perfect submissions.", "Peer code review after the event."],
      schedule: [{ time: "10:00 AM", label: "Design brief reveal" }, { time: "10:15 AM", label: "Build sprint" }, { time: "01:15 PM", label: "Evaluation" }, { time: "01:45 PM", label: "Results" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }, { name: "Sana Qureshi", role: "Student Coordinator" }]
    },
    {
      id: "e11", title: "Ideathon 2026", tagline: "Ideas that solve real campus problems", cat: "Technical", clubId: "c5",
      venue: "Seminar Hall B", dateStart: iso(2026, 8, 22), timeStart: "10:00", timeEnd: "16:00", regDeadline: iso(2026, 8, 21),
      fee: 0, maxPart: 70, teamMin: 1, teamMax: 3, eligibility: "Open to all",
      banner: "assets/img/seminar.jpg", published: true, resultsPublished: true, baseRegs: 41,
      desc: "Teams brainstormed solutions for real campus problems — canteen queues, lab inventory, lost & found — and presented working concept notes to faculty jury.",
      prizes: [{ pos: 1, amt: 3000 }, { pos: 2, amt: 1500 }, { pos: 3, amt: 750 }],
      rules: ["Original ideas only.", "5-minute presentation + 3 minutes Q&A."],
      schedule: [{ time: "10:00 AM", label: "Theme reveal" }, { time: "11:00 AM", label: "Ideation sprint" }, { time: "02:00 PM", label: "Presentations" }, { time: "04:00 PM", label: "Results" }],
      organizers: [{ name: "Prof. R. M. Shaikh", role: "Faculty Coordinator" }, { name: "Yash Kulkarni", role: "Student Coordinator" }]
    },
    {
      id: "e12", title: "CyberSafe Workshop", tagline: "Stay safe online", cat: "Workshop", clubId: "c6",
      venue: "Computer Lab 4", dateStart: iso(2026, 8, 15), timeStart: "11:00", timeEnd: "14:00", regDeadline: iso(2026, 8, 14),
      fee: 0, maxPart: 60, teamMin: 1, teamMax: 1, eligibility: "Open to all",
      banner: "assets/img/workshop.jpg", published: true, resultsPublished: true, baseRegs: 44,
      desc: "A hands-on workshop on password hygiene, phishing detection, safe social media habits and an intro to ethical hacking. Participation-based; e-certificates issued to all attendees.",
      prizes: [],
      rules: ["Bring your own laptop.", "Full attendance required for certificate."],
      schedule: [{ time: "11:00 AM", label: "Threat landscape 101" }, { time: "12:00 PM", label: "Live phishing demo" }, { time: "01:00 PM", label: "Hands-on lab" }],
      organizers: [{ name: "Dr. A. R. Merchant", role: "Faculty Coordinator" }, { name: "Zoya Khan", role: "Student Coordinator" }]
    },
    {
      id: "e13", title: "Siddik TechFest 2026", tagline: "The biggest tech celebration of the year", cat: "Technical", clubId: "c6",
      venue: "Entire MHSSCE Campus", dateStart: iso(2026, 3, 12), dateEnd: iso(2026, 3, 14),
      timeStart: "09:00", timeEnd: "20:00", regDeadline: iso(2026, 3, 10),
      fee: 150, maxPart: 500, teamMin: 1, teamMax: 6, eligibility: "Open to all colleges (main events MHSSCE only)",
      banner: "assets/img/hero.jpg", published: true, resultsPublished: true, baseRegs: 350,
      desc: "Three days, 14 competitions, one epic fest — coding marathons, robo races, CAD challenges, paper presentations, gaming tournaments and the tech exhibition that pulled 350+ participants.",
      prizes: [{ pos: 1, amt: 15000, label: "Overall Championship" }, { pos: 2, amt: 8000 }, { pos: 3, amt: 4000 }],
      rules: ["Fest pass mandatory for all events.", "Event-specific rules as per individual rulebooks.", "Overall championship scored across events per department."],
      schedule: [{ time: "Day 1", label: "Inauguration, coding marathon, robo race" }, { time: "Day 2", label: "CAD, paper presentation, gaming" }, { time: "Day 3", label: "Exhibition, finals, prize night" }],
      organizers: [{ name: "Dr. A. R. Merchant", role: "Fest Convenor" }, { name: "Rehan Patel", role: "Technical Head" }, { name: "Zoya Khan", role: "Events Head" }]
    },
    {
      id: "e14", title: "Hackathon 2025", tagline: "Build • Innovate • Solve", cat: "Hackathon", clubId: "c1",
      venue: "Seminar Hall & Computer Labs", dateStart: iso(2025, 9, 20), dateEnd: iso(2025, 9, 21),
      timeStart: "09:00", timeEnd: "18:00", regDeadline: iso(2025, 9, 18),
      fee: 100, maxPart: 128, teamMin: 2, teamMax: 4, eligibility: "All MHSSCE students",
      banner: "assets/img/hackathon.jpg", published: true, resultsPublished: true, baseRegs: 118,
      desc: "The 2025 edition of the flagship hackathon — 32 teams, 24 hours, one winning project: Smart Campus AI.",
      prizes: [{ pos: 1, amt: 10000 }, { pos: 2, amt: 5000 }, { pos: 3, amt: 2500 }],
      rules: ["Team size 2–4.", "On-site development only.", "Open-source stacks allowed."],
      schedule: [{ time: "09:00 AM", label: "Registration" }, { time: "10:00 AM", label: "Opening" }, { time: "10:30 AM", label: "Competition" }, { time: "04:00 PM", label: "Evaluation" }, { time: "05:30 PM", label: "Results" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }, { name: "Sana Qureshi", role: "Student Coordinator" }]
    },
    {
      id: "e15", title: "Tech Quiz 2025", tagline: "Battle of Brains — first edition", cat: "Technical", clubId: "c1",
      venue: "Main Auditorium", dateStart: iso(2025, 10, 16), timeStart: "10:00", timeEnd: "13:00", regDeadline: iso(2025, 10, 15),
      fee: 0, maxPart: 90, teamMin: 2, teamMax: 2, eligibility: "Open to all",
      banner: "assets/img/quiz.jpg", published: true, resultsPublished: true, baseRegs: 72,
      desc: "The first edition of the MHSSCE Tech Quiz — 36 teams, six rounds, one legendary tie-breaker.",
      prizes: [{ pos: 1, amt: 2500 }, { pos: 2, amt: 1250 }, { pos: 3, amt: 650 }],
      rules: ["Teams of 2.", "Quizmaster's decision final."],
      schedule: [{ time: "10:00 AM", label: "Prelims" }, { time: "11:30 AM", label: "Stage rounds" }, { time: "12:45 PM", label: "Results" }],
      organizers: [{ name: "Prof. J. R. Kazi", role: "Faculty Coordinator" }]
    },
    {
      id: "e16", title: "Annual Sports Meet 2025", tagline: "Run. Jump. Conquer.", cat: "Sports", clubId: "c4",
      venue: "MHSSCE Ground", dateStart: iso(2025, 12, 18), dateEnd: iso(2025, 12, 20),
      timeStart: "08:00", timeEnd: "17:00", regDeadline: iso(2025, 12, 15),
      fee: 50, maxPart: 300, teamMin: 1, teamMax: 16, eligibility: "All branches",
      banner: "assets/img/sports.jpg", published: true, resultsPublished: true, baseRegs: 260,
      desc: "Three days of athletics, team sports and the famous inter-branch tug of war.",
      prizes: [{ pos: 1, amt: 5000, label: "Champion Branch" }, { pos: 2, amt: 2500 }, { pos: 3, amt: 1250 }],
      rules: ["ID card compulsory.", "Athletics: max 3 events per student."],
      schedule: [{ time: "Day 1", label: "Track events" }, { time: "Day 2", label: "Team sports semis" }, { time: "Day 3", label: "Finals & closing" }],
      organizers: [{ name: "Prof. P. V. Deshmukh", role: "Faculty Coordinator" }]
    },
    {
      id: "e17", title: "TechFest 2025", tagline: "Innovation unleased", cat: "Technical", clubId: "c2",
      venue: "MHSSCE Campus", dateStart: iso(2025, 3, 14), dateEnd: iso(2025, 3, 15),
      timeStart: "09:00", timeEnd: "19:00", regDeadline: iso(2025, 3, 12),
      fee: 100, maxPart: 400, teamMin: 1, teamMax: 6, eligibility: "Open to all",
      banner: "assets/img/hero.jpg", published: true, resultsPublished: true, baseRegs: 280,
      desc: "The 2025 edition of the college tech fest with 11 events across two days.",
      prizes: [{ pos: 1, amt: 12000 }, { pos: 2, amt: 6000 }, { pos: 3, amt: 3000 }],
      rules: ["Fest pass mandatory."],
      schedule: [{ time: "Day 1", label: "Competitions" }, { time: "Day 2", label: "Exhibition & prize night" }],
      organizers: [{ name: "Prof. S. Z. Ansari", role: "Faculty Coordinator" }]
    }
  ];

  const users = [
    { id: "u-admin", name: "Prof. M. A. Shaikh", email: "admin@mhssce.ac.in", phone: "98200 11223", prn: "FACULTY-01", branch: "Faculty", year: "-", role: "admin", pass: "admin123", title: "Event Coordinator, MHSSCE" },
    { id: "u-org", name: "Sana Qureshi", email: "organizer@mhssce.ac.in", phone: "98200 44556", prn: "2012480033", branch: "Information Technology", year: "BE", role: "organizer", pass: "org123", title: "Student Coordinator — Coding Club" },
    { id: "u1", name: "Zaid Shaikh", email: "student@mhssce.ac.in", phone: "98210 55321", prn: "2212480104", branch: "Computer Engineering", year: "TE", role: "student", pass: "student123" },
    { id: "u2", name: "Aarav Sharma", email: "aarav@mhssce.ac.in", phone: "98211 20101", prn: "2212480011", branch: "Information Technology", year: "TE", role: "student", pass: "student123" },
    { id: "u3", name: "Zoya Khan", email: "zoya@mhssce.ac.in", phone: "98212 30202", prn: "2312480057", branch: "AI & Data Science", year: "SE", role: "student", pass: "student123" },
    { id: "u4", name: "Rehan Patel", email: "rehan@mhssce.ac.in", phone: "98213 40303", prn: "2012480077", branch: "Computer Engineering", year: "BE", role: "student", pass: "student123" },
    { id: "u5", name: "Sana Sheikh", email: "sanash@mhssce.ac.in", phone: "98214 50404", prn: "2312480069", branch: "Information Technology", year: "SE", role: "student", pass: "student123" },
    { id: "u6", name: "Aditya Deshmukh", email: "aditya@mhssce.ac.in", phone: "98215 60505", prn: "2112480121", branch: "Mechanical Engineering", year: "TE", role: "student", pass: "student123" },
    { id: "u7", name: "Fatima Ansari", email: "fatima@mhssce.ac.in", phone: "98216 70606", prn: "2112480090", branch: "AI & Data Science", year: "TE", role: "student", pass: "student123" },
    { id: "u8", name: "Yash Kulkarni", email: "yash@mhssce.ac.in", phone: "98217 80707", prn: "2212480143", branch: "Computer Engineering", year: "SE", role: "student", pass: "student123" },
    { id: "u9", name: "Ayesha Sayyed", email: "ayesha@mhssce.ac.in", phone: "98218 90808", prn: "2112480055", branch: "Civil Engineering", year: "TE", role: "student", pass: "student123" },
    { id: "u10", name: "Tanmay Joshi", email: "tanmay@mhssce.ac.in", phone: "98219 10909", prn: "2012480110", branch: "Electrical Engineering", year: "BE", role: "student", pass: "student123" },
    { id: "u11", name: "Khadija Memon", email: "khadija@mhssce.ac.in", phone: "98212 21010", prn: "2412480028", branch: "Computer Engineering", year: "FE", role: "student", pass: "student123" },
    { id: "u12", name: "Sahil Raut", email: "sahil@mhssce.ac.in", phone: "98213 31111", prn: "2012480132", branch: "Information Technology", year: "BE", role: "student", pass: "student123" }
  ];

  const registrations = [
    { id: "EV2026-1042", eventId: "e10", userId: "u1", type: "team", teamName: "NullPointers", members: ["Aarav Sharma"], paid: true, attended: true, date: "2026-08-28", name: "Zaid Shaikh", email: "student@mhssce.ac.in", phone: "98210 55321", prn: "2212480104", branch: "Computer Engineering", year: "TE" },
    { id: "EV2026-1036", eventId: "e11", userId: "u1", type: "team", teamName: "CampusFix", members: ["Khadija Memon"], paid: true, attended: true, date: "2026-08-20", name: "Zaid Shaikh", email: "student@mhssce.ac.in", phone: "98210 55321", prn: "2212480104", branch: "Computer Engineering", year: "TE" },
    { id: "EV2026-1048", eventId: "e5", userId: "u1", type: "individual", teamName: "", members: [], paid: true, attended: false, date: "2026-09-08", name: "Zaid Shaikh", email: "student@mhssce.ac.in", phone: "98210 55321", prn: "2212480104", branch: "Computer Engineering", year: "TE" },
    { id: "EV2026-1049", eventId: "e1", userId: "u2", type: "team", teamName: "Ctrl+Alt+Elite", members: ["Zoya Khan", "Yash Kulkarni"], paid: true, attended: false, date: "2026-09-06", name: "Aarav Sharma", email: "aarav@mhssce.ac.in", phone: "98211 20101", prn: "2212480011", branch: "Information Technology", year: "TE" },
    { id: "EV2026-1050", eventId: "e1", userId: "u4", type: "team", teamName: "Byte Knights", members: ["Sahil Raut", "Tanmay Joshi", "Aditya Deshmukh"], paid: true, attended: false, date: "2026-09-07", name: "Rehan Patel", email: "rehan@mhssce.ac.in", phone: "98213 40303", prn: "2012480077", branch: "Computer Engineering", year: "BE" },
    { id: "EV2026-1051", eventId: "e2", userId: "u3", type: "team", teamName: "Semicolons", members: ["Sana Sheikh"], paid: true, attended: false, date: "2026-09-05", name: "Zoya Khan", email: "zoya@mhssce.ac.in", phone: "98212 30202", prn: "2312480057", branch: "AI & Data Science", year: "SE" },
    { id: "EV2026-1052", eventId: "e3", userId: "u6", type: "team", teamName: "Iron Bots", members: ["Tanmay Joshi", "Sahil Raut"], paid: true, attended: false, date: "2026-09-04", name: "Aditya Deshmukh", email: "aditya@mhssce.ac.in", phone: "98215 60505", prn: "2112480121", branch: "Mechanical Engineering", year: "TE" },
    { id: "EV2026-1053", eventId: "e4", userId: "u8", type: "team", teamName: "Sky Flyers", members: ["Khadija Memon"], paid: true, attended: false, date: "2026-09-03", name: "Yash Kulkarni", email: "yash@mhssce.ac.in", phone: "98217 80707", prn: "2212480143", branch: "Computer Engineering", year: "SE" },
    { id: "EV2026-1054", eventId: "e5", userId: "u7", type: "individual", teamName: "", members: [], paid: true, attended: false, date: "2026-09-06", name: "Fatima Ansari", email: "fatima@mhssce.ac.in", phone: "98216 70606", prn: "2112480090", branch: "AI & Data Science", year: "TE" },
    { id: "EV2026-1055", eventId: "e6", userId: "u5", type: "team", teamName: "Rangreza", members: ["Fatima Ansari", "Ayesha Sayyed", "Khadija Memon"], paid: true, attended: false, date: "2026-09-09", name: "Sana Sheikh", email: "sanash@mhssce.ac.in", phone: "98214 50404", prn: "2312480069", branch: "Information Technology", year: "SE" },
    { id: "EV2026-1056", eventId: "e7", userId: "u9", type: "team", teamName: "Civil Warriors", members: ["Aditya Deshmukh"], paid: false, attended: false, date: "2026-09-09", name: "Ayesha Sayyed", email: "ayesha@mhssce.ac.in", phone: "98218 90808", prn: "2112480055", branch: "Civil Engineering", year: "TE" },
    { id: "EV2026-1057", eventId: "e8", userId: "u12", type: "team", teamName: "Pitch Perfect", members: ["Aarav Sharma"], paid: true, attended: false, date: "2026-09-09", name: "Sahil Raut", email: "sahil@mhssce.ac.in", phone: "98213 31111", prn: "2012480132", branch: "Information Technology", year: "BE" }
  ];

  const results = [
    { id: "r1", eventId: "e10", pos: 1, title: "Team NullPointers", type: "team", members: ["Zaid Shaikh", "Aarav Sharma"], prize: 4000, project: "Pixel-perfect college portal clone in 2h 11m" },
    { id: "r2", eventId: "e10", pos: 2, title: "CSS Czars", type: "team", members: ["Fatima Ansari", "Sana Sheikh"], prize: 2000, project: "Closest mobile-first layout" },
    { id: "r3", eventId: "e10", pos: 3, title: "Byte Me!", type: "team", members: ["Yash Kulkarni"], prize: 1000, project: "Cleanest vanilla-JS build" },
    { id: "r4", eventId: "e11", pos: 1, title: "Team Catalyst", type: "team", members: ["Rehan Patel", "Tanmay Joshi"], prize: 3000, project: "SmartQueue — canteen queue predictor" },
    { id: "r5", eventId: "e11", pos: 2, title: "CampusFix", type: "team", members: ["Zaid Shaikh", "Khadija Memon"], prize: 1500, project: "One-tap lab inventory app" },
    { id: "r6", eventId: "e11", pos: 3, title: "Grey Cells", type: "team", members: ["Ayesha Sayyed"], prize: 750, project: "Lost & Found portal with QR claim" },
    { id: "r7", eventId: "e12", pos: 0, title: "All 44 attendees", type: "individual", members: [], prize: 0, project: "Participation-based workshop — e-certificates issued to all attendees" },
    { id: "r8", eventId: "e13", pos: 1, title: "Neural Ninjas (Computer Engg.)", type: "team", members: ["Zaid Shaikh", "Rehan Patel", "Khadija Memon"], prize: 15000, project: "Overall championship — 4 golds across events" },
    { id: "r9", eventId: "e13", pos: 2, title: "IT Dynamos (Information Tech.)", type: "team", members: ["Aarav Sharma", "Sahil Raut", "Sana Qureshi"], prize: 8000, project: "Runners-up — gaming & web events sweep" },
    { id: "r10", eventId: "e13", pos: 3, title: "Mech Mavericks (Mechanical)", type: "team", members: ["Aditya Deshmukh", "Tanmay Joshi"], prize: 4000, project: "Robo race & CAD champions" },
    { id: "r11", eventId: "e14", pos: 1, title: "Team Innovators", type: "team", members: ["Aarav Sharma", "Fatima Ansari", "Zoya Khan"], prize: 10000, project: "Smart Campus AI — attendance & energy optimiser" },
    { id: "r12", eventId: "e14", pos: 2, title: "Code Warriors", type: "team", members: ["Rehan Patel", "Yash Kulkarni", "Sahil Raut"], prize: 5000, project: "CampusNav — indoor navigation app" },
    { id: "r13", eventId: "e14", pos: 3, title: "Tech Titans", type: "team", members: ["Aditya Deshmukh", "Tanmay Joshi"], prize: 2500, project: "AgriBot — plant monitoring rover" },
    { id: "r14", eventId: "e15", pos: 1, title: "Ctrl+Alt+Defeat", type: "team", members: ["Zoya Khan", "Fatima Ansari"], prize: 2500, project: "Won on the final tie-breaker" },
    { id: "r15", eventId: "e15", pos: 2, title: "Null Terminators", type: "team", members: ["Aarav Sharma", "Zaid Shaikh"], prize: 1250, project: "Led till the last round" },
    { id: "r16", eventId: "e15", pos: 3, title: "Segmentation Fault", type: "team", members: ["Sahil Raut", "Sana Sheikh"], prize: 650, project: "Best in rapid fire" },
    { id: "r17", eventId: "e16", pos: 1, title: "Computer Engineering", type: "team", members: ["Zaid Shaikh", "Yash Kulkarni"], prize: 5000, project: "Champion Branch — 78 points" },
    { id: "r18", eventId: "e16", pos: 2, title: "Mechanical Engineering", type: "team", members: ["Aditya Deshmukh"], prize: 2500, project: "Tug of war & athletics champions" },
    { id: "r19", eventId: "e16", pos: 3, title: "Information Technology", type: "team", members: ["Sahil Raut"], prize: 1250, project: "Cricket runners-up" },
    { id: "r20", eventId: "e17", pos: 1, title: "Robotics Club — Team Volt", type: "team", members: ["Rehan Patel", "Aditya Deshmukh"], prize: 12000, project: "Robo race + robo war double crown" },
    { id: "r21", eventId: "e17", pos: 2, title: "Coding Club — Binary Brains", type: "team", members: ["Aarav Sharma"], prize: 6000, project: "Coding marathon winners" },
    { id: "r22", eventId: "e17", pos: 3, title: "AI Forum — Think Tank", type: "team", members: ["Zoya Khan", "Fatima Ansari"], prize: 3000, project: "Best paper presentation" }
  ];

  const certificates = [
    { id: "CERT-2026-10231", eventId: "e10", userId: "u1", name: "Zaid Shaikh", achievement: "Winner", date: "2026-08-30" },
    { id: "CERT-2026-10232", eventId: "e11", userId: "u1", name: "Zaid Shaikh", achievement: "Runner-up", date: "2026-08-22" },
    { id: "CERT-2026-10188", eventId: "e10", userId: "u2", name: "Aarav Sharma", achievement: "Winner", date: "2026-08-30" },
    { id: "CERT-2026-10190", eventId: "e10", userId: "u7", name: "Fatima Ansari", achievement: "Runner-up", date: "2026-08-30" },
    { id: "CERT-2025-0994", eventId: "e14", userId: "u1", name: "Zaid Shaikh", achievement: "Participant", date: "2025-09-21" },
    { id: "CERT-2026-10211", eventId: "e13", userId: "u1", name: "Zaid Shaikh", achievement: "Winner", date: "2026-03-14" }
  ];

  const gallery = [
    { id: "g1", eventId: "e13", img: "assets/img/hero.jpg", caption: "Siddik TechFest 2026 — inauguration" },
    { id: "g2", eventId: "e13", img: "assets/img/quiz.jpg", caption: "TechFest quiz prelims" },
    { id: "g3", eventId: "e13", img: "assets/img/robowar.jpg", caption: "Robo arena at TechFest" },
    { id: "g4", eventId: "e1", img: "assets/img/hackathon.jpg", caption: "Hackathon teams hacking at 2 AM" },
    { id: "g5", eventId: "e14", img: "assets/img/hackathon.jpg", caption: "Hackathon 2025 — lab full of builders" },
    { id: "g6", eventId: "e3", img: "assets/img/robowar.jpg", caption: "Robo War 2.0 — final bout" },
    { id: "g7", eventId: "e7", img: "assets/img/sports.jpg", caption: "Khel Mahotsav cricket final" },
    { id: "g8", eventId: "e16", img: "assets/img/sports.jpg", caption: "Annual Sports Meet 2025" },
    { id: "g9", eventId: "e6", img: "assets/img/cultural.jpg", caption: "Aawaaz cultural night" },
    { id: "g10", eventId: "e6", img: "assets/img/cultural.jpg", caption: "Fashion parade finale" },
    { id: "g11", eventId: "e4", img: "assets/img/workshop.jpg", caption: "Drone assembly session" },
    { id: "g12", eventId: "e12", img: "assets/img/workshop.jpg", caption: "CyberSafe hands-on lab" },
    { id: "g13", eventId: "e5", img: "assets/img/seminar.jpg", caption: "AI seminar keynote" },
    { id: "g14", eventId: "e8", img: "assets/img/seminar.jpg", caption: "Pitch day with the jury" },
    { id: "g15", eventId: "e2", img: "assets/img/quiz.jpg", caption: "Buzzers down, brains on" },
    { id: "g16", eventId: "e-live", img: "assets/img/hackathon.jpg", caption: "CodeStorm live leaderboard" }
  ];

  return {
    version: 3,
    meta: { regSeq: 1058, certSeq: 10233 },
    users, clubs, events, registrations, results, certificates, gallery
  };
}

/* Bundled image library (for admin pickers) */
const IMG_LIBRARY = [
  { src: "assets/img/hackathon.jpg", label: "Hackathon / coding lab" },
  { src: "assets/img/robowar.jpg", label: "Robots / arena" },
  { src: "assets/img/quiz.jpg", label: "Quiz / stage" },
  { src: "assets/img/sports.jpg", label: "Sports / ground" },
  { src: "assets/img/cultural.jpg", label: "Cultural / stage night" },
  { src: "assets/img/workshop.jpg", label: "Workshop / lab" },
  { src: "assets/img/seminar.jpg", label: "Seminar / auditorium" },
  { src: "assets/img/hero.jpg", label: "Techfest / campus vibe" }
];
