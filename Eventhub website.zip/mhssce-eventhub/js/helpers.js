/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — Helpers & utilities
   ═══════════════════════════════════════════════════════════════ */

/* ---------- safe storage (works even in sandboxed previews) ---------- */
const store = (function () {
  let mem = {};
  let ok = false;
  try { localStorage.setItem("__t", "1"); localStorage.removeItem("__t"); ok = true; } catch (e) { ok = false; }
  return {
    persistent: ok,
    get(k) { try { return ok ? localStorage.getItem(k) : (mem[k] || null); } catch (e) { return mem[k] || null; } },
    set(k, v) { try { if (ok) localStorage.setItem(k, v); else mem[k] = v; } catch (e) { mem[k] = v; } },
    remove(k) { try { if (ok) localStorage.removeItem(k); else delete mem[k]; } catch (e) { delete mem[k]; } }
  };
})();

/* ---------- asset resolver ----------
       The multi-file site serves images from the assets/img directory The standalone
       offline build defines window.__ASSET_MAP once (data URIs) — A() makes
       both work with zero duplication. */
function A(src) {
  try { var m = window.__ASSET_MAP; return (m && m[src]) || src; } catch (e) { return src; }
}

/* ---------- DOM + misc ---------- */
function qs(sel) { return document.querySelector(sel); }
function qsa(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function initials(name) {
  return String(name || "?").trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase();
}
function uid(prefix) { return prefix + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

/* ---------- dates & money ---------- */
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function toDate(v) {
  if (typeof v === "number") return new Date(v);
  var d = new Date(v + "T00:00:00");
  return isNaN(d.getTime()) ? new Date(v) : d;
}
function fmtDate(v) {
  if (!v && v !== 0) return "";
  var d = toDate(v);
  return d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear();
}
function fmtTime12(hhmm) {
  if (!hhmm && hhmm !== "0") return "";
  var parts = String(hhmm).split(":");
  var h = parseInt(parts[0], 10), m = parts[1] || "00";
  var ap = h >= 12 ? "PM" : "AM";
  h = h % 12; if (h === 0) h = 12;
  return h + ":" + m + " " + ap;
}
function fmtDateRange(e) {
  if (e.liveDemo) return "Happening now";
  var s = fmtDate(e.dateStart);
  if (e.dateEnd) {
    var de = toDate(e.dateEnd);
    var ds = toDate(e.dateStart);
    if (ds.getMonth() === de.getMonth()) return ds.getDate() + "–" + de.getDate() + " " + MONTHS[de.getMonth()] + " " + de.getFullYear();
    return s + " – " + fmtDate(e.dateEnd);
  }
  return s;
}
function fmtMoney(n) {
  if (!n || n <= 0) return "FREE";
  return "₹" + Number(n).toLocaleString("en-IN");
}
function eventYear(e) {
  return toDate(e.dateStart || e.startMs).getFullYear();
}
function sameDayUTC(a, b) { return a && b && a.toDateString() === b.toDateString(); }

/* ---------- event time & status engine ----------
   Status flow: UPCOMING → REG OPEN → REG CLOSED → 🔴 LIVE → COMPLETED → RESULTS PUBLISHED */
function evStart(e) { return e.liveDemo ? e.startMs : toDate(e.dateStart).getTime() + (parseHM(e.timeStart) || 9 * 60) * 60e3; }
function evEnd(e) {
  if (e.liveDemo) return e.endMs;
  var endDay = e.dateEnd || e.dateStart;
  return toDate(endDay).getTime() + (parseHM(e.timeEnd) || 22 * 60) * 60e3;
}
function evRegClose(e) {
  if (e.liveDemo) return e.regCloseMs;
  if (e.regDeadline) return toDate(e.regDeadline).getTime() + 23.5 * 3600e3;
  return evStart(e);
}
function parseHM(hhmm) {
  if (!hhmm) return null;
  var p = String(hhmm).split(":");
  var h = parseInt(p[0], 10) || 0, m = parseInt(p[1], 10) || 0;
  return h * 60 + m;
}
function getStatus(e) {
  var now = Date.now();
  if (e.resultsPublished) return { key: "results", label: "Results Published" };
  if (now >= evStart(e) && now <= evEnd(e)) return { key: "live", label: "Happening Now" };
  if (now > evEnd(e)) return { key: "done", label: "Completed" };
  if (now > evRegClose(e)) return { key: "closed", label: "Reg. Closed" };
  return { key: "open", label: "Registration Open" };
}
function badgeHTML(e, extra) {
  var st = getStatus(e);
  var cls = { live: "badge-live", open: "badge-open", closed: "badge-closed", done: "badge-done", results: "badge-results" }[st.key] || "badge-done";
  var dot = st.key === "live" ? '<span class="dot"></span>' : (st.key === "results" ? "" : '<span class="dot"></span>');
  return '<span class="badge ' + cls + '">' + dot + esc(st.label) + (extra || "") + "</span>";
}
function joinedCount(e) {
  return (e.baseRegs || 0) + DB.registrations.filter(function (r) { return r.eventId === e.id; }).length;
}
function regOpenFor(e) {
  var st = getStatus(e);
  return st.key === "open" && e.published !== false;
}

/* ---------- countdown ---------- */
function timeParts(ms) {
  ms = Math.max(0, ms);
  var s = Math.floor(ms / 1000);
  return { d: Math.floor(s / 86400), h: Math.floor(s % 86400 / 3600), m: Math.floor(s % 3600 / 60), s: s % 60 };
}
function pad2(n) { return String(n).padStart(2, "0"); }
function renderCountdowns() {
  qsa("[data-countend]").forEach(function (el) {
    var end = parseInt(el.getAttribute("data-countend"), 10);
    var mode = el.getAttribute("data-countmode") || "ends";
    var t = timeParts(end - Date.now());
    var html =
      '<div class="count-grid">' +
      (t.d > 0 ? '<div class="count-cell"><b>' + t.d + '</b><span>DAY</span></div>' : "") +
      '<div class="count-cell"><b>' + pad2(t.h) + '</b><span>HRS</span></div>' +
      '<div class="count-cell"><b>' + pad2(t.m) + '</b><span>MIN</span></div>' +
      '<div class="count-cell"><b>' + pad2(t.s) + '</b><span>SEC</span></div>' +
      "</div>";
    el.innerHTML = '<small>' + (t.d > 0 ? (mode === "starts" ? "STARTS IN" : "TIME LEFT") : (mode === "starts" ? "STARTS IN" : "ENDS IN")) + '</small>' + html;
    if (end - Date.now() <= 0) el.innerHTML = '<small>' + mode.toUpperCase() + '</small><div class="count-grid"><div class="count-cell"><b>00</b><span>HRS</span></div><div class="count-cell"><b>00</b><span>MIN</span></div><div class="count-cell"><b>00</b><span>SEC</span></div></div>';
  });
}

/* ---------- toasts ---------- */
function toast(msg, type) {
  var root = qs("#toastRoot");
  var el = document.createElement("div");
  el.className = "toast " + (type || "info");
  el.innerHTML = '<span>' + (type === "ok" ? "✅" : type === "err" ? "⚠️" : "💡") + '</span><span>' + msg + "</span>";
  root.appendChild(el);
  setTimeout(function () {
    el.classList.add("out");
    setTimeout(function () { el.remove(); }, 320);
  }, 3400);
}

/* ---------- modal ---------- */
function openModal(html, maxW) {
  var root = qs("#modalRoot");
  root.innerHTML = '<div class="modal-overlay" onclick="overlayClose(event)"><div class="modal" style="max-width:' + (maxW || 640) + 'px" onclick="event.stopPropagation()">' + html + '</div></div>';
  document.body.style.overflow = "hidden";
}
function closeModal() {
  qs("#modalRoot").innerHTML = "";
  document.body.style.overflow = "";
}
function overlayClose(ev) { if (ev.target.classList.contains("modal-overlay")) closeModal(); }
function modalHead(title, sub) {
  return '<div class="modal-head"><div><h3>' + title + "</h3>" + (sub ? "<p>" + sub + "</p>" : "") + '</div><button class="modal-x" onclick="closeModal()">✕</button></div>';
}
document.addEventListener("keydown", function (ev) { if (ev.key === "Escape") { closeModal(); closeLightbox(); } });

/* ---------- CSV download ---------- */
function downloadCSV(filename, rows) {
  var csv = rows.map(function (r) {
    return r.map(function (c) { return '"' + String(c == null ? "" : c).replace(/"/g, '""') + '"'; }).join(",");
  }).join("\n");
  var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  var a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a); a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 400);
  toast("CSV downloaded — " + filename, "ok");
}

/* ---------- canvas helpers ---------- */
function loadImg(src) {
  return new Promise(function (res, rej) {
    var im = new Image();
    im.onload = function () { res(im); };
    im.onerror = rej;
    im.src = src;
  });
}
function canvasDownload(canvas, filename) {
  try {
    var a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    toast("Downloaded — " + filename, "ok");
  } catch (e) {
    toast("Download blocked in this preview. Open the served site or the standalone file to download.", "err");
  }
}
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
/* pseudo-barcode from an ID string (decorative) */
function drawBarcode(ctx, text, x, y, w, h) {
  var seed = 0;
  for (var i = 0; i < text.length; i++) seed = (seed * 31 + text.charCodeAt(i)) >>> 0;
  var rand = function () { seed = (seed * 1103515245 + 12345) >>> 0; return (seed >>> 8) / 16777216; };
  var cx = x;
  ctx.fillStyle = "#0b1f3a";
  while (cx < x + w - 4) {
    var bw = 1 + Math.floor(rand() * 4);
    ctx.fillRect(cx, y, bw, h);
    cx += bw + 1 + Math.floor(rand() * 4);
  }
  ctx.font = "600 16px monospace";
  ctx.fillStyle = "#5b6b85";
  ctx.textAlign = "center";
  ctx.fillText(text, x + w / 2, y + h + 24);
  ctx.textAlign = "left";
}

/* ---------- certificate renderer ---------- */
const CERT_W = 1600, CERT_H = 1131;
async function renderCertificate(cert) {
  var ev = DB.events.find(function (e) { return e.id === cert.eventId; });
  var canvas = document.createElement("canvas");
  canvas.width = CERT_W; canvas.height = CERT_H;
  var ctx = canvas.getContext("2d");
  // parchment bg
  var g = ctx.createLinearGradient(0, 0, CERT_W, CERT_H);
  g.addColorStop(0, "#fffdf6"); g.addColorStop(0.5, "#ffffff"); g.addColorStop(1, "#f6f9ff");
  ctx.fillStyle = g; ctx.fillRect(0, 0, CERT_W, CERT_H);
  // double frame
  ctx.strokeStyle = "#0b1f3a"; ctx.lineWidth = 10; ctx.strokeRect(38, 38, CERT_W - 76, CERT_H - 76);
  ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 3; ctx.strokeRect(58, 58, CERT_W - 116, CERT_H - 116);
  // corner accents
  ctx.fillStyle = "#c9a227";
  [[38, 38], [CERT_W - 78, 38], [38, CERT_H - 78], [CERT_W - 78, CERT_H - 78]].forEach(function (p) {
    ctx.fillRect(p[0], p[1], 40, 8); ctx.fillRect(p[0], p[1], 8, 40);
  });
  // watermark logo
  try {
    var logo = await loadImg(A("assets/img/logo.png"));
    ctx.globalAlpha = 0.075;
    var wl = 430;
    ctx.drawImage(logo, (CERT_W - wl) / 2, (CERT_H - wl) / 2 + 30, wl, wl * logo.height / logo.width);
    ctx.globalAlpha = 1;
  } catch (e) { }
  // header
  ctx.textAlign = "center";
  try {
    var logo2 = await loadImg(A("assets/img/logo.png"));
    var lh = 120, lw = lh * logo2.width / logo2.height;
    ctx.drawImage(logo2, (CERT_W - lw) / 2, 88, lw, lh);
  } catch (e) { }
  ctx.fillStyle = "#0b1f3a";
  ctx.font = "800 30px Poppins, Arial";
  ctx.fillText("M.H. SABOO SIDDIK COLLEGE OF ENGINEERING, MUMBAI", CERT_W / 2, 250);
  ctx.font = "600 19px Poppins, Arial";
  ctx.fillStyle = "#5b6b85";
  ctx.fillText("Anjuman-I-Islam's  •  Approved by AICTE  •  Affiliated to University of Mumbai", CERT_W / 2, 282);
  // title
  ctx.font = "800 62px Poppins, Arial";
  var grad = ctx.createLinearGradient(CERT_W / 2 - 300, 0, CERT_W / 2 + 300, 0);
  grad.addColorStop(0, "#0b1f3a"); grad.addColorStop(1, "#1d5bd8");
  ctx.fillStyle = grad;
  ctx.fillText("CERTIFICATE OF " + (cert.achievement === "Participant" ? "PARTICIPATION" : "ACHIEVEMENT"), CERT_W / 2, 380);
  ctx.font = "500 22px Poppins, Arial";
  ctx.fillStyle = "#5b6b85";
  ctx.fillText("This certificate is proudly presented to", CERT_W / 2, 448);
  // name
  ctx.font = "800 74px Poppins, Arial";
  ctx.fillStyle = "#1d5bd8";
  ctx.fillText(cert.name, CERT_W / 2, 545);
  // underline
  ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 4;
  var nw = ctx.measureText(cert.name).width;
  ctx.beginPath(); ctx.moveTo(CERT_W / 2 - nw / 2 - 30, 570); ctx.lineTo(CERT_W / 2 + nw / 2 + 30, 570); ctx.stroke();
  // body
  ctx.font = "500 24px Poppins, Arial";
  ctx.fillStyle = "#31415f";
  ctx.fillText("for " + (cert.achievement === "Participant" ? "active participation in" : "securing the position of " + cert.achievement + " in"), CERT_W / 2, 635);
  ctx.font = "800 40px Poppins, Arial";
  ctx.fillStyle = "#0b1f3a";
  ctx.fillText(ev ? ev.title : "College Event", CERT_W / 2, 700);
  if (ev) {
    ctx.font = "600 22px Poppins, Arial";
    ctx.fillStyle = "#5b6b85";
    ctx.fillText(fmtDateRange(ev) + "  •  " + ev.venue, CERT_W / 2, 740);
  }
  if (cert.project) {
    ctx.font = "600 22px Poppins, Arial";
    ctx.fillStyle = "#31415f";
    ctx.fillText("Project: " + cert.project, CERT_W / 2, 786);
  }
  // issue info
  ctx.font = "600 20px Poppins, Arial";
  ctx.fillStyle = "#5b6b85";
  ctx.fillText("Issued on " + fmtDate(cert.date) + "  •  Organised by " + (ev && ev.clubId ? clubName(ev.clubId) : "MHSSCE"), CERT_W / 2, 830);
  // signatures
  ctx.strokeStyle = "#94a3b8"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(300, 960); ctx.lineTo(620, 960); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(CERT_W - 620, 960); ctx.lineTo(CERT_W - 300, 960); ctx.stroke();
  ctx.font = "700 22px Poppins, Arial";
  ctx.fillStyle = "#0b1f3a";
  ctx.fillText("Faculty Coordinator", 460, 995);
  ctx.fillText("Principal, MHSSCE", CERT_W - 460, 995);
  ctx.font = "500 17px Poppins, Arial";
  ctx.fillStyle = "#5b6b85";
  ctx.fillText("EventHub · College Events Portal", 460, 1022);
  ctx.fillText("Verify at eventhub.mhssce.ac.in/verify", CERT_W - 460, 1022);
  // cert id + barcode
  drawBarcode(ctx, cert.id, CERT_W / 2 - 190, 930, 380, 56);
  return canvas;
}
async function openCertificate(certId) {
  var cert = DB.certificates.find(function (c) { return c.id === certId; });
  if (!cert) return toast("Certificate not found", "err");
  openModal(modalHead("🏆 Certificate — " + esc(cert.id), esc(cert.name) + " · " + esc(cert.achievement)) +
    '<div class="modal-body" id="certCanvasWrap" style="text-align:center"><div class="spinner" style="border-color:#cbd5e4;border-top-color:#1d5bd8"></div></div>' +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Close</button>' +
    '<button class="btn btn-primary" onclick="downloadCert(\'' + cert.id + '\')">⬇ Download PNG</button></div>', 900);
  var canvas = await renderCertificate(cert);
  canvas.style.cssText = "width:100%;height:auto;border-radius:10px;box-shadow:0 10px 40px rgba(11,31,58,.18)";
  var wrap = qs("#certCanvasWrap");
  if (wrap) { wrap.innerHTML = ""; wrap.appendChild(canvas); }
}
function downloadCert(certId) {
  var cert = DB.certificates.find(function (c) { return c.id === certId; });
  if (!cert) return;
  renderCertificate(cert).then(function (canvas) { canvasDownload(canvas, cert.id + ".png"); });
}

/* ---------- registration confirmation renderer ---------- */
async function renderConfirmation(reg) {
  var ev = DB.events.find(function (e) { return e.id === reg.eventId; });
  var canvas = document.createElement("canvas");
  canvas.width = 1400; canvas.height = 990;
  var ctx = canvas.getContext("2d");
  ctx.fillStyle = "#f5f7fb"; ctx.fillRect(0, 0, 1400, 990);
  ctx.fillStyle = "#ffffff"; roundRect(ctx, 30, 30, 1340, 930, 24); ctx.fill();
  ctx.strokeStyle = "#0b1f3a"; ctx.lineWidth = 6; roundRect(ctx, 30, 30, 1340, 930, 24); ctx.stroke();
  // header band
  var g = ctx.createLinearGradient(30, 30, 1370, 190);
  g.addColorStop(0, "#0b1f3a"); g.addColorStop(1, "#1d5bd8");
  ctx.fillStyle = g;
  roundRect(ctx, 30, 30, 1340, 160, 24); ctx.fill();
  ctx.fillRect(30, 140, 1340, 50);
  try {
    var logo = await loadImg(A("assets/img/logo.png"));
    var lh = 96, lw = lh * logo.width / logo.height;
    ctx.drawImage(logo, 70, 62, lw, lh);
  } catch (e) { }
  ctx.fillStyle = "#fff"; ctx.textAlign = "left";
  ctx.font = "800 34px Poppins, Arial";
  ctx.fillText("MHSSCE EVENTHUB", 230, 105);
  ctx.font = "600 19px Poppins, Arial"; ctx.fillStyle = "#c8d5ea";
  ctx.fillText("Event Registration Confirmation", 230, 140);
  ctx.font = "800 26px Poppins, Arial"; ctx.fillStyle = "#9fe0bb";
  ctx.textAlign = "right";
  ctx.fillText("✔ CONFIRMED", 1330, 120);
  ctx.textAlign = "left";
  // rows
  var rows = [
    ["Registration ID", reg.id],
    ["Event", ev ? ev.title : "-"],
    ["Date & Time", ev ? (fmtDateRange(ev) + " · " + fmtTime12(ev.timeStart)) : "-"],
    ["Venue", ev ? ev.venue : "-"],
    ["Participant", reg.name + (reg.teamName ? "  (Team: " + reg.teamName + ")" : "")],
    ["PRN / Roll No", reg.prn + "  ·  " + reg.branch + "  ·  " + (YEAR_FULL[reg.year] || reg.year)],
    ["Participation", reg.type === "team" ? "Team of " + (1 + (reg.members || []).length) : "Individual"],
    ["Entry Fee", reg.fee > 0 ? "₹" + reg.fee + " — Paid ✓" : "Free Event"],
    ["Registered on", fmtDate(reg.date)]
  ];
  var y = 260;
  rows.forEach(function (r) {
    ctx.font = "700 20px Poppins, Arial"; ctx.fillStyle = "#8595ad";
    ctx.fillText(r[0].toUpperCase(), 90, y);
    ctx.font = "700 24px Poppins, Arial"; ctx.fillStyle = "#16233b";
    var val = String(r[1]);
    if (val.length > 58) val = val.slice(0, 55) + "…";
    ctx.fillText(val, 560, y);
    y += 62;
  });
  if (reg.members && reg.members.length) {
    ctx.font = "700 20px Poppins, Arial"; ctx.fillStyle = "#8595ad";
    ctx.fillText("TEAM MEMBERS", 90, y);
    ctx.font = "600 21px Poppins, Arial"; ctx.fillStyle = "#16233b";
    ctx.fillText(reg.members.join(", "), 560, y);
    y += 62;
  }
  drawBarcode(ctx, reg.id, 480, y + 20, 440, 54);
  ctx.font = "500 17px Poppins, Arial"; ctx.fillStyle = "#8595ad"; ctx.textAlign = "center";
  ctx.fillText("Show this confirmation at the venue for attendance. Verify at eventhub.mhssce.ac.in/verify", 700, 920);
  return canvas;
}

/* ---------- simple canvas charts ---------- */
function drawBarChart(canvas, labels, values, color) {
  var W = canvas.width = 640, H = canvas.height = 330;
  var ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);
  var pad = { l: 46, r: 16, t: 18, b: 64 };
  var max = Math.max.apply(null, values.concat([10]));
  var iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  // grid
  ctx.strokeStyle = "#eef1f6"; ctx.fillStyle = "#8595ad"; ctx.font = "600 12px Poppins, Arial"; ctx.textAlign = "right";
  for (var i = 0; i <= 4; i++) {
    var gy = pad.t + ih - ih * i / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, gy); ctx.lineTo(W - pad.r, gy); ctx.stroke();
    ctx.fillText(String(Math.round(max * i / 4)), pad.l - 8, gy + 4);
  }
  var bw = iw / values.length;
  values.forEach(function (v, idx) {
    var bh = Math.max(4, ih * v / max);
    var x = pad.l + bw * idx + bw * 0.18, y = pad.t + ih - bh;
    var w = bw * 0.64;
    var grad = ctx.createLinearGradient(0, y, 0, y + bh);
    grad.addColorStop(0, "#2e7cf6"); grad.addColorStop(1, color || "#0b1f3a");
    ctx.fillStyle = grad;
    roundRect(ctx, x, y, w, bh, 6); ctx.fill();
    ctx.fillStyle = "#5b6b85"; ctx.textAlign = "center"; ctx.font = "600 11.5px Poppins, Arial";
    var label = labels[idx].length > 14 ? labels[idx].slice(0, 13) + "…" : labels[idx];
    var words = label.split(" ");
    if (words.length > 1) {
      ctx.fillText(words[0], x + w / 2, H - pad.b + 18);
      ctx.fillText(words.slice(1).join(" ").slice(0, 13), x + w / 2, H - pad.b + 32);
    } else ctx.fillText(label, x + w / 2, H - pad.b + 18);
    ctx.fillStyle = "#0b1f3a"; ctx.font = "800 12.5px Poppins, Arial";
    ctx.fillText(String(v), x + w / 2, y - 7);
  });
}
function drawDonut(canvas, items) {
  var W = canvas.width = 640, H = canvas.height = 330;
  var ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);
  var cx = 165, cy = 165, r = 100;
  var total = items.reduce(function (s, it) { return s + it.value; }, 0) || 1;
  var colors = ["#1d5bd8", "#7048e8", "#12b76a", "#f59e0b", "#e5484d", "#0ea5e9", "#8595ad"];
  var a0 = -Math.PI / 2;
  items.forEach(function (it, i) {
    var frac = it.value / total;
    var a1 = a0 + frac * Math.PI * 2;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, a0, a1); ctx.closePath();
    ctx.fillStyle = colors[i % colors.length]; ctx.fill();
    a0 = a1;
  });
  ctx.beginPath(); ctx.arc(cx, cy, 62, 0, Math.PI * 2);
  ctx.fillStyle = "#fff"; ctx.fill();
  ctx.fillStyle = "#0b1f3a"; ctx.font = "800 26px Poppins, Arial"; ctx.textAlign = "center";
  ctx.fillText(String(total), cx, cy + 2);
  ctx.font = "600 12px Poppins, Arial"; ctx.fillStyle = "#8595ad";
  ctx.fillText("REGISTRATIONS", cx, cy + 24);
  // legend
  ctx.textAlign = "left";
  var ly = 52;
  items.forEach(function (it, i) {
    ctx.fillStyle = colors[i % colors.length];
    roundRect(ctx, 330, ly - 12, 14, 14, 4); ctx.fill();
    ctx.fillStyle = "#16233b"; ctx.font = "600 14px Poppins, Arial";
    ctx.fillText(it.label + " — " + it.value, 354, ly);
    ly += 34;
  });
}

/* ---------- leaderboard points engine ---------- */
function computeLeaderboard() {
  var rows = {};
  DB.users.forEach(function (u) { if (u.role === "student") rows[u.id] = { user: u, pts: 0, wins: 0, events: 0 }; });
  // participation: +10 per registration (team registrant counts for their team entry)
  DB.registrations.forEach(function (r) {
    if (rows[r.userId]) { rows[r.userId].pts += POINTS.participation; rows[r.userId].events++; }
  });
  // results: winner 100 / runner 70 / third 50 / finalist 40 per member
  DB.results.forEach(function (res) {
    if (res.pos === 0) return;
    var pts = POINTS[res.pos] != null ? POINTS[res.pos] : POINTS.finalist;
    (res.members || []).forEach(function (m) {
      var u = DB.users.find(function (x) { return x.name.toLowerCase() === m.toLowerCase() && x.role === "student"; });
      if (u && rows[u.id]) { rows[u.id].pts += pts; if (res.pos === 1) rows[u.id].wins++; }
    });
  });
  return Object.keys(rows).map(function (k) { return rows[k]; })
    .filter(function (r) { return r.pts > 0; })
    .sort(function (a, b) { return b.pts - a.pts; });
}
function userRank(userId) {
  var lb = computeLeaderboard();
  var idx = lb.findIndex(function (r) { return r.user.id === userId; });
  return idx >= 0 ? idx + 1 : null;
}

/* ---------- reveal-on-scroll + counters ---------- */
function initReveal(root) {
  var els = qsa(".reveal");
  if (!("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("in"); }); return; }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
    });
  }, { threshold: 0.12 });
  els.forEach(function (e) { io.observe(e); });
}
function animateCounters(rootSel) {
  qsa((rootSel || "") + " .count-up").forEach(function (el) {
    var target = parseInt(el.getAttribute("data-target"), 10) || 0;
    var suffix = el.getAttribute("data-suffix") || "";
    var t0 = null, dur = 1300;
    function step(ts) {
      if (!t0) t0 = ts;
      var p = Math.min(1, (ts - t0) / dur);
      p = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * p).toLocaleString("en-IN") + suffix;
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
}
