/* ═══════════════════════════════════════════════════════════════
   MHSSCE EVENTHUB — Public pages
   ═══════════════════════════════════════════════════════════════ */

let PENDING_REG = null;   // event id to resume registration after login
let EF = { tab: "upcoming", cat: "All", q: "", sort: "date" };   // events page filter state

/* ═══════════════ HOME ═══════════════ */
function pageHome() {
  var published = DB.events.filter(function (e) { return e.published !== false; });
  var liveEvents = published.filter(function (e) { return getStatus(e).key === "live"; });
  var upcoming = published.filter(function (e) { var k = getStatus(e).key; return k === "open" || k === "closed"; })
    .sort(function (a, b) { return evStart(a) - evStart(b); }).slice(0, 3);
  var cats = CATEGORIES.map(function (c) {
    return { c: c, n: published.filter(function (e) { return e.cat === c; }).length };
  });
  var recentWinners = DB.results.filter(function (r) { return r.pos === 1; })
    .sort(function (a, b) { var ea = eventById(a.eventId), eb = eventById(b.eventId); return evEnd(eb) - evEnd(ea); })
    .slice(0, 3);
  var totalParticipants = published.reduce(function (s, e) { return s + joinedCount(e); }, 0) + 4820;
  var prizePool = published.reduce(function (s, e) { return s + (e.prizes || []).reduce(function (x, p) { return x + (p.amt || 0); }, 0); }, 0);
  var photos = DB.gallery.slice(0, 6);

  var html =
  /* HERO */
  '<section class="hero"><div class="hero-bg" style="background-image:url(\'' + A("assets/img/hero.jpg") + '\')"></div>' +
  '<div class="container hero-inner">' +
  '<span class="hero-eyebrow"><span class="dot"></span> ' + (liveEvents.length ? "Live now: " + esc(liveEvents[0].title) : "Registrations open — Hackathon 2026") + "</span>" +
  "<h1>EXPERIENCE.<br>PARTICIPATE. <span class='accent'>WIN.</span></h1>" +
  '<p class="sub">Your college\u2019s event ecosystem — discover every hackathon, fest, workshop, seminar and club activity happening at M.H. Saboo Siddik College of Engineering.</p>' +
  '<div class="hero-cta"><a class="btn btn-primary" href="#/events">Explore Events →</a><a class="btn btn-outline-light" href="#/results">🏆 View Results</a></div>' +
  '<div class="hero-stats">' +
  '<div class="hero-stat"><b>' + published.length + '+</b><span>Events hosted</span></div>' +
  '<div class="hero-stat"><b>' + (totalParticipants > 999 ? (totalParticipants / 1000).toFixed(1) + "k" : totalParticipants) + '</b><span>Participants</span></div>' +
  '<div class="hero-stat"><b>' + DB.clubs.length + '</b><span>Active clubs</span></div>' +
  "</div></div></section>";

  /* LIVE STRIP */
  if (liveEvents.length) {
    var le = liveEvents[0];
    html +=
    '<div class="container live-strip"><div class="live-card reveal">' +
    '<div style="flex:1;min-width:240px"><span class="lc-badge"><span class="dot"></span> HAPPENING NOW</span>' +
    "<h3>" + esc(le.title) + "</h3>" +
    '<div class="muted" style="font-weight:600">' + esc(le.tagline) + "</div>" +
    '<div class="lc-meta"><span>📍 ' + esc(le.venue) + "</span><span>👥 " + joinedCount(le) + " participants</span><span>💻 " + esc(clubName(le.clubId)) + "</span></div></div>" +
    '<div class="live-count" data-countend="' + evEnd(le) + '" data-countmode="ends"></div>' +
    '<a class="btn btn-danger" href="#/event/' + le.id + '">View Event →</a>' +
    "</div></div>";
  }

  /* UPCOMING */
  html += '<section class="section container"><div id="homeUpcoming">' +
    sectionHead("Don't miss out", "Upcoming Events", "Register before seats fill up",
      '<a class="btn btn-ghost btn-sm" href="#/events">View all events →</a>') +
    '<div class="grid-3">' + upcoming.map(eventCard).join("") + "</div></div></section>";

  /* CATEGORIES */
  html += '<section class="section container reveal">' +
    sectionHead("Browse by", "Event Categories", "Something for every kind of talent") +
    '<div class="chip-row">' + cats.map(function (x) {
      return '<a class="chip" href="#/events?cat=' + encodeURIComponent(x.c) + '">' + x.c + ' <span class="n">' + x.n + "</span></a>";
    }).join("") + "</div></section>";

  /* RECENT WINNERS */
  html += '<section class="section container">' +
    sectionHead("Hall of fame", "🏆 Recent Winners", "Teams and stars who made the college proud",
      '<a class="btn btn-ghost btn-sm" href="#/results">All results →</a>') +
    '<div class="grid-3">' + recentWinners.map(function (r) { return winnerCard(r, eventById(r.eventId)); }).join("") + "</div></section>";

  /* STATS BAND */
  html += '<section class="section container"><div class="stats-band reveal in">' +
    '<div class="stat-cell"><b class="count-up" data-target="' + published.length + '" data-suffix="+">0</b><span>Events</span></div>' +
    '<div class="stat-cell"><b class="count-up" data-target="' + totalParticipants + '" data-suffix="+">0</b><span>Participants</span></div>' +
    '<div class="stat-cell"><b class="count-up" data-target="' + DB.clubs.length + '" data-suffix="+">0</b><span>Clubs</span></div>' +
    '<div class="stat-cell"><b>₹<span class="count-up" data-target="' + Math.round(prizePool / 1000) + '">0</span>k+</b><span>Prize pool</span></div>' +
    "</div></section>";

  /* GALLERY STRIP */
  html += '<section class="section container">' +
    sectionHead("Moments", "📸 Event Gallery", "Memories from our recent events",
      '<a class="btn btn-ghost btn-sm" href="#/gallery">Open gallery →</a>') +
    '<div class="gallery-grid">' + photos.map(function (p, i) {
      return '<div class="g-item reveal" onclick="openLightbox(DB.gallery.slice(0,6),' + i + ')"><img src="' + A(p.img) + '" alt="" loading="lazy"><div class="g-cap">' + esc(p.caption) + "</div></div>";
    }).join("") + "</div></section>";

  /* CTA for organizers */
  html += '<section class="section container"><div class="register-panel reveal" style="display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap;padding:36px 40px">' +
    '<div><h3 style="font-size:24px;margin-bottom:6px">Planning a club or college event?</h3>' +
    '<p style="color:#c8d5ea;max-width:520px">Organizers can publish events, track registrations, upload results and issue certificates — all from one dashboard.</p></div>' +
    '<div class="flex"><a class="btn btn-light" href="#/login">Open Organizer Panel</a><a class="btn btn-outline-light" href="#/about">Learn more</a></div>' +
    "</div></section>";

  return html;
}

/* ═══════════════ EVENTS PAGE ═══════════════ */
function pageEvents(params) {
  if (params && params.tab) EF.tab = params.tab;
  if (params && params.cat) EF.cat = params.cat;
  var html =
    '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">Events</h1><p class="page-sub">Every event at MHSSCE — live, upcoming and completed.</p>' +
    '<div class="mt-3 flex-between">' +
    '<div class="tabs">' +
    '<button class="tab ' + (EF.tab === "live" ? "active" : "") + '" onclick="setEventsTab(\'live\')"><span class="t-dot" style="background:#e5484d"></span>Live</button>' +
    '<button class="tab ' + (EF.tab === "upcoming" ? "active" : "") + '" onclick="setEventsTab(\'upcoming\')"><span class="t-dot" style="background:#12b76a"></span>Upcoming</button>' +
    '<button class="tab ' + (EF.tab === "completed" ? "active" : "") + '" onclick="setEventsTab(\'completed\')"><span class="t-dot" style="background:#667085"></span>Completed</button>' +
    "</div>" +
    '<a class="btn btn-ghost btn-sm" href="#/archive">📕 Event Archive</a>' +
    "</div>" +
    '<div class="mt-3 filter-bar">' +
    '<div class="search-box"><input placeholder="Search events, clubs, venues…" value="' + esc(EF.q) + '" oninput="EF.q=this.value;renderEventsList()"></div>' +
    '<label>Category</label><select onchange="EF.cat=this.value;renderEventsList()">' +
    ["All"].concat(CATEGORIES).map(function (c) { return "<option " + (EF.cat === c ? "selected" : "") + ">" + c + "</option>"; }).join("") + "</select>" +
    '<label>Sort</label><select onchange="EF.sort=this.value;renderEventsList()">' +
    '<option value="date" ' + (EF.sort === "date" ? "selected" : "") + ">Date</option>" +
    '<option value="popularity" ' + (EF.sort === "popularity" ? "selected" : "") + ">Popularity</option>" +
    '<option value="fee" ' + (EF.sort === "fee" ? "selected" : "") + ">Registration fee</option>" +
    "</select></div>" +
    '<div id="eventsList"></div></div>';
  setTimeout(renderEventsList, 0);
  return html;
}
function setEventsTab(t) { EF.tab = t; route(); }
function filteredEvents() {
  var now = Date.now();
  var list = DB.events.filter(function (e) { return e.published !== false; });
  if (EF.tab === "live") list = list.filter(function (e) { return getStatus(e).key === "live"; });
  if (EF.tab === "upcoming") list = list.filter(function (e) { var k = getStatus(e).key; return k === "open" || k === "closed"; });
  if (EF.tab === "completed") list = list.filter(function (e) { var k = getStatus(e).key; return k === "done" || k === "results"; });
  if (EF.cat && EF.cat !== "All") list = list.filter(function (e) { return e.cat === EF.cat; });
  if (EF.q) {
    var q = EF.q.toLowerCase();
    list = list.filter(function (e) {
      return (e.title + " " + e.tagline + " " + e.venue + " " + clubName(e.clubId) + " " + e.cat).toLowerCase().indexOf(q) >= 0;
    });
  }
  var dir = EF.tab === "completed" ? -1 : 1;
  if (EF.sort === "date") list.sort(function (a, b) { return dir * (evStart(a) - evStart(b)); });
  if (EF.sort === "popularity") list.sort(function (a, b) { return joinedCount(b) - joinedCount(a); });
  if (EF.sort === "fee") list.sort(function (a, b) { return a.fee - b.fee; });
  return list;
}
function renderEventsList() {
  var box = qs("#eventsList");
  if (!box) return;
  var list = filteredEvents();
  var labels = { live: "live right now", upcoming: "open for registration", completed: "completed" };
  box.innerHTML = list.length
    ? '<p class="muted small mb-2">' + list.length + " event(s) " + labels[EF.tab] + "</p>" +
      '<div class="grid-3">' + list.map(eventCard).join("") + "</div>"
    : emptyState("🔍", "No events found", "Try changing the filters or search term.", '<a class="btn btn-ghost btn-sm" href="#/events" onclick="EF={tab:\'' + EF.tab + '\',cat:\'All\',q:\'\',sort:\'date\'}">Reset filters</a>');
  initReveal();
}

/* ═══════════════ EVENT DETAIL ═══════════════ */
function pageEventDetail(id) {
  var e = eventById(id);
  if (!e) return '<div class="container">' + emptyState("🤷", "Event not found", "It may have been removed.", '<a class="btn btn-primary" href="#/events">Browse events</a>') + "</div>";
  var club = clubOf(e.clubId);
  var st = getStatus(e);
  var joined = joinedCount(e);
  var u = currentUser();
  var already = u && DB.registrations.some(function (r) { return r.eventId === e.id && r.userId === u.id; });
  var regs = participantsOf(e.id);
  var teams = regs.filter(function (r) { return r.type === "team"; }).length;

  var cta;
  if (already) {
    cta = '<button class="btn btn-light btn-block" disabled>✓ You are registered</button><a class="btn btn-outline-light btn-block mt-1" href="#/dashboard">View my registration →</a>';
  } else if (st.key === "open") {
    cta = '<button class="btn btn-primary btn-block" style="background:#12b76a;box-shadow:0 8px 20px -8px rgba(18,183,106,.6)" onclick="startRegistration(\'' + e.id + '\')">REGISTER NOW →</button>';
  } else if (st.key === "live") {
    cta = '<button class="btn btn-light btn-block" disabled>🔴 Happening now — registration closed</button>';
  } else if (st.key === "closed") {
    cta = '<button class="btn btn-light btn-block" disabled>Registration closed</button>';
  } else {
    cta = '<a class="btn btn-light btn-block" href="#/results">🏆 View Results</a>';
  }

  var countdown = "";
  if (st.key === "live") countdown = '<div style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);border-radius:14px;padding:12px;margin-bottom:14px" data-countend="' + evEnd(e) + '" data-countmode="ends"></div>';
  else if (st.key === "open" || st.key === "closed") countdown = '<div style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);border-radius:14px;padding:12px;margin-bottom:14px" data-countend="' + evStart(e) + '" data-countmode="starts"></div>';

  var regPct = e.maxPart ? Math.min(100, Math.round(joined / e.maxPart * 100)) : 0;

  var html =
    '<div class="container" style="padding-top:28px">' +
    '<a class="back-link" href="javascript:history.back()">← Back</a>' +
    '<div class="detail-hero"><img class="dh-img" src="' + A(e.banner) + '" alt="' + esc(e.title) + '">' +
    '<div class="dh-content"><div>' +
    '<div class="flex" style="gap:8px;flex-wrap:wrap">' + badgeHTML(e) + '<span class="badge badge-gold">' + esc(e.cat) + "</span>" +
    (club ? '<span class="badge badge-purple">' + club.emoji + " " + esc(club.name) + "</span>" : "") + "</div>" +
    "<h1>" + esc(e.title) + "</h1>" +
    '<div class="tagline">' + esc(e.tagline || "") + "</div></div>" +
    '<button class="btn btn-light" onclick="shareEvent(\'' + e.id + '\')">🔗 Share</button>' +
    "</div></div>" +

    '<div class="detail-grid"><div>' +
    '<div class="panel reveal in"><div class="meta-grid">' +
    '<div class="meta-item"><small>📅 Date</small><b>' + fmtDateRange(e) + "</b></div>" +
    '<div class="meta-item"><small>⏰ Time</small><b>' + fmtTime12(e.timeStart) + " – " + fmtTime12(e.timeEnd) + "</b></div>" +
    '<div class="meta-item"><small>📍 Venue</small><b>' + esc(e.venue) + "</b></div>" +
    '<div class="meta-item"><small>👥 Team size</small><b>' + (e.teamMin === e.teamMax ? e.teamMin : e.teamMin + "–" + e.teamMax) + " members</b></div>" +
    '<div class="meta-item"><small>💰 Entry fee</small><b>' + fmtMoney(e.fee) + (e.fee ? " /team" : "") + "</b></div>" +
    '<div class="meta-item"><small>🎯 Eligibility</small><b>' + esc(e.eligibility || "Open to all") + "</b></div>" +
    "</div></div>" +

    '<div class="panel reveal"><h3>📖 About the event</h3><p style="color:#3d4c66;line-height:1.75">' + esc(e.desc) + "</p></div>" +

    (e.prizes && e.prizes.length ?
    '<div class="panel reveal"><h3>🏆 Prizes</h3>' + e.prizes.map(function (p) {
      return '<div class="prize-row p' + p.pos + '"><span>' + (POS_MEDAL[p.pos] || "🏅") + " " + (p.label || ({ 1: "1st Prize", 2: "2nd Prize", 3: "3rd Prize" }[p.pos]) || "Prize") + "</span><span class='amt'>" + (p.amt > 0 ? "₹" + p.amt.toLocaleString("en-IN") : esc(p.label || "Award")) + "</span></div>";
    }).join("") + "</div>" : "") +

    (e.rules && e.rules.length ?
    '<div class="panel reveal"><h3>📋 Rules</h3><ul class="rules-list">' + e.rules.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ul></div>" : "") +

    '<div class="panel reveal"><h3>📅 Event schedule</h3><div class="schedule">' +
    e.schedule.map(function (s) { return '<div class="sched-item"><b class="time">' + esc(s.time) + "</b><span>" + esc(s.label) + "</span></div>"; }).join("") +
    "</div></div>" +

    '<div class="panel reveal"><h3>👥 Organizers</h3>' +
    e.organizers.map(function (o) {
      return '<div class="org-row"><span class="avatar">' + initials(o.name) + '</span><div><b>' + esc(o.name) + '</b><div class="t-sub">' + esc(o.role) + "</div></div></div>";
    }).join("") + "</div>" +

    '<div class="panel reveal"><div class="flex-between"><h3 style="margin:0">👤 Participants</h3>' +
    '<a class="btn btn-ghost btn-sm" href="#/participants/' + e.id + '">View all participants →</a></div>' +
    '<div class="meta-grid mt-2">' +
    '<div class="meta-item"><small>Total registered</small><b>' + joined + "</b></div>" +
    '<div class="meta-item"><small>Teams</small><b>' + teams + "</b></div>" +
    '<div class="meta-item"><small>Individuals</small><b>' + (regs.length - teams) + "</b></div>" +
    "</div></div>" +
    "</div>" +

    /* side */
    '<div><div class="side-sticky"><div class="register-panel">' +
    "<small style='letter-spacing:.14em;color:#9db1cd;font-weight:800'>ENTRY FEE</small>" +
    '<div class="rp-fee">' + fmtMoney(e.fee) + (e.fee ? ' <small>/ team</small>' : "") + "</div>" +
    '<div class="mt-1" style="font-size:12.5px;color:#9db1cd">Registration closes: <b style="color:#fff">' + (e.liveDemo ? "Closed" : fmtDate(e.regDeadline || e.dateStart)) + "</b></div>" +
    '<div class="mt-2" style="font-size:12px;color:#c8d5ea;margin-bottom:6px">' + joined + " / " + (e.maxPart || "∞") + " seats filled</div>" +
    '<div class="ec-bar mb-2" style="background:rgba(255,255,255,.15)"><i style="width:' + regPct + '%"></i></div>' +
    countdown + cta +
    '<ul class="mt-2"><li>Instant confirmation with ID</li><li>Certificates for participants</li><li>Prizes worth ₹' + ((e.prizes || []).reduce(function (s, p) { return s + (p.amt || 0); }, 0)).toLocaleString("en-IN") + "</li></ul>" +
    "</div>" +
    '<div class="panel"><h3>📌 Quick info</h3>' +
    '<div class="sched-item"><b class="time">ORGANIZED BY</b><span>' + esc(clubName(e.clubId)) + "</span></div>" +
    '<div class="sched-item"><b class="time">STATUS FLOW</b><span style="font-size:12.5px" class="muted">Upcoming → Reg. Open → Live → Completed → Results</span></div>' +
    '<div class="sched-item" style="padding-bottom:0"><b class="time">QUESTIONS?</b><span class="small muted">Reach the coordinators listed above.</span></div>' +
    "</div></div></div></div></div>";
  return html;
}

/* ═══════════════ REGISTRATION FLOW ═══════════════ */
function startRegistration(eventId) {
  var e = eventById(eventId);
  if (!e) return;
  if (!regOpenFor(e)) return toast("Registration is not open for this event", "err");
  var u = currentUser();
  if (!u) {
    PENDING_REG = eventId;
    toast("Please login to register — it takes 20 seconds!", "info");
    location.hash = "#/login?next=reg";
    return;
  }
  if (u.role !== "student") return toast("Staff/organizer accounts cannot register (use a student account)", "info");
  if (DB.registrations.some(function (r) { return r.eventId === eventId && r.userId === u.id; })) {
    return toast("You are already registered for this event ✓", "info");
  }
  openRegForm(e, u);
}
function openRegForm(e, u) {
  var branchOpts = BRANCHES.map(function (b) { return "<option " + (u.branch === b ? "selected" : "") + ">" + b + "</option>"; }).join("");
  var yearOpts = YEARS.map(function (y) { return "<option " + (u.year === y ? "selected" : "") + ">" + y + " — " + YEAR_FULL[y] + "</option>"; }).join("");
  var html =
    modalHead("📝 Register for " + esc(e.title), esc(fmtDateRange(e)) + " · " + esc(e.venue) + " · " + fmtMoney(e.fee)) +
    '<div class="modal-body"><form id="regForm" onsubmit="return false">' +
    '<div class="form-grid">' +
    '<div class="field"><label>Full Name <span class="req">*</span></label><input id="rf_name" value="' + esc(u.name) + '"><div class="err">Please enter your name</div></div>' +
    '<div class="field"><label>Email <span class="req">*</span></label><input id="rf_email" type="email" value="' + esc(u.email) + '"><div class="err">Enter a valid email</div></div>' +
    '<div class="field"><label>Phone <span class="req">*</span></label><input id="rf_phone" value="' + esc(u.phone || "") + '" placeholder="98XXXXXXXX"><div class="err">Enter a valid 10-digit phone</div></div>' +
    '<div class="field"><label>PRN / Roll No <span class="req">*</span></label><input id="rf_prn" value="' + esc(u.prn || "") + '"><div class="err">PRN required</div></div>' +
    '<div class="field"><label>Branch <span class="req">*</span></label><select id="rf_branch">' + branchOpts + "</select></div>" +
    '<div class="field"><label>Year <span class="req">*</span></label><select id="rf_year">' + yearOpts + "</select></div>" +
    '<div class="field full"><label>Participation Type</label><div class="radio-cards">' +
    '<label class="radio-card sel" id="rc_ind"><input type="radio" name="ptype" value="individual" checked onchange="ptypeChange(\'individual\')"> 👤 Individual</label>' +
    '<label class="radio-card" id="rc_team"><input type="radio" name="ptype" value="team" onchange="ptypeChange(\'team\')"> 👥 Team (' + e.teamMin + "–" + e.teamMax + ")</label>" +
    "</div></div>" +
    '<div class="field full" id="teamFields" style="display:none">' +
    '<label>Team Name <span class="req">*</span></label><input id="rf_team" placeholder="e.g. Ctrl+Alt+Elite">' +
    '<label class="mt-2">Team Members <span class="muted">(comma separated names, excluding you)</span></label>' +
    '<textarea id="rf_members" rows="2" placeholder="e.g. Zoya Khan, Yash Kulkarni"></textarea>' +
    '<div class="hint">Team size allowed: ' + e.teamMin + "–" + e.teamMax + " (including you)</div></div>" +
    "</div></form></div>" +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" onclick="submitRegistration(\'' + e.id + '\')">' + (e.fee > 0 ? "Continue to Pay " + fmtMoney(e.fee) + " →" : "Submit Registration →") + "</button></div>";
  openModal(html, 700);
}
function ptypeChange(t) {
  qs("#rc_ind").classList.toggle("sel", t === "individual");
  qs("#rc_team").classList.toggle("sel", t === "team");
  qs("#teamFields").style.display = t === "team" ? "block" : "none";
}
function fieldOk(id, test) {
  var el = qs(id);
  var field = el.closest(".field");
  var val = el.value.trim();
  var ok = test(val);
  field.classList.toggle("invalid", !ok);
  return ok ? val : null;
}
function submitRegistration(eventId) {
  var e = eventById(eventId);
  var u = currentUser();
  if (!e || !u) return;
  var name = fieldOk("#rf_name", function (v) { return v.length >= 3; });
  var email = fieldOk("#rf_email", function (v) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v); });
  var phone = fieldOk("#rf_phone", function (v) { return /^[6-9]\d{9}$/.test(v.replace(/\s/g, "")); });
  var prn = fieldOk("#rf_prn", function (v) { return v.length >= 4; });
  var branch = qs("#rf_branch").value;
  var year = qs("#rf_year").value;
  var ptype = qs("input[name=ptype]:checked").value;
  var teamName = "", members = [];
  if (name == null || email == null || phone == null || prn == null) return toast("Please fix the highlighted fields", "err");
  if (ptype === "team") {
    teamName = qs("#rf_team").value.trim();
    if (teamName.length < 2) { qs("#rf_team").closest(".field").classList.add("invalid"); return toast("Team name is required", "err"); }
    members = qs("#rf_members").value.split(",").map(function (s) { return s.trim(); }).filter(Boolean);
    var size = 1 + members.length;
    if (size < e.teamMin || size > e.teamMax) return toast("Team size must be " + e.teamMin + "–" + e.teamMax + " (you currently have " + size + ")", "err");
  }
  var data = { eventId: eventId, name: name, email: email, phone: phone.replace(/\s/g, ""), prn: prn, branch: branch, year: year, type: ptype, teamName: teamName, members: members, fee: e.fee };
  if (e.fee > 0) openPayment(e, data);
  else finishRegistration(data, true);
}
function openPayment(e, data) {
  var html =
    modalHead("💳 Demo Payment — " + fmtMoney(data.fee), "Secure college payment gateway (simulated for project demo)") +
    '<div class="modal-body">' +
    '<div class="prize-row" style="background:var(--sky);border-color:#bcd2f8"><span>Ticket: ' + esc(e.title) + (data.type === "team" ? " (team)" : "") + "</span><span class='amt'>" + fmtMoney(data.fee) + "</span></div>" +
    '<div class="form-grid mt-2">' +
    '<div class="field full"><label>Card Number</label><input id="pay_card" value="4242 4242 4242 4242" class="mono"></div>' +
    '<div class="field"><label>Name on card</label><input id="pay_name" value="' + esc(data.name) + '"></div>' +
    '<div class="field"><label>Expiry / CVV</label><div class="flex"><input value="12/28" style="width:50%"> <input value="123" type="password" style="width:50%"></div></div>' +
    "</div>" +
    '<div class="note-box mt-2"><span>🧪</span><span>This is a <b>mock payment</b> for demonstration — no real money is charged. In production this plugs into Razorpay/Stripe.</span></div>' +
    "</div>" +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
    '<button class="btn btn-primary" id="payBtn" onclick="payNow(\'' + e.id + '\')">🔒 Pay ' + fmtMoney(data.fee) + "</button></div>";
  openModal(html, 620);
}
function payNow(eventId) {
  var btn = qs("#payBtn");
  var data = window.__lastPayData;
  btn.innerHTML = '<span class="spinner"></span> Processing…';
  btn.disabled = true;
  setTimeout(function () {
    btn.innerHTML = "✓ Payment successful";
    setTimeout(function () {
      if (data) finishRegistration(data, true);
    }, 500);
  }, 1400);
}
function finishRegistration(data, paid) {
  var e = eventById(data.eventId);
  var reg = {
    id: "EV2026-" + (DB.meta.regSeq++),
    eventId: data.eventId,
    userId: currentUser().id,
    name: data.name, email: data.email, phone: data.phone, prn: data.prn,
    branch: data.branch, year: data.year,
    type: data.type, teamName: data.teamName, members: data.members,
    fee: data.fee || 0, paid: !!paid, attended: false,
    date: new Date().toISOString().slice(0, 10)
  };
  DB.registrations.push(reg);
  saveDB();
  PENDING_REG = null;
  var club = clubOf(e.clubId);
  openModal(
    '<div class="success-wrap">' +
    '<div class="tick">✓</div><h3>REGISTRATION SUCCESSFUL!</h3>' +
    '<p class="muted">You are going to <b>' + esc(e.title) + "</b> 🎉</p>" +
    '<div class="reg-id-box">' + reg.id + "</div>" +
    '<div class="success-details">' +
    "<div><span>Event</span><b>" + esc(e.title) + "</b></div>" +
    "<div><span>Date</span><b>" + fmtDateRange(e) + "</b></div>" +
    "<div><span>Venue</span><b>" + esc(e.venue) + "</b></div>" +
    "<div><span>Participant</span><b>" + esc(reg.name) + (reg.teamName ? " — Team " + esc(reg.teamName) : "") + "</b></div>" +
    "<div><span>Fee</span><b>" + (reg.fee > 0 ? "₹" + reg.fee + " — Paid ✓" : "Free") + "</b></div>" +
    "<div><span>Organized by</span><b>" + esc(clubName(e.clubId)) + "</b></div>" +
    "</div>" +
    '<div class="flex" style="justify-content:center;flex-wrap:wrap">' +
    '<button class="btn btn-ghost" onclick="downloadConfirmation(\'' + reg.id + '\')">⬇ Download Confirmation</button>' +
    '<a class="btn btn-primary" href="#/dashboard" onclick="closeModal()">View My Dashboard →</a>' +
    "</div></div>", 560);
  toast("Registered for " + e.title + " 🎉", "ok");
}
function downloadConfirmation(regId) {
  var reg = DB.registrations.find(function (r) { return r.id === regId; });
  if (!reg) return;
  renderConfirmation(reg).then(function (canvas) { canvasDownload(canvas, reg.id + "-confirmation.png"); });
}
function cancelRegistration(regId) {
  var reg = DB.registrations.find(function (r) { return r.id === regId; });
  if (!reg) return;
  var e = eventById(reg.eventId);
  openModal(modalHead("Cancel registration?", esc(e.title)) +
    '<div class="modal-body"><p class="muted">Your registration <b class="mono">' + reg.id + "</b> will be cancelled and the seat released" + (reg.paid && reg.fee > 0 ? ". Refund (demo): fee will be returned to source" : "") + ".</p></div>" +
    '<div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">Keep it</button>' +
    '<button class="btn btn-danger" onclick="confirmCancel(\'' + regId + '\')">Yes, cancel</button></div>', 480);
}
function confirmCancel(regId) {
  DB.registrations = DB.registrations.filter(function (r) { return r.id !== regId; });
  saveDB(); closeModal(); route();
  toast("Registration cancelled", "info");
}

/* ═══════════════ RESULTS ═══════════════ */
var RF = { q: "", year: "All", cat: "All" };
function pageResults(params) {
  var years = {};
  DB.events.forEach(function (e) { years[eventYear(e)] = true; });
  var yearList = Object.keys(years).sort().reverse();
  var html =
    '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">🏆 Event Results</h1>' +
    '<p class="page-sub">Winners, runners-up and champions of every MHSSCE competition.</p>' +
    '<div class="mt-3 filter-bar">' +
    '<div class="search-box"><input placeholder="Search events…" oninput="RF.q=this.value;renderResults()"></div>' +
    "<label>Year</label><select onchange='RF.year=this.value;renderResults()'>" +
    '<option>All</option>' + yearList.map(function (y) { return "<option " + (RF.year === y ? "selected" : "") + ">" + y + "</option>"; }).join("") + "</select>" +
    "<label>Type</label><select onchange='RF.cat=this.value;renderResults()'>" +
    '<option>All</option>' + CATEGORIES.map(function (c) { return "<option " + (RF.cat === c ? "selected" : "") + ">" + c + "</option>"; }).join("") +
    "</select></div><div id='resultsList'></div></div>";
  setTimeout(renderResults, 0);
  return html;
}
function resultEvents() {
  var evsWithResults = {};
  DB.results.forEach(function (r) { evsWithResults[r.eventId] = true; });
  var list = DB.events.filter(function (e) { return evsWithResults[e.id] && e.resultsPublished; });
  if (RF.q) {
    var q = RF.q.toLowerCase();
    list = list.filter(function (e) { return e.title.toLowerCase().indexOf(q) >= 0 || clubName(e.clubId).toLowerCase().indexOf(q) >= 0; });
  }
  if (RF.year !== "All") list = list.filter(function (e) { return String(eventYear(e)) === RF.year; });
  if (RF.cat !== "All") list = list.filter(function (e) { return e.cat === RF.cat; });
  list.sort(function (a, b) { return evEnd(b) - evEnd(a); });
  return list;
}
function renderResults() {
  var box = qs("#resultsList");
  if (!box) return;
  var list = resultEvents();
  if (!list.length) { box.innerHTML = emptyState("🏆", "No results found", "Results appear here once organizers publish them."); return; }
  var years = {};
  list.forEach(function (e) { (years[eventYear(e)] = years[eventYear(e)] || []).push(e); });
  var html = "";
  Object.keys(years).sort().reverse().forEach(function (y) {
    html += '<div class="archive-year"><h3>' + y + "</h3>";
    years[y].forEach(function (e) {
      var res = DB.results.filter(function (r) { return r.eventId === e.id && r.pos > 0; })
        .sort(function (a, b) { return a.pos - b.pos; });
      var joined = joinedCount(e);
      html += '<div class="result-event">' +
        '<div class="flex-between mb-2"><div><h3 style="font-size:19px;font-weight:800">🏆 ' + esc(e.title) + '</h3>' +
        '<span class="muted small">' + esc(e.cat) + " · " + fmtDateRange(e) + " · " + clubName(e.clubId) + " · 👥 " + joined + " participants</span></div>" +
        '<div class="flex"><a class="btn btn-ghost btn-sm" href="#/participants/' + e.id + '">Participants</a>' +
        '<a class="btn btn-ghost btn-sm" href="#/event/' + e.id + '">Event page</a></div></div>' +
        '<div class="result-rows">' + res.map(function (r) {
          return '<div class="result-row"><span class="medal ' + (r.pos <= 3 ? "m" + r.pos : "") + '">' + (POS_MEDAL[r.pos] || "🏅") + "</span>" +
            '<div class="rr-main"><b>' + esc(r.title) + "</b><span>" +
            (r.members && r.members.length ? "Members: " + esc(r.members.join(", ")) : esc(r.project || "")) +
            (r.project && r.members.length ? " · " + esc(r.project) : "") + "</span></div>" +
            '<span class="rr-prize">' + (r.prize > 0 ? "₹" + r.prize.toLocaleString("en-IN") : "🏆") + "</span></div>";
        }).join("") + "</div></div>";
    });
    html += "</div>";
  });
  box.innerHTML = html;
}

/* ═══════════════ PARTICIPANTS PAGE ═══════════════ */
function pageParticipants(id) {
  var e = eventById(id);
  if (!e) return '<div class="container">' + emptyState("🤷", "Event not found", "", '<a class="btn btn-primary" href="#/events">Browse events</a>') + "</div>";
  var regs = participantsOf(e.id);
  var teams = regs.filter(function (r) { return r.type === "team"; });
  var html =
    '<div class="container" style="padding-top:28px">' +
    '<a class="back-link" href="#/event/' + e.id + '">← Back to event</a>' +
    '<div class="flex-between"><div><h1 class="page-title">Participants</h1>' +
    '<p class="page-sub">' + esc(e.title) + " · " + fmtDateRange(e) + "</p></div>" +
    badgeHTML(e) + "</div>" +
    '<div class="meta-grid mt-3 mb-3">' +
    '<div class="meta-item"><small>Total participants</small><b>' + joinedCount(e) + "</b></div>" +
    '<div class="meta-item"><small>Teams</small><b>' + teams.length + "</b></div>" +
    '<div class="meta-item"><small>Individuals</small><b>' + (regs.length - teams.length) + "</b></div>" +
    '<div class="meta-item"><small>Result status</small><b>' + (e.resultsPublished ? "Published ✓" : "Awaited") + "</b></div>" +
    "</div>" +
    '<div class="note-box mb-3"><span>🔒</span><span>Privacy: only names, branch and year are shown publicly. Phone numbers, emails and PRNs stay private to the organizers.</span></div>' +
    '<div class="filter-bar"><div class="search-box"><input placeholder="Search participant…" oninput="filterParticipantRows(this.value)"></div></div>' +
    '<div class="table-wrap"><table class="data" id="ptTable"><thead><tr>' +
    "<th>#</th><th>Participant</th><th>Branch</th><th>Year</th><th>Type</th><th>Result</th></tr></thead><tbody>" +
    regs.map(function (r, i) {
      return "<tr class='p-row' data-s='" + esc((r.name + " " + r.branch + " " + r.year + " " + (r.teamName || "")).toLowerCase()) + "'>" +
        "<td class='muted'>" + (i + 1) + "</td>" +
        "<td class='t-main'>" + esc(r.name) + (r.teamName ? "<div class='t-sub'>Team: " + esc(r.teamName) + "</div>" : "") + "</td>" +
        "<td>" + esc(r.branch) + "</td><td>" + esc(r.year) + "</td>" +
        "<td>" + (r.type === "team" ? "👥 Team" : "👤 Individual") + "</td>" +
        "<td>" + (e.resultsPublished ? esc(resultLabelForName(e.id, r.name)) : "<span class='muted'>—</span>") + "</td></tr>";
    }).join("") +
    "</tbody></table></div></div>";
  return html;
}
function filterParticipantRows(q) {
  q = q.toLowerCase();
  qsa("#ptTable .p-row").forEach(function (tr) {
    tr.style.display = tr.getAttribute("data-s").indexOf(q) >= 0 ? "" : "none";
  });
}

/* ═══════════════ ARCHIVE ═══════════════ */
function pageArchive() {
  var years = {};
  DB.events.filter(function (e) {
    var k = getStatus(e).key;
    return e.published !== false && (k === "done" || k === "results" || k === "live");
  }).forEach(function (e) { (years[eventYear(e)] = years[eventYear(e)] || []).push(e); });
  var html =
    '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">📕 Event Archive</h1>' +
    '<p class="page-sub">The digital history of MHSSCE events — every year, every winner, forever.</p>' +
    '<div class="mt-3">';
  Object.keys(years).sort().reverse().forEach(function (y) {
    html += '<div class="archive-year"><h3>🗓️ ' + y + "</h3>";
    years[y].sort(function (a, b) { return evStart(b) - evStart(a); }).forEach(function (e) {
      var winner = DB.results.find(function (r) { return r.eventId === e.id && r.pos === 1; });
      html += '<a class="archive-row" href="#/event/' + e.id + '">' +
        '<img class="ar-thumb" src="' + A(e.banner) + '" alt="">' +
        '<div class="ar-main"><b>' + esc(e.title) + "</b><span>" + esc(e.cat) + " · " + fmtDateRange(e) + " · " + clubName(e.clubId) + "</span></div>" +
        '<div class="ar-nums">' +
        "<div><small>Winner</small><b>" + (winner ? esc(winner.title) : "—") + "</b></div>" +
        "<div><small>Participants</small><b>" + joinedCount(e) + "</b></div></div>" +
        (e.resultsPublished ? '<span class="badge badge-results">Results</span>' : "") +
        "</a>";
    });
    html += "</div>";
  });
  html += "</div></div>";
  return html;
}

/* ═══════════════ GALLERY ═══════════════ */
var GF = "All";
function pageGallery(params) {
  if (params && params.event) GF = params.event;
  var evIds = {};
  DB.gallery.forEach(function (g) { evIds[g.eventId] = true; });
  var evs = Object.keys(evIds).map(eventById).filter(Boolean);
  var html =
    '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">📸 Event Gallery</h1>' +
    '<p class="page-sub">' + DB.gallery.length + ' photos · click any photo to view full size</p>' +
    '<div class="chip-row mt-3 mb-3">' +
    '<button class="chip ' + (GF === "All" ? "active" : "") + '" onclick="GF=\'All\';renderGallery()">All</button>' +
    evs.map(function (e) {
      return '<button class="chip ' + (GF === e.id ? "active" : "") + '" onclick="GF=\'' + e.id + '\';renderGallery()">' + esc(e.title) + "</button>";
    }).join("") + "</div>" +
    '<div id="galleryGrid"></div></div>';
  setTimeout(renderGallery, 0);
  return html;
}
function renderGallery() {
  var box = qs("#galleryGrid");
  if (!box) return;
  var items = GF === "All" ? DB.gallery : DB.gallery.filter(function (g) { return g.eventId === GF; });
  box.innerHTML = items.length
    ? '<div class="gallery-grid">' + items.map(function (g, i) {
      return '<div class="g-item reveal" onclick="openLightbox(galleryItems(),' + i + ')"><img src="' + A(g.img) + '" alt="" loading="lazy"><div class="g-cap">' + esc(g.caption) + "</div></div>";
    }).join("") + "</div>"
    : emptyState("📷", "No photos yet", "Photos will appear here after the event.");
  initReveal();
}
function galleryItems() {
  return GF === "All" ? DB.gallery : DB.gallery.filter(function (g) { return g.eventId === GF; });
}

/* ═══════════════ LEADERBOARD ═══════════════ */
var LBF = "";
function pageLeaderboard() {
  return '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">🏆 College Leaderboard</h1>' +
    '<p class="page-sub">Overall champions of MHSSCE — updated live from results & participation.</p>' +
    '<div class="chip-row mt-2 mb-2">' +
    '<span class="badge badge-gold">🥇 Winner +100</span><span class="badge badge-blue">🥈 Runner-up +70</span>' +
    '<span class="badge badge-purple">🥉 Third +50</span><span class="badge badge-green">Finalist +40</span><span class="badge badge-open">Participation +10</span>' +
    "</div>" +
    '<div class="filter-bar"><div class="search-box"><input placeholder="Search your name…" oninput="LBF=this.value;renderLeaderboard()"></div></div>' +
    '<div id="lbWrap"></div></div>';
  setTimeout(renderLeaderboard, 0);
}
function renderLeaderboard() {
  var box = qs("#lbWrap");
  if (!box) return;
  var lb = computeLeaderboard();
  if (LBF) {
    var q = LBF.toLowerCase();
    lb = lb.filter(function (r) { return r.user.name.toLowerCase().indexOf(q) >= 0 || r.user.branch.toLowerCase().indexOf(q) >= 0; });
  }
  if (!lb.length) { box.innerHTML = emptyState("🏆", "No entries yet", "Participate in events to earn points!"); return; }
  var top = lb.slice(0, 3);
  var rest = lb.slice(3);
  var maxPts = lb[0].pts || 1;
  var podium = top.map(function (r, i) {
    var medals = ["🥇", "🥈", "🥉"];
    return '<div class="podium-card p' + (i + 1) + '"><div class="p-medal">' + medals[i] + '</div>' +
      '<span class="avatar">' + initials(r.user.name) + "</span><b>" + esc(r.user.name) + "</b>" +
      '<span class="muted small">' + esc(r.user.branch) + " · " + r.user.year + "</span>" +
      '<div class="pts">' + r.pts + " pts</div>" +
      '<div class="t-sub">' + (r.wins ? "🏆 " + r.wins + " win" + (r.wins > 1 ? "s" : "") : r.events + " events") + "</div>" +
      '<div class="podium-base"></div></div>';
  }).join("");
  box.innerHTML =
    '<div class="podium">' + podium + "</div>" +
    rest.map(function (r, i) {
      return '<div class="lb-row"><span class="lb-rank">' + (i + 4) + '</span>' +
        '<span class="avatar" style="width:36px;height:36px;font-size:12px">' + initials(r.user.name) + "</span>" +
        '<span class="lb-name">' + esc(r.user.name) + "<small>" + esc(r.user.branch) + " · " + r.user.year + "</small></span>" +
        '<div class="lb-bar"><i style="width:' + Math.round(r.pts / maxPts * 100) + '%"></i></div>' +
        '<span class="lb-pts">' + r.pts + "</span></div>";
    }).join("");
}

/* ═══════════════ CLUBS ═══════════════ */
function pageClubs() {
  return '<div class="container" style="padding-top:34px">' +
    '<h1 class="page-title">🤝 Clubs & Committees</h1>' +
    '<p class="page-sub">The communities that make MHSSCE happen. Join one, run events, earn glory.</p>' +
    '<div class="grid-3 mt-3">' + DB.clubs.map(clubCard).join("") + "</div></div>";
}
function pageClubDetail(id) {
  var c = clubOf(id);
  if (!c) return '<div class="container">' + emptyState("🤷", "Club not found", "", '<a class="btn btn-primary" href="#/clubs">All clubs</a>') + "</div>";
  var evs = DB.events.filter(function (e) { return e.clubId === id && e.published !== false; });
  var upcoming = evs.filter(function (e) { var k = getStatus(e).key; return k === "open" || k === "closed" || k === "live"; })
    .sort(function (a, b) { return evStart(a) - evStart(b); });
  var past = evs.filter(function (e) { var k = getStatus(e).key; return k === "done" || k === "results"; })
    .sort(function (a, b) { return evStart(b) - evStart(a); });
  var wins = DB.results.filter(function (r) { return r.pos === 1 && past.some(function (e) { return e.id === r.eventId; }); }).slice(0, 4);
  var photos = DB.gallery.filter(function (g) { return evs.some(function (e) { return e.id === g.eventId; }); }).slice(0, 4);
  var html =
    '<div class="container" style="padding-top:28px">' +
    '<a class="back-link" href="#/clubs">← All clubs</a>' +
    '<div class="register-panel" style="display:flex;gap:26px;align-items:center;flex-wrap:wrap;padding:34px">' +
    '<div class="club-logo" style="background:rgba(255,255,255,.12);width:74px;height:74px;font-size:38px;margin:0">' + c.emoji + "</div>" +
    '<div style="flex:1;min-width:240px"><h2 style="font-size:28px">' + esc(c.name) + '</h2><p style="color:#c8d5ea">' + esc(c.tagline) + "</p>" +
    '<div class="hero-stats" style="margin-top:14px;gap:26px">' +
    '<div class="hero-stat"><b>' + evs.length + '</b><span>Events</span></div>' +
    '<div class="hero-stat"><b>' + c.members + '</b><span>Members</span></div>' +
    '<div class="hero-stat"><b>' + wins.length + '</b><span>Recent wins</span></div></div></div></div>' +
    '<div class="grid-2 mt-3">' +
    '<div class="panel"><h3>ℹ️ About</h3><p style="color:#3d4c66;line-height:1.75">' + esc(c.about) + "</p>" +
    '<div class="mt-2 meta-grid">' +
    '<div class="meta-item"><small>Faculty Coordinator</small><b>' + esc(c.faculty) + "</b></div>" +
    '<div class="meta-item"><small>Student Coordinator</small><b>' + esc(c.studentCoord) + "</b></div></div></div>" +
    '<div class="panel"><h3>🖼️ Club gallery</h3><div class="gallery-grid" style="grid-template-columns:1fr 1fr">' +
    (photos.length ? photos.map(function (g, i) {
      return '<div class="g-item" onclick="openLightbox(DB.gallery,' + DB.gallery.indexOf(g) + ')"><img src="' + A(g.img) + '" alt=""><div class="g-cap">' + esc(g.caption) + "</div></div>";
    }).join("") : '<p class="muted">No photos yet.</p>') + "</div></div></div>" +
    '<div class="mt-3">' + sectionHead("What's next", "Upcoming events") +
    (upcoming.length ? '<div class="grid-3">' + upcoming.map(eventCard).join("") + "</div>" : emptyState("🗓️", "No upcoming events", "Follow this club for announcements.")) + "</div>" +
    '<div class="mt-3">' + sectionHead("Track record", "Past events") +
    (past.length ? past.map(function (e) {
      var w = DB.results.find(function (r) { return r.eventId === e.id && r.pos === 1; });
      return '<a class="archive-row" href="#/event/' + e.id + '"><img class="ar-thumb" src="' + A(e.banner) + '">' +
        '<div class="ar-main"><b>' + esc(e.title) + "</b><span>" + fmtDateRange(e) + "</span></div>" +
        '<div class="ar-nums"><div><small>Winner</small><b>' + (w ? esc(w.title) : "—") + "</b></div><div><small>Joined</small><b>" + joinedCount(e) + "</b></div></div>" +
        (e.resultsPublished ? '<span class="badge badge-results">Results</span>' : "") + "</a>";
    }).join("") : emptyState("📭", "No past events yet", "")) + "</div>" +
    "</div>";
  return html;
}

/* ═══════════════ VERIFY CERTIFICATE ═══════════════ */
function pageVerify(params) {
  var pre = params && params.id ? esc(params.id) : "";
  return '<div class="container" style="padding-top:34px;max-width:760px">' +
    '<h1 class="page-title">🛡️ Verify a Certificate</h1>' +
    '<p class="page-sub">Every EventHub certificate carries a unique ID. Type it below to check authenticity.</p>' +
    '<div class="panel mt-3"><div class="filter-bar" style="box-shadow:none;border:none;padding:0;margin:0">' +
    '<div class="search-box"><input id="verifyInput" class="mono" placeholder="e.g. CERT-2026-10231" value="' + pre + '" onkeydown="if(event.key===\'Enter\')verifyCert()"></div>' +
    '<button class="btn btn-primary" onclick="verifyCert()">Verify</button></div>' +
    '<div id="verifyResult" class="mt-2"></div></div>' +
    '<div class="note-box mt-2"><span>💡</span><span>Try the demo ID <b class="mono">CERT-2026-10231</b></span></div></div>';
  if (pre) setTimeout(verifyCert, 60);
}
function verifyCert() {
  var val = qs("#verifyInput").value.trim().toUpperCase();
  var out = qs("#verifyResult");
  if (!val) { out.innerHTML = ""; return; }
  var cert = DB.certificates.find(function (c) { return c.id.toUpperCase() === val; });
  if (!cert) {
    out.innerHTML = '<div class="note-box" style="background:var(--red-bg);border-color:#f3b6b8;color:#8c1d21"><span>❌</span><span><b>Not verified.</b> No certificate exists with ID <b class="mono">' + esc(val) + "</b>. Check for typos or contact the event organizers.</span></div>";
    return;
  }
  var ev = eventById(cert.eventId);
  out.innerHTML =
    '<div style="border:2px solid #12b76a;background:var(--green-bg);border-radius:14px;padding:18px 20px">' +
    '<div style="font-weight:800;color:#067647;font-size:16px">✓ CERTIFICATE VERIFIED</div>' +
    '<div class="meta-grid mt-2">' +
    '<div class="meta-item" style="background:#fff"><small>Name</small><b>' + esc(cert.name) + "</b></div>" +
    '<div class="meta-item" style="background:#fff"><small>Event</small><b>' + esc(ev ? ev.title : "—") + "</b></div>" +
    '<div class="meta-item" style="background:#fff"><small>Achievement</small><b>' + esc(cert.achievement) + "</b></div>" +
    '<div class="meta-item" style="background:#fff"><small>Issued by</small><b>MHSSCE · ' + fmtDate(cert.date) + "</b></div>" +
    "</div>" +
    '<button class="btn btn-primary mt-2" onclick="openCertificate(\'' + cert.id + '\')">View full certificate →</button></div>';
}

/* ═══════════════ LOGIN / REGISTER ═══════════════ */
function pageLogin(params) {
  var mode = params && params.mode === "register" ? "register" : "login";
  return '<div class="container"><div class="auth-wrap">' +
    '<div class="auth-side">' +
    '<a href="#/" style="color:#fff;font-weight:800;font-size:18px">🎓 MHSSCE EVENTHUB</a>' +
    "<h2>Your gateway to<br>every college event.</h2>" +
    "<p>Register for hackathons in seconds, build your participation profile, collect certificates and climb the college leaderboard.</p>" +
    "<ul><li>One-tap event registration</li><li>Digital certificates with verification</li><li>Personal dashboard & history</li><li>Leaderboard points & badges</li></ul>" +
    '<div class="quote">“EXPERIENCE. PARTICIPATE. WIN.”<br><span class="small" style="opacity:.7">— Team EventHub</span></div></div>' +
    '<div class="auth-form">' +
    '<div class="auth-tabs"><button class="' + (mode === "login" ? "active" : "") + '" onclick="location.hash=\'#/login\'">Login</button>' +
    '<button class="' + (mode === "register" ? "active" : "") + '" onclick="location.hash=\'#/login?mode=register\'">Create account</button></div>' +
    '<div id="authBox">' + (mode === "login" ? loginFormHTML() : registerFormHTML()) + "</div>" +
    "</div></div></div>";
}
function loginFormHTML() {
  return '<div class="form-grid">' +
    '<div class="field full"><label>Email</label><input id="li_email" placeholder="you@mhssce.ac.in"></div>' +
    '<div class="field full"><label>Password</label><input id="li_pass" type="password" placeholder="••••••••" onkeydown="if(event.key===\'Enter\')doLogin()"></div>' +
    "</div>" +
    '<button class="btn btn-primary btn-block mt-2" onclick="doLogin()">Login →</button>' +
    '<p class="muted small center mt-2">New here? <a href="#/login?mode=register"><b>Create a student account</b></a></p>' +
    '<div class="demo-box"><b>🧪 Demo accounts (for presentation)</b>' +
    '<button class="btn btn-ghost btn-xs" onclick="demoLogin(\'student@mhssce.ac.in\')">👨‍🎓 Student</button>' +
    '<button class="btn btn-ghost btn-xs" onclick="demoLogin(\'admin@mhssce.ac.in\')">🛠️ Admin</button>' +
    '<button class="btn btn-ghost btn-xs" onclick="demoLogin(\'organizer@mhssce.ac.in\')">🎤 Organizer</button>' +
    '<div class="mt-1 muted">student@mhssce.ac.in · student123<br>admin@mhssce.ac.in · admin123<br>organizer@mhssce.ac.in · org123</div></div>';
}
function registerFormHTML() {
  return '<div class="form-grid">' +
    '<div class="field full"><label>Full Name <span class="req">*</span></label><input id="rg_name" placeholder="As per college records"></div>' +
    '<div class="field full"><label>Email <span class="req">*</span></label><input id="rg_email" type="email" placeholder="you@mhssce.ac.in"></div>' +
    '<div class="field"><label>Phone</label><input id="rg_phone" placeholder="98XXXXXXXX"></div>' +
    '<div class="field"><label>PRN / Roll No <span class="req">*</span></label><input id="rg_prn"></div>' +
    '<div class="field"><label>Branch</label><select id="rg_branch">' + BRANCHES.map(function (b) { return "<option>" + b + "</option>"; }).join("") + "</select></div>" +
    '<div class="field"><label>Year</label><select id="rg_year">' + YEARS.map(function (y) { return "<option>" + y + "</option>"; }).join("") + "</select></div>" +
    '<div class="field full"><label>Password <span class="req">*</span></label><input id="rg_pass" type="password" placeholder="Min 6 characters"></div>' +
    "</div>" +
    '<button class="btn btn-primary btn-block mt-2" onclick="doRegister()">Create account →</button>' +
    '<p class="muted small center mt-2">Already registered? <a href="#/login"><b>Login</b></a></p>' +
    '<p class="muted small center">Staff accounts are issued by the college admin.</p>';
}
function demoLogin(email) {
  qs("#li_email").value = email;
  qs("#li_pass").value = { "student@mhssce.ac.in": "student123", "admin@mhssce.ac.in": "admin123", "organizer@mhssce.ac.in": "org123" }[email];
  doLogin();
}
function doLogin() {
  var email = qs("#li_email").value.trim().toLowerCase();
  var pass = qs("#li_pass").value;
  var u = DB.users.find(function (x) { return x.email.toLowerCase() === email; });
  if (!u || u.pass !== pass) return toast("Invalid email or password", "err");
  setSession(u.id);
  toast("Welcome back, " + u.name.split(" ")[0] + "!", "ok");
  if (PENDING_REG) {
    var eid = PENDING_REG;
    if (u.role === "student") { location.hash = "#/event/" + eid; setTimeout(function () { startRegistration(eid); }, 350); PENDING_REG = null; return; }
  }
  if (u.role === "admin" || u.role === "organizer") location.hash = "#/admin";
  else location.hash = "#/dashboard";
}
function doRegister() {
  var name = qs("#rg_name").value.trim();
  var email = qs("#rg_email").value.trim().toLowerCase();
  var phone = qs("#rg_phone").value.trim();
  var prn = qs("#rg_prn").value.trim();
  var branch = qs("#rg_branch").value;
  var year = qs("#rg_year").value;
  var pass = qs("#rg_pass").value;
  if (name.length < 3) return toast("Enter your full name", "err");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return toast("Enter a valid email", "err");
  if (prn.length < 4) return toast("PRN is required", "err");
  if (pass.length < 6) return toast("Password must be at least 6 characters", "err");
  if (DB.users.some(function (u) { return u.email.toLowerCase() === email; })) return toast("An account with this email already exists — try logging in", "err");
  var u = {
    id: uid("u"), name: name, email: email, phone: phone, prn: prn,
    branch: branch, year: year, role: "student", pass: pass
  };
  DB.users.push(u);
  saveDB();
  setSession(u.id);
  toast("Account created — welcome to EventHub, " + name.split(" ")[0] + "! 🎉", "ok");
  if (PENDING_REG) { var eid = PENDING_REG; PENDING_REG = null; location.hash = "#/event/" + eid; setTimeout(function () { startRegistration(eid); }, 350); }
  else location.hash = "#/dashboard";
}

/* ═══════════════ STUDENT DASHBOARD ═══════════════ */
function pageDashboard(params) {
  var u = currentUser();
  if (!u) { location.hash = "#/login"; return '<div class="container mt-4">' + emptyState("🔐", "Login required", "Redirecting you to login…") + "</div>"; }
  var myRegs = DB.registrations.filter(function (r) { return r.userId === u.id; });
  var myCerts = DB.certificates.filter(function (c) { return c.userId === u.id; });
  var attended = myRegs.filter(function (r) { var e = eventById(r.eventId); return e && (getStatus(e).key === "done" || getStatus(e).key === "results"); });
  var pts = (computeLeaderboard().find(function (r) { return r.user.id === u.id; }) || {}).pts || 0;
  var rank = userRank(u.id);
  var tab = params && params.tab === "certs" ? "certs" : "regs";

  var recs = DB.events.filter(function (e) { return regOpenFor(e) && !myRegs.some(function (r) { return r.eventId === e.id; }); })
    .sort(function (a, b) { return evStart(a) - evStart(b); }).slice(0, 3);

  var html =
    '<div class="container" style="padding-top:30px">' +
    '<h1 class="page-title">My Dashboard</h1><p class="page-sub">Your EventHub profile, registrations and certificates.</p>' +
    '<div class="dash-grid mt-3">' +
    '<div><div class="profile-card">' +
    '<span class="avatar">' + initials(u.name) + "</span>" +
    "<h3>" + esc(u.name) + "</h3>" +
    '<div class="p-meta">' + esc(u.branch) + " · " + (YEAR_FULL[u.year] || u.year) + "</div>" +
    '<div class="p-meta mono">' + esc(u.prn) + "</div>" +
    '<div class="p-points"><div><b>' + pts + '</b><span>Points</span></div><div><b>#' + (rank || "—") + '</b><span>Rank</span></div><div><b>' + myCerts.length + '</b><span>Certs</span></div></div>' +
    '<a class="btn btn-light btn-block mt-2" href="#/leaderboard">View leaderboard →</a>' +
    "</div>" +
    '<div class="panel mt-3"><h3>✨ Recommended for you</h3>' +
    (recs.length ? recs.map(function (e) {
      return '<div class="reg-item"><img src="' + A(e.banner) + '"><div class="ri-main"><b>' + esc(e.title) + "</b><span>" + fmtDateRange(e) + " · " + fmtMoney(e.fee) + "</span></div>" +
        '<button class="btn btn-primary btn-xs" onclick="startRegistration(\'' + e.id + '\')">Register</button></div>';
    }).join("") : '<p class="muted small">You have registered for everything open — legend! 🏆</p>') +
    "</div></div>" +
    '<div>' +
    '<div class="tabs mb-2">' +
    '<button class="tab ' + (tab === "regs" ? "active" : "") + '" onclick="location.hash=\'#/dashboard\'">🎟️ My Registrations (' + myRegs.length + ')</button>' +
    '<button class="tab ' + (tab === "certs" ? "active" : "") + '" onclick="location.hash=\'#/dashboard?tab=certs\'">🏆 My Certificates (' + myCerts.length + ')</button>' +
    "</div>";

  if (tab === "regs") {
    html += myRegs.length ? myRegs.map(function (r) {
      var e = eventById(r.eventId);
      if (!e) return "";
      var st = getStatus(e);
      return '<div class="reg-item"><img src="' + A(e.banner) + '" alt="">' +
        '<div class="ri-main"><b>' + esc(e.title) + '</b><span class="mono">' + r.id + "</span> <span>· " + fmtDateRange(e) + " · " + (r.type === "team" ? "👥 " + esc(r.teamName) : "👤 Individual") + "</span></div>" +
        (r.paid && r.fee > 0 ? '<span class="badge badge-green">Paid</span>' : r.fee > 0 ? '<span class="badge badge-closed">Unpaid</span>' : "") + " " + badgeHTML(e) +
        '<div class="flex" style="gap:6px">' +
        '<button class="btn btn-ghost btn-xs" onclick="downloadConfirmation(\'' + r.id + '\')">⬇</button>' +
        (st.key === "open" ? '<button class="btn btn-danger btn-xs" onclick="cancelRegistration(\'' + r.id + '\')">✕</button>' : "") +
        '<a class="btn btn-ghost btn-xs" href="#/event/' + e.id + '">→</a></div></div>';
    }).join("") : emptyState("🎟️", "No registrations yet", "Browse events and register for your first one!", '<a class="btn btn-primary" href="#/events">Explore events →</a>');
  } else {
    html += myCerts.length ? myCerts.map(function (c) {
      var e = eventById(c.eventId);
      var icon = c.achievement === "Winner" ? "🏆" : c.achievement === "Runner-up" ? "🥈" : c.achievement === "Third Place" ? "🥉" : "🎖";
      return '<div class="cert-item"><span class="c-emoji">' + icon + '</span><div class="ci-main"><b>' + esc(e ? e.title : "Event") + '</b><span class="mono">' + c.id + "</span> <span>· " + esc(c.achievement) + "</span></div>" +
        '<div class="flex" style="gap:6px">' +
        '<button class="btn btn-ghost btn-xs" onclick="openCertificate(\'' + c.id + '\')">👁 View</button>' +
        '<button class="btn btn-ghost btn-xs" onclick="downloadCert(\'' + c.id + '\')">⬇ PNG</button></div></div>';
    }).join("") : emptyState("🏅", "No certificates yet", "Participate in events — winners and participants get verifiable digital certificates.", '<a class="btn btn-primary" href="#/events">Find events →</a>');
    html += '<div class="note-box mt-2"><span>🛡️</span><span>Every certificate has a public verification ID. Share it with anyone — they can verify it at the <a href="#/verify">Verify page</a>.</span></div>';
  }
  html += "</div></div></div>";
  return html;
}

/* ═══════════════ ABOUT ═══════════════ */
function pageAbout() {
  var feats = [
    ["🔍", "Discover", "Live, upcoming and archived events in one place with powerful filters."],
    ["📝", "Register", "Smart forms with team support, instant confirmation and demo payments."],
    ["🏆", "Compete", "Results, winner profiles, points and a college-wide leaderboard."],
    ["🎖", "Get certified", "Verifiable digital certificates with public verification IDs."],
    ["🛠️", "Organize", "Full admin panel — create events, manage registrations, publish results."],
    ["📕", "Preserve", "A permanent digital archive of the college's event history."]
  ];
  var stack = ["HTML5", "CSS3", "Vanilla JavaScript", "Hash Router (SPA)", "Canvas API", "localStorage", "Python HTTP Server"];
  return '<div class="container" style="padding-top:34px;max-width:900px">' +
    '<h1 class="page-title">About MHSSCE EventHub</h1>' +
    '<p class="page-sub">A student-built college project — one platform to discover, register, manage and archive every event at MHSSCE.</p>' +
    '<div class="panel mt-3" style="display:flex;gap:24px;align-items:center;flex-wrap:wrap">' +
    '<img src="' + A("assets/img/logo.png") + '" style="width:110px" alt="MHSSCE logo">' +
    '<div><h3>Anjuman-I-Islam\u2019s M.H. Saboo Siddik College of Engineering</h3>' +
    '<p class="muted">8, Shepherd Road, Byculla, Mumbai — 400 008 · Affiliated to the University of Mumbai · Approved by AICTE</p>' +
    '<p class="mt-1" style="color:#3d4c66">EventHub was built to solve a simple problem: information about college events is scattered across posters, WhatsApp groups and word of mouth. This portal brings the entire event lifecycle online — from discovery to certificates — and preserves our college\u2019s event history forever.</p></div></div>' +
    '<div class="grid-3 mt-3">' + feats.map(function (f) {
      return '<div class="panel reveal"><h3 style="margin-bottom:8px">' + f[0] + " " + f[1] + "</h3><p class='muted' style='font-size:13.5px'>" + f[2] + "</p></div>";
    }).join("") + "</div>" +
    '<div class="panel mt-3"><h3>🧰 Technology used</h3><div class="chip-row">' +
    stack.map(function (s) { return '<span class="chip" style="cursor:default">' + s + "</span>"; }).join("") + "</div>" +
    '<p class="muted small mt-2">The frontend is a single-page application with a hash router. Data is managed in a mock database layer (localStorage) that mirrors the MongoDB collections designed in the project spec — so it can be swapped with a real Node.js + Express + MongoDB backend without touching the UI.</p></div>' +
    '<div class="panel mt-3"><h3>👥 Team EventHub</h3>' +
    '<p class="muted">Built by students of MHSSCE as a classroom project — and designed to grow into a real college-wide platform.</p>' +
    '<div class="meta-grid mt-2">' +
    '<div class="meta-item"><small>Project guide</small><b>Prof. M. A. Shaikh</b></div>' +
    '<div class="meta-item"><small>Team</small><b>Team EventHub — TY CSE</b></div>' +
    '<div class="meta-item"><small>Version</small><b>v1.0 · 2026</b></div>' +
    '<div class="meta-item"><small>Status</small><b>Phase 1 & 2 complete</b></div></div></div>' +
    '<div class="note-box mt-3"><span>🎓</span><span>This is a demonstration portal. All events, people and results shown are sample data created for the project demo.</span></div>' +
    "</div>";
}

/* ═══════════════ 404 ═══════════════ */
function page404() {
  return '<div class="container mt-4">' + emptyState("🧭", "Page not found", "The link may be outdated.", '<a class="btn btn-primary" href="#/">Go home</a>') + "</div>";
}
