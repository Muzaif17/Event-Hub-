#!/usr/bin/env python3
"""
MHSSCE EventHub — local development server
Serves the project folder and falls back to index.html for unknown
paths (SPA-friendly). Run:  python3 server.py   →  http://localhost:8000
"""
import http.server
import os
import socketserver
import sys

PORT = int(os.environ.get("PORT", 8000))
ROOT = os.path.dirname(os.path.abspath(__file__))


class SPAHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def send_head(self):
        path = self.translate_path(self.path)
        # SPA fallback: unknown "pretty" paths get index.html
        if not os.path.exists(path) and "." not in os.path.basename(self.path):
            self.path = "/index.html"
        return super().send_head()

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stdout.write("  %s - %s\n" % (self.address_string(), fmt % args))
        sys.stdout.flush()


class ThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    with ThreadingServer(("0.0.0.0", PORT), SPAHandler) as httpd:
        print("=" * 62)
        print("  MHSSCE EVENTHUB — dev server")
        print("  Serving : %s" % ROOT)
        print("  URL     : http://localhost:%d" % PORT)
        print("=" * 62)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nBye!")
