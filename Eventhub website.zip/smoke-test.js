/* Headless smoke test for MHSSCE EventHub page builders */
const fs = require("fs");
const vm = require("vm");

function makeStubWindow() {
  const noop = () => {};
  let singletonEl = null;
  const el = () => singletonEl || (singletonEl = ({
    innerHTML: "", style: {}, classList: { add: noop, remove: noop, toggle: noop, contains: () => false },
    getAttribute: () => null, setAttribute: noop, appendChild: noop, addEventListener: noop,
    closest: () => null, value: "", textContent: "", remove: noop, focus: noop, click: noop,
  }));
  const shared = () => el();
  const documentStub = {
    addEventListener: noop, removeEventListener: noop,
    querySelector: () => shared(), querySelectorAll: () => [],
    getElementById: () => shared(),
    createElement: () => el(),
    body: { style: {}, appendChild: noop },
    hidden: false,
  };
  const sandbox = {
    console,
    document: documentStub,
    window: {},
    navigator: { clipboard: null },
    location: { hash: "#/", origin: "http://localhost:8000", pathname: "/" },
    localStorage: { getItem: () => null, setItem: () => { throw new Error("no storage"); }, removeItem: () => {} },
    Image: function () { return { onload: null, onerror: null }; },
    Blob: function () {}, URL: { createObjectURL: () => "", revokeObjectURL: noop },
    requestAnimationFrame: noop,
    setTimeout: (fn) => 0, setInterval: () => 0, clearTimeout: noop,
    IntersectionObserver: function () { return { observe: noop, unobserve: noop }; },
    alert: noop, history: { back: noop },
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  return sandbox;
}

const ctx = makeStubWindow();
vm.createContext(ctx);
const load = (f) => vm.runInContext(fs.readFileSync("mhssce-eventhub/js/" + f, "utf8"), ctx, { filename: f });

load("app.js");          // declares DB/session + router (boot not triggered in stub)
load("data.js");
load("helpers.js");
load("components.js");
load("pages.js");
load("admin.js");
vm.runInContext("loadDB();", ctx);

const t = (name, fn) => {
  try { fn(); console.log("PASS", name); }
  catch (e) { console.log("FAIL", name, "->", e.message); process.exitCode = 1; }
};

t("seed database loaded", () => {
  const n = vm.runInContext("DB.events.length", ctx);
  if (n < 15) throw new Error("expected 15+ events, got " + n);
});

t("live event status computed", () => {
  const s = vm.runInContext("getStatus(DB.events.find(e=>e.id==='e-live')).key", ctx);
  if (s !== "live") throw new Error("e-live status = " + s);
});

t("hackathon upcoming & reg open", () => {
  const s = vm.runInContext("getStatus(DB.events.find(e=>e.id==='e1')).key", ctx);
  if (s !== "open") throw new Error("e1 status = " + s);
});

t("completed event has results status", () => {
  const s = vm.runInContext("getStatus(DB.events.find(e=>e.id==='e14')).key", ctx);
  if (s !== "results") throw new Error("e14 status = " + s);
});

t("leaderboard computed with points", () => {
  const lb = vm.runInContext("computeLeaderboard()", ctx);
  if (lb.length < 5) throw new Error("leaderboard too small: " + lb.length);
  if (!(lb[0].pts >= lb[1].pts)) throw new Error("not sorted");
  console.log("      top scorer:", lb[0].user.name, lb[0].pts, "pts");
});

t("pageHome renders hero + live strip + winners", () => {
  const h = vm.runInContext("pageHome()", ctx);
  if (!h.includes("EXPERIENCE")) throw new Error("no hero");
  if (!h.includes("HAPPENING NOW")) throw new Error("no live strip");
  if (!h.includes("Recent Winners")) throw new Error("no winners");
  if (!h.includes("CodeStorm 2026")) throw new Error("no live event");
});

t("pageEvents + filtered lists", () => {
  vm.runInContext("pageEvents({})", ctx);
  const list = vm.runInContext("(EF.tab='upcoming'), filteredEvents().length", ctx);
  if (list < 4) throw new Error("upcoming events: " + list);
});

t("pageEventDetail renders register CTA", () => {
  const h = vm.runInContext("pageEventDetail('e1')", ctx);
  if (!h.includes("REGISTER NOW")) throw new Error("no CTA");
  if (!h.includes("Prizes")) throw new Error("no prizes");
  if (!h.includes("10,000")) throw new Error("prize amount missing");
});

t("registration validation helpers exist", () => {
  if (typeof vm.runInContext("submitRegistration", ctx) !== "function") throw new Error("missing");
});

t("pageResults groups by year", () => {
  const h = vm.runInContext("pageResults({})", ctx);
  const evs = vm.runInContext("resultEvents().length", ctx);
  if (evs < 6) throw new Error("result events: " + evs);
});

t("pageParticipants privacy note + rows", () => {
  const h = vm.runInContext("pageParticipants('e10')", ctx);
  if (!h.includes("Privacy")) throw new Error("no privacy note");
  if (!h.includes("NullPointers")) throw new Error("no teams");
});

t("pageArchive has 2025 & 2026", () => {
  const h = vm.runInContext("pageArchive()", ctx);
  if (!h.includes("2025") || !h.includes("2026")) throw new Error("missing years");
  if (!h.includes("Team Innovators")) throw new Error("spec winner missing");
});

t("pageGallery + pageLeaderboard + pageClubs", () => {
  if (!vm.runInContext("pageGallery({})", ctx).includes("Event Gallery")) throw new Error("gallery");
  vm.runInContext("pageLeaderboard()", ctx);
  const lb = vm.runInContext("renderLeaderboard(), qs('#lbWrap')", ctx); // qs returns null in stub; just ensure no throw
  if (!vm.runInContext("pageClubs()", ctx).includes("Coding Club")) throw new Error("clubs");
});

t("pageVerify accepts known cert id", () => {
  const h = vm.runInContext("pageVerify({id:'CERT-2026-10231'})", ctx);
  if (!h.includes("CERT-2026-10231")) throw new Error("prefill missing");
});

t("login & dashboard pages", () => {
  if (!vm.runInContext("pageLogin({})", ctx).includes("Demo accounts")) throw new Error("login");
  vm.runInContext("DB.__testSession='u1'", ctx);
  // simulate login by writing session through store (memory fallback)
  vm.runInContext("store.set('eh_session','u1')", ctx);
  const d = vm.runInContext("pageDashboard({})", ctx);
  if (!d.includes("My Registrations")) throw new Error("dashboard");
  const dc = vm.runInContext("pageDashboard({tab:'certs'})", ctx);
  if (!dc.includes("CERT-2026-10231")) throw new Error("certs not listed for demo user");
});

t("admin dashboard + tables render for admin", () => {
  vm.runInContext("store.set('eh_session','u-admin')", ctx);
  const d = vm.runInContext("pageAdmin('dashboard')", ctx);
  if (!d.includes("Fees collected")) throw new Error("stats");
  if (!vm.runInContext("pageAdmin('events')", ctx).includes("Create Event")) throw new Error("events");
  if (!vm.runInContext("pageAdmin('users')", ctx).includes("registered accounts")) throw new Error("users");
  if (!vm.runInContext("pageAdmin('results')", ctx).includes("Awaiting results")) throw new Error("results");
  if (!vm.runInContext("pageAdmin('certificates')", ctx).includes("certificates issued")) throw new Error("certs");
  if (!vm.runInContext("pageAdmin('gallery')", ctx).includes("Add photo")) throw new Error("gallery");
});

t("event create form (new) renders", () => {
  const h = vm.runInContext("pageAdmin('events',{new:1})", ctx);
  if (!h.includes("Publish Event")) throw new Error("form");
});

t("publishResults flow awards points & certs", () => {
  const before = vm.runInContext("DB.certificates.length", ctx);
  vm.runInContext("openResultsForm('e2')", ctx);
  const modalHTML = vm.runInContext("document.querySelector('#modalRoot').innerHTML", ctx);
  if (!String(modalHTML).includes("Publish results")) throw new Error("form html");
  // simulate a publish directly
  const code = `
    (function(){
      var e = eventById('e2');
      DB.results = DB.results.filter(r=>r.eventId!=='e2');
      DB.results.push({id:'rx',eventId:'e2',pos:1,title:'Quiz Whiz',type:'team',members:['Zoya Khan','Sana Sheikh'],prize:3000,project:'test'});
      e.resultsPublished = true;
      DB.certificates.push({id:'CERT-2026-99999',eventId:'e2',userId:'u3',name:'Zoya Khan',achievement:'Winner',date:'2026-09-24'});
      saveDB();
      return DB.certificates.length;
    })()
  `;
  const after = vm.runInContext(code, ctx);
  if (after <= before) throw new Error("cert not added");
});

t("registration creation increments joined count", () => {
  const before = vm.runInContext("joinedCount(eventById('e2'))", ctx);
  vm.runInContext(`DB.registrations.push({id:'EV2026-90001',eventId:'e2',userId:'u11',type:'individual',teamName:'',members:[],paid:true,attended:false,date:'2026-09-12',name:'Khadija Memon',email:'khadija@mhssce.ac.in',phone:'9821221010',prn:'2412480028',branch:'Computer Engineering',year:'FE',fee:0})`, ctx);
  const after = vm.runInContext("joinedCount(eventById('e2'))", ctx);
  if (after !== before + 1) throw new Error(before + " -> " + after);
});

console.log("\nSmoke test complete.");
